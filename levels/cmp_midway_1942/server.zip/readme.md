CMP Midway 1942
===============

Remake of the fh07 map by Dime a Dozen. FH2 map made by Stubbfan, Watchtower and Pr0z4c.

Rework going on by pozzo


TODO
====

[ ] localization, including notifications (see below)
[ ] add ABC plugin to cmp
[ ] remove objective markers from carriers
[ ] 16p: make boats explode FASTER
[ ] 16p: scale flagpole BIGGER
[O] make airfield destrutable
  [ ] make dedicated object (mc202 placeholder)
[ ] non-spawnraped plane spawns
[ ] figure out purpose for ships


Notification
------------

```
CP_16_midway_notificationKing of the Hill:
Flag can be captured by both Airplane and Ship.
Do NOT enter enemy spawn area (red minimap markers).

CP_32_midway_notificationBoth Teams: Bomb the enemy carriers to win

CP_64_midway_notificationJapan: 
Main Island:  Destroy enemy hangar, fuel tanks and radar sites. 
Small Island:. Destroy enemy runway.

USA: Sink all Japanese Carriers

Both Teams: Destroy the enemy naval fleet

Ships CANNOT enter the lagoon!
Ships CANNOT enter enemy spawnzone (red markers)!
```


CHANGES
=======

- Give everything in the GPO.con/mapdata.py a proper name


New Layers
----------

- add 16p layer: air KOT, 
  - 2 carriers each, 
  - 2 PTboats each, 
  - 1 divebomber spawn, 
  - rest fighters
- add 32p layer: carrier-only objective (last phase of 64p)
  - 2 carriers each
  - ships


Spawns
------

- 64p: add spawns at henderson west tip (new group)
- 64p: add spawns at henderson southeast (new group)
- 64p: split sand island spawns into groups
- 64p: add new sand island spawns


PCOs
----

- 64p: Add 50cal to henderson west tip (empty sandbag pos)
- 64p: replace lone browning 30cal with a 50cal (30cal also has too limited elev)
- 64p: add AA to sandisland east tip (empty prepared sandbag circle)
- 64p: add 2 boats to east sandisland (so you can leave for henderson when the 
  objectives are down and there is nothing left to defend)
- add gap in 64p allied naval OOB -- big ships still cant go island, but the
  lifeboats can travel between the islands
- strengthen lifeboat engine a bit
- add airfield objective (mc202 placeholder) -> destroying it loses henderson field
- US carriers will also spawn upon henderson destruction


HUD
---

- remove on-map Tutorial text (move to localized Notification Flag)
- remove on-map ABC lines (replace with dynamic ABC marker)


Notes
=====

Win condition:

- US need to sink 4x carriers
- JP need to destroy 14x Fueltanks, 4x AA Batteries, 1x Hangar building and 2x Carriers

Reinforcements:

- japanese north carrier spawns once east carrier goes down
- japanese west carrier spawns once south carrier goes down

- us north carrier spawns once silo goes down
- us south carrier spawns once hangar goes down

```
japanese:
  tf a:  [start axis]
    cv shokaku dest    (-1581/1011) [Bottom]
    - flag 102 (tf)
    "jap carrier south"

  tf b:  [start allies] -> delay (spawns when 107 goes down) (D)
    - flag 104 (tf2)
    cv shokaku dest 1  (-1520/1619) [Top]
    "jap carrier north"

  tf c:  [start allies] -> delay (spawns when 102 goes down) (A)
    - flag 106 (tf3)
    cv shokaku dest 2  (-1781/1500) [Left]
    "jap carrier west"

  tf d:  [start axis]
    - flag 107 (tf4)
    cv shokaku dest 3  (-1292/1229) [Right]
    "jap carrier east"

  shipsup a: [start allies] -> delay (when either 102, 106, 107 go down)
  "japanese cruisers"
    ca mogami

  shipsup b: [start allies] -> delay
  "japanese destroyers"
    dd hatsuzuki
    dd hatsuzuki

  shipsup c: [start allies] -> delay
  "japanese torpedoboats"
    bt ptboat
    bt ptboat

american:
  tf e: [start axis] -> delay (trigger by hangar)
    - tf 16 attackcarrier
    - flag 103 (tf 16)
    cv enterprise dest 1  [N]
    "american carrier south"

  tf a:  [start axis] -> delay (trigger by silo)
    - tf 16 carrier
    - flag 108 (tf 16 2 1)
    cv enterprise dest  [S]
    "american carrier north"

  tf d:  [start axis] -> delay
    "american ships"
    dd gleaves
    dd southdakota
    ub gato
```
