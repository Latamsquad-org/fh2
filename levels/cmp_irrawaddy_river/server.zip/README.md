# Level template repository

## Remove .sample from filename

This should be obvious to make them work, also, copypasta them into your own map folder. These files will be updated.

### .gitattributes

This file describes which file formats will be pushed to LFS storage instead of regular repo

### .gitignores

This file describes which files will be excluded from commits. Essentially client and server zips as obviously its the build jobs job to create them for you

### .gitlab-ci.yml

This file describes the job. Sorts files around, runs the packing script and pushes the files for people to download.

# ! Before pushing any files or making any commits, do 'git lfs install' or equivalent from your choice of GUI