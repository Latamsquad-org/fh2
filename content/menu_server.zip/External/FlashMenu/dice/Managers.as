class dice.Managers extends MovieClip
{
    function Managers()
    {
        super();
        trace ("Manager Spawns");
        _root.updateManager1 = new dice.UpdateManager(_root.updateManager1, 50);
        dice.bf2.AudioSettings;
        dice.bf2.Clans;
        dice.bf2.Client;
        dice.bf2.ControlSettings;
        dice.bf2.Cursor;
        dice.bf2.EndOfRound;
        dice.bf2.GeneralSettings;
        dice.bf2.Locale;
        dice.bf2.Logic;
        dice.bf2.Mod;
        dice.bf2.Multiplay;
        dice.bf2.Options;
        dice.bf2.Player;
        dice.bf2.PlayerStats;
        dice.bf2.Profile;
        dice.bf2.Render;
        dice.bf2.ServerInfo;
        dice.bf2.ServerSettings;
        dice.bf2.Singleplay;
        dice.bf2.Sound;
        dice.bf2.VideoSettings;
        dice.bf2.GlobalSettings;
    } // End of the function
} // End of Class
