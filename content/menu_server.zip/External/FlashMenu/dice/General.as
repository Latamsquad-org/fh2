class dice.General
{
    function General()
    {
    } // End of the function
    static function cacheExtendedServerInfo()
    {
    } // End of the function
    static function getHostVersion()
    {
        return ("9.9.9.9999");
    } // End of the function
    static function flushList(id)
    {
    } // End of the function
    static function setFilter(id, filter)
    {
    } // End of the function
    static function setSortOrder(id, column, descending)
    {
    } // End of the function
    static function getListRevision(id)
    {
    } // End of the function
    static function getListEntries(id, start, count)
    {
    } // End of the function
    static function saveList(id)
    {
    } // End of the function
    static function setEquipmentIndex(n)
    {
    } // End of the function
} // End of Class
