class dice.UI extends MovieClip
{
    var m_inAuthorMode, __get__soundId, m_callbackFrequency, __get__callbackFrequency, __get__callbackIsStaticFunction, m_callbackFormat, __get__callbackFormat, __get__callBackFunctionSpecial, m_callbackFunctionSpecial, __get__callbackFunctionInit, m_callbackFunctionInit, __get__callBackFunction, m_callbackFunction, __get__callBackGetFunction, m_callbackGetFunction, m_localizationId, __get__localizationId, __get____authorMode, __get__alpha, _alpha, __get__isEnabled, __get__height, __height, __get__width, __width, _xscale, _yscale, _height, _width, m_glowPercentFactor, m_glowPercent, m_glowStartAlpha, m_callbackObject, m_callbackObjectInit, m_callbackObjectSpecial, m_callbackGetObject, __set____authorMode, __set__alpha, __set__callBackFunction, __set__callBackFunctionSpecial, __set__callBackGetFunction, __set__callbackFormat, __set__callbackFrequency, __set__callbackFunctionInit, __set__callbackIsStaticFunction, __set__height, __set__isEnabled, __set__localizationId, __set__soundId, __set__width;
    function UI(cancelInit)
    {
        super();
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.attachChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set soundId(nValue)
    {
        m_soundId = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.soundId());
        null;
    } // End of the function
    function get soundId()
    {
        return (m_soundId);
    } // End of the function
    function set callbackFrequency(nValue)
    {
        m_callbackFrequency = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.callbackFrequency());
        null;
    } // End of the function
    function get callbackFrequency()
    {
        return (m_callbackFrequency);
    } // End of the function
    function set callbackIsStaticFunction(nValue)
    {
        m_callbackIsStaticFunction = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.callbackIsStaticFunction());
        null;
    } // End of the function
    function get callbackIsStaticFunction()
    {
        return (m_callbackIsStaticFunction);
    } // End of the function
    function set callbackFormat(nValue)
    {
        m_callbackFormat = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.callbackFormat());
        null;
    } // End of the function
    function get callbackFormat()
    {
        return (m_callbackFormat);
    } // End of the function
    function set callBackFunctionSpecial(sValue)
    {
        this.setCallbackSpecial(sValue);
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.callBackFunctionSpecial());
        null;
    } // End of the function
    function get callBackFunctionSpecial()
    {
        return (m_callbackFunctionSpecial);
    } // End of the function
    function set callbackFunctionInit(sValue)
    {
        this.setCallbackInit(sValue);
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.callbackFunctionInit());
        null;
    } // End of the function
    function get callbackFunctionInit()
    {
        return (m_callbackFunctionInit);
    } // End of the function
    function set callBackFunction(sValue)
    {
        this.setCallback(sValue);
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.callBackFunction());
        null;
    } // End of the function
    function get callBackFunction()
    {
        return (m_callbackFunction);
    } // End of the function
    function set callBackGetFunction(sValue)
    {
        this.setCallbackGet(sValue);
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.callBackGetFunction());
        null;
    } // End of the function
    function get callBackGetFunction()
    {
        return (m_callbackGetFunction);
    } // End of the function
    function set localizationId(nValue)
    {
        m_localizationId = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.localizationId());
        null;
    } // End of the function
    function get localizationId()
    {
        return (m_localizationId);
    } // End of the function
    function set __authorMode(nValue)
    {
        m_inAuthorMode = nValue || !dice.bf2.Logic.active();
        //return (this.__authorMode());
        null;
    } // End of the function
    function get __authorMode()
    {
        return (m_inAuthorMode);
    } // End of the function
    function set alpha(nValue)
    {
        __alpha = nValue;
        //return (this.alpha());
        null;
    } // End of the function
    function get alpha()
    {
        return (__alpha);
    } // End of the function
    function set isEnabled(nValue)
    {
        if (nValue)
        {
            this.enable();
        }
        else
        {
            m_initAlpha = _alpha;
            this.disable();
        } // end else if
        //return (this.isEnabled());
        null;
    } // End of the function
    function get isEnabled()
    {
        return (m_enabled);
    } // End of the function
    function set height(nHeight)
    {
        //return (this.height());
        null;
    } // End of the function
    function get height()
    {
        return (__height);
    } // End of the function
    function set width(nWidth)
    {
        //return (this.width());
        null;
    } // End of the function
    function get width()
    {
        return (__width);
    } // End of the function
    function setSize(nW, nH, isCalled)
    {
        m_initHeight = nH;
        m_initWidth = nW;
        _xscale = 100;
        _yscale = 100;
        __width = nW;
        __height = nH;
        if (!isCalled)
        {
            if (m_inAuthorMode)
            {
                this.authorModeUpdate();
            } // end if
        } // end if
    } // End of the function
    function setColor(mcObj, color)
    {
        var _loc1;
        _loc1 = new Color(mcObj);
        _loc1.setRGB(color);
    } // End of the function
    function mixColors(col2, col1, r)
    {
        var _loc2;
        var _loc4;
        var _loc3;
        _loc3 = (col1 & 255) - (col2 & 255);
        _loc4 = (col1 >> 8 & 255) - (col2 >> 8 & 255);
        _loc2 = (col1 >> 16 & 255) - (col2 >> 16 & 255);
        _loc3 = _loc3 * r + (col2 & 255);
        _loc4 = _loc4 * r + (col2 >> 8 & 255);
        _loc2 = _loc2 * r + (col2 >> 16 & 255);
        return ((_loc3 & 255) + ((_loc4 & 255) << 8) + ((_loc2 & 255) << 16));
    } // End of the function
    function init()
    {
        if (m_initHeight == 0 && m_initWidth == 0)
        {
            m_initHeight = _height;
            m_initWidth = _width;
        } // end if
        if (m_initAlpha == -1)
        {
            m_initAlpha = _alpha;
        } // end if
        __alpha = _alpha;
        __width = _width;
        __height = _height;
        _xscale = 100;
        _yscale = 100;
        m_glowPercentFactor = m_glowPercentFactorAuthor;
    } // End of the function
    function draw()
    {
    } // End of the function
    function attachChildren()
    {
    } // End of the function
    function arrange(inAuthorMode)
    {
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange(true);
    } // End of the function
    function setGlow(glow, glowColor)
    {
    } // End of the function
    function update()
    {
        if (m_glowEnabled)
        {
            if (m_glow == 0)
            {
                m_glowUp = true;
                m_glowPercent = 0;
                m_glowStartAlpha = _alpha;
                m_glowAlpha = m_glowStartAlpha;
            } // end if
            if (m_glowPercent >= 100)
            {
                m_glowUp = false;
                m_glowPercent = 100;
            } // end if
            if (m_glowUp)
            {
                m_glow = m_glow + m_glowFactor;
                m_glowPercent = Math.round(m_glow / m_glowStrength * 100);
                m_glowAlpha = m_glowAlpha - m_glowAlphaFactor;
            } // end if
            this.setGlow(m_glow, m_glowColor);
        }
        else if (!m_glowEnabled && m_glow > 0)
        {
            m_glow = m_glow - m_glowFactor * m_glowRemovalFactor;
            m_glowAlpha = m_glowAlpha + m_glowAlphaFactor * m_glowRemovalFactor;
            m_glowPercent = Math.round(m_glow / m_glowStrength * 100);
            this.setGlow(m_glow, m_glowColor);
        }
        else if (m_glow < 0)
        {
            m_glow = 0;
            m_glowPercentFactor = m_glowPercentFactorAuthor;
            m_glowPercent = 0;
            _alpha = m_glowStartAlpha;
        } // end else if
    } // End of the function
    function setEvents()
    {
        if (m_enabled)
        {
            function onRollOver()
            {
                this.rollOverEvent(this);
            } // End of the function
            function onRollOut()
            {
                this.rollOutEvent(this);
            } // End of the function
            function onPress()
            {
                this.pressEvent(this);
            } // End of the function
            function onRelease()
            {
                this.releaseEvent(this);
            } // End of the function
            function onReleaseOutside()
            {
                this.releaseOutsideEvent(this);
            } // End of the function
        } // end if
    } // End of the function
    function rollOverEvent()
    {
        if (m_enabled)
        {
            m_glowEnabled = true;
        } // end if
    } // End of the function
    function rollOutEvent()
    {
        if (m_enabled)
        {
            m_glowEnabled = false;
        } // end if
    } // End of the function
    function pressEvent()
    {
    } // End of the function
    function releaseEvent()
    {
    } // End of the function
    function releaseOutsideEvent()
    {
    } // End of the function
    function enable()
    {
        m_enableStatusChanged = true;
        m_enabled = true;
        m_changed = true;
        this.setEvents();
        if (m_initAlpha > 0)
        {
            _alpha = m_initAlpha;
        } // end if
    } // End of the function
    function disable()
    {
        m_enableStatusChanged = true;
        m_enabled = false;
        m_changed = true;
        this.setEvents();
        _alpha = m_disableAlpha;
    } // End of the function
    function setCallbackObject(obj)
    {
        m_callbackObject = obj;
        if (m_callbackFunctionSpecial.length > 0)
        {
            this.setCallbackObjectSpecial(obj);
        } // end if
        this.setCallbackObjectInit(obj);
    } // End of the function
    function getCallbackObject()
    {
        return (m_callbackObject);
    } // End of the function
    function setCallbackObjectInit(obj)
    {
        m_callbackObjectInit = obj;
    } // End of the function
    function getCallbackObjectInit()
    {
        return (m_callbackObjectInit);
    } // End of the function
    function setCallbackObjectSpecial(obj)
    {
        m_callbackObjectSpecial = obj;
    } // End of the function
    function getCallbackObjectSpecial()
    {
        return (m_callbackObjectSpecial);
    } // End of the function
    function setCallbackGetObject(obj)
    {
        m_callbackGetObject = obj;
    } // End of the function
    function getCallbackGetObject()
    {
        return (m_callbackGetObject);
    } // End of the function
    function setCallback(func)
    {
        if (func.length > 0)
        {
            m_callbackFunction = new String(func);
            m_callbackEnabled = true;
        } // end if
    } // End of the function
    function getCallback()
    {
        return (m_callbackFunction);
    } // End of the function
    function setCallbackInit(func)
    {
        if (func.length > 0)
        {
            m_callbackFunctionInit = new String(func);
            m_callbackInitEnabled = true;
        } // end if
    } // End of the function
    function getCallbackInit()
    {
        return (m_callbackFunctionInit);
    } // End of the function
    function setCallbackSpecial(func)
    {
        if (func.length > 0)
        {
            m_callbackFunctionSpecial = new String(func);
            m_callbackSpecialEnabled = true;
        } // end if
    } // End of the function
    function getCallbackSpecial()
    {
        return (m_callbackFunctionSpecial);
    } // End of the function
    function setCallbackGet(func)
    {
        if (func.length > 0)
        {
            m_callbackGetFunction = func;
        } // end if
    } // End of the function
    function getCallbackGet()
    {
        return (m_callbackGetFunction);
    } // End of the function
    function runCallbackInit()
    {
        if (m_callbackInitEnabled)
        {
            var _loc2 = "";
            _loc2 = this.callFunction(m_callbackObjectInit, m_callbackFunctionInit, false, true);
            m_callbackInitEnabled = false;
        } // end if
        return (_loc2);
    } // End of the function
    function runCallbackSpecial()
    {
        if (m_callbackSpecialEnabled)
        {
            this.callFunction(m_callbackObjectSpecial, m_callbackFunctionSpecial, false);
            return (true);
        } // end if
        return (false);
    } // End of the function
    function runCallbackGet()
    {
        if (m_callbackSpecialEnabled)
        {
            this.callFunction(m_callbackObjectSpecial, m_callbackFunctionSpecial, false);
            return (true);
        } // end if
        return (false);
    } // End of the function
    function runCallback()
    {
        if (m_nextCallbackIsCancelled)
        {
            m_nextCallbackIsCancelled = false;
        }
        else
        {
            if (m_callbackEnabled)
            {
                if (m_callbackFormat == 1)
                {
                    var _loc5 = Number(m_callbackGetObject[m_callbackGetFunction]());
                    this.callFunction(m_callbackObject, m_callbackFunction, _loc5);
                }
                else if (m_callbackFormat == 2)
                {
                    var _loc6 = m_callbackGetObject[m_callbackGetFunction]();
                    this.callFunction(m_callbackObject, m_callbackFunction, _loc6);
                }
                else if (m_callbackFormat == 3)
                {
                    var _loc2 = m_callbackGetObject[m_callbackGetFunction]();
                    this.callFunction(m_callbackObject, m_callbackFunction, _loc2);
                }
                else if (m_callbackFormat == 4)
                {
                    var _loc4 = m_callbackGetObject[m_callbackGetFunction]();
                    this.callFunction(m_callbackObject, m_callbackFunction, _loc4);
                }
                else
                {
                    var _loc3 = m_callbackGetObject[m_callbackGetFunction]();
                    this.callFunction(m_callbackObject, m_callbackFunction, _loc3);
                } // end else if
                return (true);
            } // end if
            return (false);
        } // end else if
    } // End of the function
    function callFunction(obj, func, arg, returnString)
    {
        var _loc6 = "";
        var _loc4 = func.split(".");
        var _loc5 = _loc4.length;
        if (_loc5 < 2)
        {
            _loc6 = obj[func](arg);
            if (returnString)
            {
                return (_loc6);
            }
            else
            {
                return;
            } // end else if
        }
        else
        {
            var _loc2 = 0;
            obj = _global;
            while (_loc2 < _loc5 - 1)
            {
                obj = obj[_loc4[_loc2]];
                ++_loc2;
            } // end while
            _loc6 = obj[_loc4[_loc2]](arg);
        } // end else if
        if (returnString)
        {
            return (_loc6);
        } // end if
    } // End of the function
    function clearCallback()
    {
        m_callbackEnabled = false;
        m_callbackSpecialEnabled = false;
        m_callbackInitEnabled = false;
    } // End of the function
    function getValue()
    {
    } // End of the function
    function setValue()
    {
    } // End of the function
    function getInitWidth()
    {
        return (m_initWidth);
    } // End of the function
    function getInitHeight()
    {
        return (m_initHeight);
    } // End of the function
    var m_updating = false;
    var m_changed = false;
    var m_enabled = true;
    var m_enableStatusChanged = false;
    var m_nextCallbackIsCancelled = false;
    var m_callbackEnabled = false;
    var m_callbackSpecialEnabled = false;
    var m_callbackInitEnabled = false;
    var m_callbackIsStaticFunction = false;
    var m_edgeThickness = 2;
    var m_edgeColor = 15251468;
    var __alpha = 100;
    var m_initWidth = 0;
    var m_initHeight = 0;
    var m_soundId = "";
    var m_UIBevelTopLeftColor = 14199040;
    var m_UIBevelBottomRightColor = 14199040;
    var m_UIBevelAlpha = 35;
    var m_UIBGColor = 4013373;
    var m_UIGlowColor = 16754953;
    var m_UIBGAlpha = 73;
    var m_UITriggerColor = 16762149;
    var m_UITriggerColorLight = 16768623;
    var m_UITriggerColorGlow = 16765756;
    var m_UITriggerColorSelected = 16777215;
    var m_UIArrowThickness = 11;
    var m_baseColor = 3355443;
    var m_baseColorSelected = 6710886;
    var m_baseTextColor = 8947848;
    var m_baseTextColorSelected = 16711680;
    var m_baseDetailColor = 14518408;
    var m_baseDetailColorSelected = 7807522;
    var m_baseDetailBGColor = 10044484;
    var m_baseDetailBGColorSelected = 5570560;
    var m_baseLineColor = 14540253;
    var m_initAlpha = -1;
    var m_disableAlpha = 50;
    var m_glowUp = false;
    var m_glow = 0;
    var m_glowEnabled = false;
    var m_glowAlphaFactor = 1.500000E-001;
    var m_glowFactor = 5.000000E-001;
    var m_glowRemovalFactor = 1.500000E+000;
    var m_glowStrength = 15;
    var m_glowColor = 16777215;
    var m_glowBackgroundEnabled = true;
    var m_glowAlphaEnabled = false;
    var m_glowPercentFactorAuthor = 6.400000E-001;
    var m_glowAlpha = 0;
} // End of Class
