class dice.UIs.Form extends dice.UI
{
    function Form(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.attachChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function init()
    {
        super.init();
    } // End of the function
    function draw()
    {
    } // End of the function
    function attachChildren()
    {
    } // End of the function
    function arrange(inAuthorMode)
    {
    } // End of the function
    function setEvents()
    {
        super.setEvents();
    } // End of the function
    function rollOverEvent()
    {
        super.rollOverEvent();
    } // End of the function
    function rollOutEvent()
    {
        super.rollOutEvent();
    } // End of the function
    function pressEvent()
    {
        super.pressEvent();
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange(true);
    } // End of the function
    function setGlow(glow, glowColor)
    {
    } // End of the function
    function update()
    {
        super.update();
    } // End of the function
    function enable()
    {
        super.enable();
    } // End of the function
    function disable()
    {
        super.disable();
    } // End of the function
} // End of Class
