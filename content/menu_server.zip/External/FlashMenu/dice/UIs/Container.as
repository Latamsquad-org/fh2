class dice.UIs.Container extends dice.UI
{
    var m_containerBGEnabled, __get__containerBGEnabled, m_BGColor, m_inAuthorMode, __get__backgroundColor, m_attachedContentId, __get__contentMovieClipId, mcBoundingBox, getNextHighestDepth, createEmptyMovieClip, m_mcContainerMask, m_mcContainerBG, m_mcContainerBGBevel, m_mcContainer, setColor, m_contentWidth, m_contentHeight, m_updating, m_changed, m_containerHeight, m_initHeight, m_containerWidth, m_contentInternalScrollCallBackObject, __set__backgroundColor, __set__containerBGEnabled, __set__contentMovieClipId;
    function Container(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.attachChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set containerBGEnabled(nValue)
    {
        m_containerBGEnabled = nValue;
        //return (this.containerBGEnabled());
        null;
    } // End of the function
    function get containerBGEnabled()
    {
        return (m_containerBGEnabled);
    } // End of the function
    function set backgroundColor(nValue)
    {
        m_BGColor = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.backgroundColor());
        null;
    } // End of the function
    function get backgroundColor()
    {
        return (m_BGColor);
    } // End of the function
    function set contentMovieClipId(nValue)
    {
        m_attachedContentId = nValue;
        //return (this.contentMovieClipId());
        null;
    } // End of the function
    function get contentMovieClipId()
    {
        return (m_attachedContentId);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
        } // end if
    } // End of the function
    function draw()
    {
        this.m_bottomDepth = this.getNextHighestDepth();
        this.createEmptyMovieClip("m_mcContainerMask", this.getNextHighestDepth());
        if (this.m_mcContainerMask)
        {
            with (this.m_mcContainerMask)
            {
                lineStyle(0, 255, 0);
                beginFill(255, 100);
                moveTo(0, 0);
                lineTo(50, 0);
                lineTo(50, 50);
                lineTo(0, 50);
                endFill();
            } // End of with
        } // end if
        this.createEmptyMovieClip("m_mcContainerBG", this.getNextHighestDepth());
        if (this.m_mcContainerBG)
        {
            with (this.m_mcContainerBG)
            {
                lineStyle(0, 255, 0);
                beginFill(255, 100);
                moveTo(0, 0);
                lineTo(50, 0);
                lineTo(50, 50);
                lineTo(0, 50);
                endFill();
            } // End of with
        } // end if
        this.createEmptyMovieClip("m_mcContainerBGBevel", this.getNextHighestDepth());
        with (this.m_mcContainerBGBevel)
        {
            lineStyle(0, _parent.m_sliderBevelTopLeftColor, _parent.m_sliderBevelAlpha);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelBottomRightColor, _parent.m_sliderBevelAlpha);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcContainer", this.getNextHighestDepth());
        if (this.m_mcContainer)
        {
            with (this.m_mcContainer)
            {
                createEmptyMovieClip("authBox", getNextHighestDepth());
                with (authBox)
                {
                    lineStyle(0, 14594928, 0);
                    beginFill(14594928, 100);
                    moveTo(0, 0);
                    lineTo(5, 0);
                    lineTo(5, 5);
                    lineTo(0, 5);
                    endFill();
                } // End of with
                createEmptyMovieClip("contents", getNextHighestDepth());
            } // End of with
        } // end if
    } // End of the function
    function attachChildren()
    {
    } // End of the function
    function arrange(inAuthorMode)
    {
        if (this.m_mcContainer)
        {
            with (this.m_mcContainer)
            {
                _x = 0;
                _y = 0;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
                m_containerHeight = _parent.m_initHeight;
                m_containerWidth = _parent.m_initWidth;
            } // End of with
        } // end if
        if (this.m_mcContainerBG)
        {
            with (this.m_mcContainerBG)
            {
                _x = 0;
                _y = 0;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
                if (!_parent.m_containerBGEnabled)
                {
                    _visible = false;
                } // end if
            } // End of with
        } // end if
        this.setColor(this.m_mcContainerBG, this.m_BGColor);
        if (this.m_mcContainerBGBevel)
        {
            with (this.m_mcContainerBGBevel)
            {
                _x = _parent.m_mcContainerBG._x;
                _y = _parent.m_mcContainerBG._y;
                _width = _parent.m_mcContainerBG._width;
                _height = _parent.m_mcContainerBG._height;
                if (!_parent.m_containerBGEnabled)
                {
                    _visible = false;
                } // end if
            } // End of with
        } // end if
        if (this.m_mcContainerMask)
        {
            with (this.m_mcContainerMask)
            {
                _x = 0;
                _y = 0;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
                _alpha = 0;
            } // End of with
        } // end if
        this.m_mcContainer.authBox._visible = false;
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange(true);
        m_mcContainer.authBox._visible = true;
    } // End of the function
    function update()
    {
        super.update();
        if (!m_hasAttachedMc)
        {
            m_hasAttachedMc = true;
            this.setContent();
        } // end if
        if (m_mcContainer.contents.update())
        {
            var _loc4 = m_mcContainer.contents.contentWidth;
            var _loc3 = m_mcContainer.contents.contentHeight;
            if (_loc4 > 0 && _loc3 > 0 && !m_contentInternalScroll)
            {
                if (m_contentWidth != _loc4 && m_contentHeight != _loc3)
                {
                    trace ("setting content from columnlist.. not used!");
                    this.setContentSize(_loc4, _loc3);
                } // end if
            } // end if
        } // end if
    } // End of the function
    function setEvents()
    {
    } // End of the function
    function setContent(isAuthorMode)
    {
        if (this.m_mcContainer)
        {
            if (this.m_mcContainer.contents)
            {
                this.m_mcContainer.contents.removeMovieClip();
            } // end if
            if (this.m_attachedContentId.length > 0)
            {
                this.m_mcContainer._xscale = 100;
                this.m_mcContainer._yscale = 100;
                this.m_mcContainer.attachMovie(this.m_attachedContentId, "contents", this.m_mcContainer.getNextHighestDepth());
                this.m_mcContainer.authBox._visible = false;
                this.m_mcContainer.setMask(this.m_mcContainerMask);
                if (this.m_mcContainer)
                {
                    this.m_updating = false;
                    with (this.m_mcContainer)
                    {
                        _xscale = 100;
                        _yscale = 100;
                        if (contents)
                        {
                            with (contents)
                            {
                                _xscale = 100;
                                _yscale = 100;
                                if (!_parent._parent.m_contentInternalScroll)
                                {
                                    _parent._parent.setContentSize(_width, _height, 0);
                                } // end if
                            } // End of with
                        } // end if
                    } // End of with
                } // end if
                this.m_changed = true;
                this.m_hasAttachedMc = true;
            } // end if
        } // end if
    } // End of the function
    function setContentSize(width, height, shownHeight)
    {
        if (shownHeight > 0)
        {
            if (m_containerHeight < height)
            {
                var _loc2 = m_initHeight - m_contentOffsetY - shownHeight;
            }
            else
            {
                _loc2 = 0;
            } // end else if
        }
        else
        {
            _loc2 = 0;
        } // end else if
        m_contentWidth = width;
        m_contentHeight = height;
        if (shownHeight > 0 && _loc2 > 0)
        {
            m_contentHeight = height + _loc2;
        } // end if
        this.update();
    } // End of the function
    function setValue(sValue)
    {
        m_attachedContentId = sValue;
        this.setContent();
    } // End of the function
    function getValue()
    {
        return (this.getContentMc());
    } // End of the function
    function setContainerSize(width, height, x, y)
    {
        if (this.m_mcContainerMask)
        {
            with (this.m_mcContainerMask)
            {
                _width = width;
                _height = height;
                if (x)
                {
                    _x = x;
                } // end if
                if (y)
                {
                    _y = y;
                } // end if
            } // End of with
        } // end if
        this.m_containerHeight = height;
        this.m_containerWidth = width;
    } // End of the function
    function setContentPlacement(x, y)
    {
        if (x != this.m_x || y != this.m_y)
        {
            if (this.m_mcContainer)
            {
                with (this.m_mcContainer)
                {
                    _x = x;
                    _y = y;
                } // End of with
            } // end if
            this.m_x = x;
            this.m_y = y;
            this.m_changed = true;
        } // end if
    } // End of the function
    function setContentId(newContentId)
    {
        m_attachedContentId = newContentId;
        m_changed = true;
        this.setContent();
    } // End of the function
    function getContentMc()
    {
        return (m_mcContainer.contents);
    } // End of the function
    function enable()
    {
        super.enable();
    } // End of the function
    function disable()
    {
        super.disable();
    } // End of the function
    function getContentHeight()
    {
        return (m_contentHeight);
    } // End of the function
    function getContentWidth()
    {
        return (m_contentWidth);
    } // End of the function
    function setInternalScrollCallback(obj, func, offsetY, offsetX)
    {
        m_contentInternalScroll = true;
        m_contentInternalScrollCallBackObject = obj;
        m_contentInternalScrollCallBack = func;
        m_contentInternalScrollOffsetYCallback = offsetY;
        m_contentInternalScrollOffsetXCallback = offsetX;
    } // End of the function
    var m_sliderBevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_sliderBevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_sliderBevelAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_bottomDepth = -1;
    var m_contentInternalScrollCallBack = "";
    var m_contentInternalScrollOffsetYCallback = "";
    var m_contentInternalScrollOffsetY = 0;
    var m_oldContentInternalScrollOffsetY = -1;
    var m_contentInternalScrollOffsetXCallback = "";
    var m_contentInternalScrollOffsetX = 0;
    var m_oldContentInternalScrollOffsetX = -1;
    var m_contentInternalScroll = false;
    var m_hasAttachedMc = false;
    var m_x = -1;
    var m_y = -1;
    var m_contentOffsetY = 0;
    var m_contentOffsetX = 0;
} // End of Class
