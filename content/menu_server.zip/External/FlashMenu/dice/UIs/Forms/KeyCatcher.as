class dice.UIs.Forms.KeyCatcher extends dice.UIs.Form
{
    var m_groupRoot, m_keyId, _parent, m_isCommon, m_inAuthorMode, __get__isCommon, m_negative, __get__keyIsNegatoryKey, __get__keyIsSecondary, __get__groupRoot, __get__keyId, m_stringValuePress, __get__stringValuePress, mcBoundingBox, getNextHighestDepth, createEmptyMovieClip, m_mcKeyCatcherBG, attachMovie, m_mcKeyDescription, setColor, __alpha, _alpha, m_enabled, __set__groupRoot, __set__isCommon, __set__keyId, __set__keyIsNegatoryKey, __set__keyIsSecondary, __set__stringValuePress;
    function KeyCatcher(cancelInit)
    {
        super(true);
        if (m_groupRoot.length > 0)
        {
            if (!this[m_groupRoot]._parent[m_keyId])
            {
                this[m_groupRoot]._parent[m_keyId] = new Array();
            } // end if
            this[m_groupRoot]._parent[m_keyId].push(this);
        }
        else
        {
            if (!_parent[m_keyId])
            {
                _parent[m_keyId] = new Array();
            } // end if
            _parent[m_keyId].push(this);
        } // end else if
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set isCommon(sValue)
    {
        m_isCommon = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.isCommon());
        null;
    } // End of the function
    function get isCommon()
    {
        return (m_isCommon);
    } // End of the function
    function set keyIsNegatoryKey(sValue)
    {
        m_negative = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.keyIsNegatoryKey());
        null;
    } // End of the function
    function get keyIsNegatoryKey()
    {
        return (m_negative);
    } // End of the function
    function set keyIsSecondary(sValue)
    {
        m_secondary = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.keyIsSecondary());
        null;
    } // End of the function
    function get keyIsSecondary()
    {
        return (m_secondary);
    } // End of the function
    function set groupRoot(sValue)
    {
        m_groupRoot = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.groupRoot());
        null;
    } // End of the function
    function get groupRoot()
    {
        return (m_groupRoot);
    } // End of the function
    function set keyId(sValue)
    {
        m_keyId = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.keyId());
        null;
    } // End of the function
    function get keyId()
    {
        return (m_keyId);
    } // End of the function
    function set stringValuePress(sValue)
    {
        m_stringValuePress = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.stringValuePress());
        null;
    } // End of the function
    function get stringValuePress()
    {
        return (m_stringValuePress);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcKeyCatcherBG", this.getNextHighestDepth());
        with (this.m_mcKeyCatcherBG)
        {
            lineStyle(0, _parent.m_baseColor, 0);
            beginFill(_parent.m_baseColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
    } // End of the function
    function createChildren()
    {
        this.attachMovie("mcKeyCatcher", "m_mcKeyDescription", this.getNextHighestDepth());
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_mcKeyDescription)
        {
            with (this.m_mcKeyDescription)
            {
                with (keyCatcherField)
                {
                    textColor = _parent._parent.m_edgeColor;
                    _width = _parent._parent.m_initWidth;
                    _height = _parent._parent.m_initHeight;
                    password = _parent._parent.m_inputPassword;
                } // End of with
                _x = 0;
                _y = 0;
            } // End of with
        } // end if
        if (this.m_mcKeyCatcherBG)
        {
            with (this.m_mcKeyCatcherBG)
            {
                _y = 0;
                _x = 0;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
            } // End of with
        } // end if
        this.setColor(this.m_mcKeyCatcherBG, this.m_keyCatcherColor);
        this._alpha = this.__alpha;
        dice.bf2.ControlSettings.setActiveControlMap(_root.activeControlMap.toString());
        if (this.m_isCommon)
        {
            dice.bf2.ControlSettings.setActiveControlMap("5");
        } // end if
        var tempString = dice.bf2.ControlSettings.getMappedString(this.m_keyId, this.m_secondary, this.m_negative);
        this.setTextValue(tempString);
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function update()
    {
        var _loc2 = false;
        if (super.update())
        {
            _loc2 = true;
        } // end if
        return (_loc2);
    } // End of the function
    function keySet(listArray)
    {
        for (var _loc3 = 1; _loc3 < listArray.length; ++_loc3)
        {
            for (var _loc2 = 1; _loc2 < listArray[_loc3].length; ++_loc2)
            {
                var _loc4 = listArray[_loc3][_loc2];
                this.setTextValue(_loc4);
                stringValue = _loc4;
                m_enabled = true;
                m_inCatchState = false;
            } // end of for
        } // end of for
    } // End of the function
    function setTextValue(textString)
    {
        m_mcKeyDescription.keyCatcherField.text = textString;
    } // End of the function
    function selectKeyCatcher(deSelect)
    {
        if (deSelect)
        {
            this.setColor(m_mcKeyCatcherBG, m_keyCatcherColor);
        }
        else
        {
            this.setColor(m_mcKeyCatcherBG, m_keyCatcherColorSelected);
        } // end else if
    } // End of the function
    function setEvents()
    {
        function onPress()
        {
            if (!m_inCatchState)
            {
                this.selectKeyCatcher(false);
            } // end if
        } // End of the function
        function onRelease()
        {
            if (!m_inCatchState)
            {
                this.pressEvent(this);
            } // end if
        } // End of the function
    } // End of the function
    function pressEvent(currentComponent)
    {
        if (currentComponent.m_inCatchState)
        {
        }
        else
        {
            m_enabled = false;
            dice.bf2.ControlSettings.setActiveControlMap(_root.activeControlMap.toString());
            if (m_isCommon)
            {
                dice.bf2.ControlSettings.setActiveControlMap("5");
            } // end if
            var _loc7 = dice.bf2.ControlSettings.mapInput(m_keyId, m_secondary, m_negative, m_isCommon);
            if (m_groupRoot.length > 0)
            {
                var _loc6 = this[m_groupRoot]._parent[m_keyId];
            }
            else
            {
                _loc6 = _parent[m_keyId];
            } // end else if
            if (_loc6)
            {
                for (var _loc4 = 0; _loc4 < _loc6.length; ++_loc4)
                {
                    var _loc3 = _loc6[_loc4];
                    var _loc5;
                    _loc3.m_enabled = true;
                    _loc3.m_inCatchState = false;
                    dice.bf2.ControlSettings.setActiveControlMap(_root.activeControlMap.toString());
                    if (_loc3.m_isCommon)
                    {
                        dice.bf2.ControlSettings.setActiveControlMap("5");
                    } // end if
                    _loc5 = dice.bf2.ControlSettings.getMappedString(_loc3.m_keyId, _loc3.m_secondary, _loc3.m_negative);
                    _loc3.setTextValue(_loc5);
                    _loc3.selectKeyCatcher(true);
                } // end of for
            } // end if
        } // end else if
    } // End of the function
    var m_keyCatcherColor = 6710886;
    var m_keyCatcherColorSelected = 10066329;
    var stringValue = "";
    var m_inCatchState = false;
    var m_secondary = true;
} // End of Class
