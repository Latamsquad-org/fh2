class dice.UIs.Forms.SortButton extends dice.UIs.Form
{
    var _parent, m_sortType, __get__sortType, __get__sortId, __get__groupId, m_inAuthorMode, __get__initialSorting, m_labelFontCharPixelWidth, __get__labelFontCharPixelWidth, m_iconXOffset, __get__iconXOffset, m_iconYOffset, __get__iconYOffset, m_labelXOffset, __get__labelXOffset, m_labelYOffset, __get__labelYOffset, m_labelColor, __get__labelColor, m_labelLength, m_label, __get__label, mcBoundingBox, setCallbackObject, setCallbackGetObject, getNextHighestDepth, createEmptyMovieClip, m_mcSortButtonBG, attachMovie, m_mcSortArrowDesc, m_mcSortArrowAsc, m_localizationId, m_mcLabel, m_btSpecial, m_edgeColor, setColor, m_glowAlphaFactor, runCallback, __set__groupId, __set__iconXOffset, __set__iconYOffset, __set__initialSorting, __set__label, __set__labelColor, __set__labelFontCharPixelWidth, __set__labelXOffset, __set__labelYOffset, __set__sortId, __set__sortType;
    function SortButton(cancelInit)
    {
        super(true);
        if (!_parent[identifier])
        {
            _parent[identifier] = new Array();
        } // end if
        _parent[identifier].push(this);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set sortType(nValue)
    {
        m_sortType = nValue;
        //return (this.sortType());
        null;
    } // End of the function
    function get sortType()
    {
        return (m_sortType);
    } // End of the function
    function set sortId(nValue)
    {
        m_sortId = nValue;
        //return (this.sortId());
        null;
    } // End of the function
    function get sortId()
    {
        return (m_sortId);
    } // End of the function
    function set groupId(nValue)
    {
        identifier = nValue;
        //return (this.groupId());
        null;
    } // End of the function
    function get groupId()
    {
        return (identifier);
    } // End of the function
    function set initialSorting(nValue)
    {
        sorting = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.initialSorting());
        null;
    } // End of the function
    function get initialSorting()
    {
        return (sorting);
    } // End of the function
    function set labelFontCharPixelWidth(nValue)
    {
        m_labelFontCharPixelWidth = nValue;
        //return (this.labelFontCharPixelWidth());
        null;
    } // End of the function
    function get labelFontCharPixelWidth()
    {
        return (m_labelFontCharPixelWidth);
    } // End of the function
    function set iconXOffset(Value)
    {
        m_iconXOffset = Value;
        //return (this.iconXOffset());
        null;
    } // End of the function
    function get iconXOffset()
    {
        return (m_iconXOffset);
    } // End of the function
    function set iconYOffset(Value)
    {
        m_iconYOffset = Value;
        //return (this.iconYOffset());
        null;
    } // End of the function
    function get iconYOffset()
    {
        return (m_iconYOffset);
    } // End of the function
    function set labelXOffset(Value)
    {
        m_labelXOffset = Value;
        //return (this.labelXOffset());
        null;
    } // End of the function
    function get labelXOffset()
    {
        return (m_labelXOffset);
    } // End of the function
    function set labelYOffset(Value)
    {
        m_labelYOffset = Value;
        //return (this.labelYOffset());
        null;
    } // End of the function
    function get labelYOffset()
    {
        return (m_labelYOffset);
    } // End of the function
    function set labelColor(nValue)
    {
        m_labelColor = nValue;
        //return (this.labelColor());
        null;
    } // End of the function
    function get labelColor()
    {
        return (m_labelColor);
    } // End of the function
    function set label(sValue)
    {
        var _loc2 = new String(sValue);
        m_labelLength = _loc2.length;
        m_label = sValue;
        //return (this.label());
        null;
    } // End of the function
    function get label()
    {
        return (m_label);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        this.setCallbackObject(_parent);
        this.setCallbackGetObject(this);
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcSortButtonBG", this.getNextHighestDepth());
        with (this.m_mcSortButtonBG)
        {
            lineStyle(0, _parent.m_buttonBGColor, 0);
            beginFill(_parent.m_buttonBGColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
    } // End of the function
    function createChildren()
    {
        this.attachMovie("sortArrowAsc", "m_mcSortArrowAsc", this.getNextHighestDepth());
        this.attachMovie("sortArrowDesc", "m_mcSortArrowDesc", this.getNextHighestDepth());
        if (!m_inAuthorMode)
        {
            m_mcSortArrowDesc.loadMovie("images/components/sortArrow_down.png");
            m_mcSortArrowAsc.loadMovie("images/components/sortArrow_up.png");
        } // end if
        this.attachMovie("mcSortButtonLabelSmall", "m_mcLabel", this.getNextHighestDepth());
        if (m_localizationId.length > 0)
        {
            mx.lang.Locale.addDelayedInstance(m_mcLabel.labelRadio, m_localizationId);
        } // end if
        this.attachMovie("btSortbuttonSpecial", "m_btSpecial", this.getNextHighestDepth());
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_btSpecial)
        {
            with (this.m_btSpecial)
            {
                _x = 0;
                _y = 0;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
                _alpha = 0;
            } // End of with
        } // end if
        if (this.m_mcSortButtonBG)
        {
            with (this.m_mcSortButtonBG)
            {
                _width = _parent.m_initHeight;
                _height = _parent.m_initHeight;
                _x = _parent.m_initWidth - _parent.m_initHeight;
                _y = 0;
                _alpha = 0;
            } // End of with
        } // end if
        if (this.m_mcSortArrowAsc)
        {
            with (this.m_mcSortArrowAsc)
            {
                _width = _parent.m_UIArrowThickness;
                _height = _parent.m_UIArrowThickness;
                _x = _parent.m_initWidth - _parent.m_initHeight + (_parent.m_initHeight / 2 - _parent.m_UIArrowThickness / 2) + 2;
                _y = _parent.m_initHeight / 2 - _parent.m_UIArrowThickness / 2;
                _alpha = 20;
            } // End of with
        } // end if
        if (this.m_mcSortArrowDesc)
        {
            with (this.m_mcSortArrowDesc)
            {
                _width = _parent.m_UIArrowThickness;
                _height = _parent.m_UIArrowThickness;
                _x = _parent.m_initWidth - _parent.m_initHeight + (_parent.m_initHeight / 2 - _parent.m_UIArrowThickness / 2) + 2;
                _y = _parent.m_initHeight / 2 - _parent.m_UIArrowThickness / 2;
                _alpha = 0;
            } // End of with
        } // end if
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                _x = 0;
                _y = _parent.m_initHeight / 2 - labelRadio._height / 2;
                if (labelRadio)
                {
                    with (labelRadio)
                    {
                        if (_parent._parent.m_localizationId.length > 0)
                        {
                            text = _parent._parent.m_localizationId;
                        }
                        else
                        {
                            text = _parent._parent.m_label;
                        } // end else if
                        _width = _parent._parent.m_initWidth - _parent._parent.m_initHeight;
                        textColor = _parent._parent.m_labelColor;
                        _x = 0;
                        _y = 0;
                    } // End of with
                } // end if
            } // End of with
        } // end if
        this.toggleCheck(this.sorting);
        if (this.m_inAuthorMode)
        {
            this.setColor(this.m_mcSortArrowAsc, this.m_edgeColor);
            this.setColor(this.m_mcSortArrowDesc, this.m_edgeColor);
        } // end if
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function update()
    {
        super.update();
        if (m_activateSortArrow)
        {
            if (sorting == 1)
            {
                var _loc3 = m_mcSortArrowAsc._alpha;
                m_mcSortArrowAsc._alpha = _loc3 + m_glowAlphaFactor;
                _loc3 = m_mcSortArrowDesc._alpha;
                if (_loc3 > 0)
                {
                    m_mcSortArrowDesc._alpha = _loc3 - m_glowAlphaFactor;
                } // end if
                if (m_mcSortArrowAsc._alpha >= 100)
                {
                    m_mcSortArrowAsc._alpha = 100;
                    m_activateSortArrow = false;
                } // end if
            }
            else if (sorting == 2)
            {
                _loc3 = m_mcSortArrowDesc._alpha;
                m_mcSortArrowDesc._alpha = _loc3 + m_glowAlphaFactor;
                _loc3 = m_mcSortArrowAsc._alpha;
                if (_loc3 > 0)
                {
                    m_mcSortArrowAsc._alpha = _loc3 - m_glowAlphaFactor;
                } // end if
                if (m_mcSortArrowDesc._alpha >= 100)
                {
                    m_mcSortArrowDesc._alpha = 100;
                    m_activateSortArrow = false;
                } // end if
            } // end if
        } // end else if
        return (m_activateSortArrow);
    } // End of the function
    function setEvents()
    {
        super.setEvents();
        function onPress()
        {
            dice.bf2.Sound.playSound("sortPress");
            if (sorting > 0)
            {
                if (sorting == 1)
                {
                    this.toggleCheck(2);
                }
                else
                {
                    this.toggleCheck(1);
                } // end else if
            }
            else
            {
                this.toggleCheck(1);
            } // end else if
        } // End of the function
    } // End of the function
    function toggleCheck(overRide)
    {
        if (overRide > 0)
        {
            var _loc3 = _parent[identifier];
            if (_loc3)
            {
                for (var _loc4 in _loc3)
                {
                    var _loc2 = _loc3[_loc4];
                    if (_loc2 != this)
                    {
                        _loc2.toggleCheck(0);
                    } // end if
                } // end of for...in
            } // end if
            if (overRide == 2)
            {
                sorting = 2;
                m_mcSortArrowDesc._alpha = 100;
                m_mcSortArrowAsc._alpha = 0;
            }
            else
            {
                sorting = 1;
                m_mcSortArrowAsc._alpha = 100;
                m_mcSortArrowDesc._alpha = 0;
            } // end else if
        }
        else if (overRide == 0)
        {
            sorting = 0;
            m_mcSortArrowAsc._alpha = 20;
            m_mcSortArrowDesc._alpha = 0;
        } // end else if
        trace ("sort should run callback below..");
        this.runCallback();
        return (sorting);
    } // End of the function
    function updateManager()
    {
        return (this.update());
    } // End of the function
    function getValue()
    {
        var _loc2 = new Object();
        _loc2.sorting = sorting;
        _loc2.sortType = m_sortType;
        _loc2.id = m_sortId;
        _loc2.groupid = identifier;
        return (_loc2);
    } // End of the function
    function setValue(newSort)
    {
        this.toggleCheck(newSort);
    } // End of the function
    var m_buttonBGColor = 10066329;
    var m_mcSortArrowColor = 16777215;
    var m_buttonBGAlpha = 70;
    var sorting = 0;
    var identifier = "";
    var m_sortId = "";
    var m_activateSortArrow = false;
} // End of Class
