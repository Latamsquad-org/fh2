class dice.UIs.Forms.ToggleField extends dice.UIs.Form
{
    var m_inAuthorMode, m_useImage, __get__useImage, m_useLargeFont, __get__useLargeFont, m_arrowSizeMod, __get__arrowSizeMod, __get__listLinkageId, m_labelValue, __get__startLabel, m_labelMarginWidth, __get__labelMarginWidth, m_labelMarginHeight, __get__labelMarginHeight, m_labelX, __get__labelXOffset, m_labelY, __get__labelYOffset, mcBoundingBox, m_soundId, _parent, setCallbackObject, setCallbackGetObject, g_listObject, m_callbackFrequency, getNextHighestDepth, createEmptyMovieClip, m_mcLabelBG, m_mcArrowLeftBG, m_mcArrowRightBG, m_mcButtonLeftEdge, m_mcLabelBGEdge, m_mcButtonLeftEdgeInverted, m_mcButtonLeftEdgeDisabled, m_mcButtonRightEdge, m_mcButtonRightEdgeInverted, m_mcButtonRightEdgeDisabled, m_mcLabel, attachMovie, m_mcArrowLeft, m_mcArrowRight, m_mcArrowLeftInverted, m_mcArrowRightInverted, runCallback, runCallbackSpecial, m_updating, m_object, setColor, __set__arrowSizeMod, __set__labelMarginHeight, __set__labelMarginWidth, __set__labelXOffset, __set__labelYOffset, __set__listLinkageId, __set__startLabel, __set__useImage, __set__useLargeFont;
    function ToggleField(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
            this.initList();
            if (m_inAuthorMode)
            {
                this.fakeListCallback();
            } // end if
        } // end if
    } // End of the function
    function set useImage(nValue)
    {
        m_useImage = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.useImage());
        null;
    } // End of the function
    function get useImage()
    {
        return (m_useImage);
    } // End of the function
    function set useLargeFont(nValue)
    {
        m_useLargeFont = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.useLargeFont());
        null;
    } // End of the function
    function get useLargeFont()
    {
        return (m_useLargeFont);
    } // End of the function
    function set arrowSizeMod(nValue)
    {
        m_arrowSizeMod = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.arrowSizeMod());
        null;
    } // End of the function
    function get arrowSizeMod()
    {
        return (m_arrowSizeMod);
    } // End of the function
    function set listLinkageId(Value)
    {
        m_listId = Value;
        //return (this.listLinkageId());
        null;
    } // End of the function
    function get listLinkageId()
    {
        return (m_listId);
    } // End of the function
    function set startLabel(nValue)
    {
        m_labelValue = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.startLabel());
        null;
    } // End of the function
    function get startLabel()
    {
        return (m_labelValue);
    } // End of the function
    function set labelMarginWidth(Value)
    {
        m_labelMarginWidth = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelMarginWidth());
        null;
    } // End of the function
    function get labelMarginWidth()
    {
        return (m_labelMarginWidth);
    } // End of the function
    function set labelMarginHeight(Value)
    {
        m_labelMarginHeight = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelMarginHeight());
        null;
    } // End of the function
    function get labelMarginHeight()
    {
        return (m_labelMarginHeight);
    } // End of the function
    function set labelXOffset(Value)
    {
        m_labelX = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelXOffset());
        null;
    } // End of the function
    function get labelXOffset()
    {
        return (m_labelX);
    } // End of the function
    function set labelYOffset(Value)
    {
        m_labelY = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelYOffset());
        null;
    } // End of the function
    function get labelYOffset()
    {
        return (m_labelY);
    } // End of the function
    function fakeListCallback()
    {
        var _loc3 = new Array();
        _loc3[0] = new Object();
        _loc3[0].id = "testid";
        var _loc2 = new Array();
        _loc2[0] = new Object();
        _loc2[0].gamespy = 1;
        _loc2[0].disabled = 0;
        _loc2[0].id = 666;
        _loc2[0].selected = true;
        _loc2[0].nick = "kalle";
        _loc2[0].kitId = "us_specops";
        _loc2[1] = "profileName";
        _loc3.push(_loc2);
        m_currentToggleList = _loc3;
        this.setList(m_currentToggleList);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        if (m_soundId.length == 0)
        {
            m_soundId = "toggleFieldPress";
        } // end if
        this.setCallbackObject(_parent);
        this.setCallbackGetObject(this);
        this.update();
    } // End of the function
    function initList()
    {
        g_listObject = new dice.lists.List(m_listId, 0, -1);
        g_listObject.setCallback(this, "setList");
        _root.updateManager1.registerCallback(this, "updateManager", m_callbackFrequency);
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcLabelBG", this.getNextHighestDepth());
        with (this.m_mcLabelBG)
        {
            lineStyle(0, _parent.m_fieldBGColor, 0);
            beginFill(_parent.m_fieldBGColor, _parent.m_BGAlpha);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcArrowLeftBG", this.getNextHighestDepth());
        with (this.m_mcArrowLeftBG)
        {
            lineStyle(0, _parent.m_scrollArrowBGColor, 0);
            beginFill(_parent.m_scrollArrowBGColor, _parent.m_BGAlpha);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcArrowRightBG", this.getNextHighestDepth());
        with (this.m_mcArrowRightBG)
        {
            lineStyle(0, _parent.m_scrollArrowBGColor, 0);
            beginFill(_parent.m_scrollArrowBGColor, _parent.m_BGAlpha);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcButtonLeftEdge", this.getNextHighestDepth());
        with (this.m_mcButtonLeftEdge)
        {
            lineStyle(0, _parent.m_sliderBevelTopLeftColor, _parent.m_bevelAlpha);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelBottomRightColor, _parent.m_bevelAlpha);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcLabelBGEdge", this.getNextHighestDepth());
        with (this.m_mcLabelBGEdge)
        {
            lineStyle(0, _parent.m_sliderBevelTopLeftColor, _parent.m_bevelAlpha);
            moveTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelBottomRightColor, _parent.m_bevelAlpha);
            moveTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcButtonLeftEdgeInverted", this.getNextHighestDepth());
        with (this.m_mcButtonLeftEdgeInverted)
        {
            lineStyle(0, _parent.m_sliderBevelBottomRightColor, _parent.m_bevelAlpha);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelTopLeftColor, _parent.m_bevelAlpha);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcButtonLeftEdgeDisabled", this.getNextHighestDepth());
        with (this.m_mcButtonLeftEdgeDisabled)
        {
            lineStyle(0, _parent.m_sliderDisabledBevelTopLeftColor, _parent.m_bevelAlpha);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderDisabledBevelBottomRightColor, _parent.m_bevelAlpha);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcButtonRightEdge", this.getNextHighestDepth());
        with (this.m_mcButtonRightEdge)
        {
            lineStyle(0, _parent.m_sliderBevelTopLeftColor, _parent.m_bevelAlpha);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelBottomRightColor, _parent.m_bevelAlpha);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcButtonRightEdgeInverted", this.getNextHighestDepth());
        with (this.m_mcButtonRightEdgeInverted)
        {
            lineStyle(0, _parent.m_sliderBevelBottomRightColor, _parent.m_bevelAlpha);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelTopLeftColor, _parent.m_bevelAlpha);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcButtonRightEdgeDisabled", this.getNextHighestDepth());
        with (this.m_mcButtonRightEdgeDisabled)
        {
            lineStyle(0, _parent.m_sliderDisabledBevelTopLeftColor, _parent.m_bevelAlpha);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderDisabledBevelBottomRightColor, _parent.m_bevelAlpha);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
    } // End of the function
    function createChildren()
    {
        if (m_mcLabel)
        {
            m_mcLabel.removeMovieClip();
        } // end if
        if (m_useLargeFont)
        {
            this.attachMovie("mcToggleFieldLabelLarge", "m_mcLabel", this.getNextHighestDepth());
        }
        else
        {
            this.attachMovie("mcToggleFieldLabel", "m_mcLabel", this.getNextHighestDepth());
        } // end else if
        this.attachMovie("toggleFieldArrowLeft", "m_mcArrowLeft", this.getNextHighestDepth());
        this.attachMovie("toggleFieldArrowRight", "m_mcArrowRight", this.getNextHighestDepth());
        this.attachMovie("toggleFieldArrowLeftInverted", "m_mcArrowLeftInverted", this.getNextHighestDepth());
        this.attachMovie("toggleFieldArrowRightInverted", "m_mcArrowRightInverted", this.getNextHighestDepth());
        if (!m_inAuthorMode)
        {
            m_mcArrowLeft.loadMovie("images/components/scrollArrow_left.png");
            m_mcArrowRight.loadMovie("images/components/scrollArrow_right.png");
            m_mcArrowLeft.loadMovie("images/components/scrollArrow_leftInverted.png");
            m_mcArrowRight.loadMovie("images/components/scrollArrow_rightInverted.png");
        } // end if
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_mcArrowLeftBG)
        {
            with (this.m_mcArrowLeftBG)
            {
                _width = _parent.m_initHeight;
                _height = _parent.m_initHeight;
                _x = 0;
                _y = 0;
            } // End of with
        } // end if
        if (this.m_mcArrowLeft)
        {
            with (this.m_mcArrowLeft)
            {
                _x = _parent.m_initHeight / 2 - _parent.m_UIArrowThickness / 2;
                _y = _parent.m_initHeight / 2 - _parent.m_UIArrowThickness / 2;
                _width = _parent.m_UIArrowThickness;
                _height = _parent.m_UIArrowThickness;
            } // End of with
        } // end if
        if (this.m_mcArrowLeftInverted)
        {
            with (this.m_mcArrowLeftInverted)
            {
                _x = _parent.m_mcArrowLeft._x;
                _y = _parent.m_mcArrowLeft._y;
                _width = _parent.m_mcArrowLeft._width;
                _height = _parent.m_mcArrowLeft._height;
                _visible = false;
            } // End of with
        } // end if
        if (this.m_mcArrowRightBG)
        {
            with (this.m_mcArrowRightBG)
            {
                _width = _parent.m_initHeight;
                _height = _parent.m_initHeight;
                _x = _parent.m_initWidth - _parent.m_initHeight;
                _y = 0;
            } // End of with
        } // end if
        if (this.m_mcArrowRight)
        {
            with (this.m_mcArrowRight)
            {
                _x = _parent.m_initWidth - _parent.m_initHeight + (_parent.m_initHeight / 2 - _parent.m_UIArrowThickness / 2);
                _y = _parent.m_initHeight / 2 - _parent.m_UIArrowThickness / 2;
                _width = _parent.m_UIArrowThickness;
                _height = _parent.m_UIArrowThickness;
            } // End of with
        } // end if
        if (this.m_mcArrowRightInverted)
        {
            with (this.m_mcArrowRightInverted)
            {
                _x = _parent.m_mcArrowRight._x;
                _y = _parent.m_mcArrowRight._y;
                _width = _parent.m_mcArrowRight._width;
                _height = _parent.m_mcArrowRight._height;
                _visible = false;
            } // End of with
        } // end if
        if (this.m_mcButtonRightEdge)
        {
            with (this.m_mcButtonRightEdge)
            {
                _x = _parent.m_mcArrowRightBG._x;
                _y = 0;
                _width = _parent.m_initHeight;
                _height = _parent.m_initHeight;
            } // End of with
        } // end if
        if (this.m_mcButtonRightEdgeInverted)
        {
            with (this.m_mcButtonRightEdgeInverted)
            {
                _x = _parent.m_mcButtonRightEdge._x;
                _y = _parent.m_mcButtonRightEdge._y;
                _width = _parent.m_mcButtonRightEdge._width;
                _height = _parent.m_mcButtonRightEdge._height;
                _visible = false;
            } // End of with
        } // end if
        if (this.m_mcButtonRightEdgeDisabled)
        {
            with (this.m_mcButtonRightEdgeDisabled)
            {
                _x = _parent.m_mcButtonRightEdge._x;
                _y = _parent.m_mcButtonRightEdge._y;
                _width = _parent.m_mcButtonRightEdge._width;
                _height = _parent.m_mcButtonRightEdge._height;
                _visible = false;
            } // End of with
        } // end if
        if (this.m_mcButtonLeftEdge)
        {
            with (this.m_mcButtonLeftEdge)
            {
                _x = 0;
                _y = 0;
                _width = _parent.m_initHeight;
                _height = _parent.m_initHeight;
            } // End of with
        } // end if
        if (this.m_mcButtonLeftEdgeInverted)
        {
            with (this.m_mcButtonLeftEdgeInverted)
            {
                _x = _parent.m_mcButtonLeftEdge._x;
                _y = _parent.m_mcButtonLeftEdge._y;
                _width = _parent.m_mcButtonLeftEdge._width;
                _height = _parent.m_mcButtonLeftEdge._height;
                _visible = false;
            } // End of with
        } // end if
        if (this.m_mcButtonLeftEdgeDisabled)
        {
            with (this.m_mcButtonLeftEdgeDisabled)
            {
                _x = _parent.m_mcButtonLeftEdge._x;
                _y = _parent.m_mcButtonLeftEdge._y;
                _width = _parent.m_mcButtonLeftEdge._width;
                _height = _parent.m_mcButtonLeftEdge._height;
                _visible = false;
            } // End of with
        } // end if
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                with (toggleTextField)
                {
                    textColor = _parent._parent.m_labelColor;
                    _width = _parent._parent.m_initWidth - _parent._parent.m_initHeight * 2;
                } // End of with
                _x = _parent.m_initHeight;
                _y = _parent.m_initHeight / 2 - toggleTextField._height / 2 + _parent.m_labelY;
            } // End of with
        } // end if
        this.setLabel(this.m_labelValue);
        if (this.m_mcLabelBG)
        {
            with (this.m_mcLabelBG)
            {
                _y = 0;
                _x = _parent.m_initHeight;
                _width = _parent.m_initWidth - _parent.m_initHeight * 2;
                _height = _parent.m_initHeight;
            } // End of with
        } // end if
        if (this.m_mcLabelBGEdge)
        {
            with (this.m_mcLabelBGEdge)
            {
                _width = _parent.m_mcLabelBG._width;
                _height = _parent.m_mcLabelBG._height;
                _x = _parent.m_mcLabelBG._x;
                _y = _parent.m_mcLabelBG._y;
            } // End of with
        } // end if
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function update()
    {
        super.update();
        trace ("togglefield update");
        g_listObject.update();
    } // End of the function
    function pressed()
    {
        dice.bf2.Sound.playSound(m_soundId);
        this.runCallback();
        this.runCallbackSpecial();
    } // End of the function
    function setEvents()
    {
        m_mcArrowLeft.onPress = function ()
        {
            if (!_parent.m_buttonsHidden)
            {
                _parent.goPrevious();
                _parent.pressed();
                _parent.m_mcButtonLeftEdge._visible = false;
                _parent.m_mcButtonLeftEdgeInverted._visible = true;
            } // end if
        };
        m_mcArrowLeft.onRelease = function ()
        {
            if (!_parent.m_buttonsHidden)
            {
                _parent.m_mcButtonLeftEdge._visible = true;
                _parent.m_mcButtonLeftEdgeInverted._visible = false;
            } // end if
        };
        m_mcArrowLeft.onReleaseOutside = function ()
        {
            if (!m_buttonsHidden)
            {
                _parent.m_mcButtonLeftEdge._visible = true;
                _parent.m_mcButtonLeftEdgeInverted._visible = false;
            } // end if
        };
        m_mcArrowLeftBG.onPress = function ()
        {
            if (!_parent.m_buttonsHidden)
            {
                _parent.goPrevious();
                _parent.pressed();
                _parent.m_mcButtonLeftEdge._visible = false;
                _parent.m_mcButtonLeftEdgeInverted._visible = true;
            } // end if
        };
        m_mcArrowLeftBG.onRelease = function ()
        {
            if (!_parent.m_buttonsHidden)
            {
                _parent.m_mcButtonLeftEdge._visible = true;
                _parent.m_mcButtonLeftEdgeInverted._visible = false;
            } // end if
        };
        m_mcArrowLeftBG.onReleaseOutside = function ()
        {
            if (!m_buttonsHidden)
            {
                _parent.m_mcButtonLeftEdge._visible = true;
                _parent.m_mcButtonLeftEdgeInverted._visible = false;
            } // end if
        };
        m_mcArrowRight.onPress = function ()
        {
            if (!_parent.m_buttonsHidden)
            {
                _parent.goNext();
                _parent.pressed();
                _parent.m_mcButtonRightEdge._visible = false;
                _parent.m_mcButtonRightEdgeInverted._visible = true;
            } // end if
        };
        m_mcArrowRight.onRelease = function ()
        {
            if (!_parent.m_buttonsHidden)
            {
                _parent.m_mcButtonRightEdge._visible = true;
                _parent.m_mcButtonRightEdgeInverted._visible = false;
            } // end if
        };
        m_mcArrowRight.onReleaseOutside = function ()
        {
            if (!m_buttonsHidden)
            {
                _parent.m_mcButtonRightEdge._visible = true;
                _parent.m_mcButtonRightEdgeInverted._visible = false;
            } // end if
        };
        m_mcArrowRightBG.onPress = function ()
        {
            if (!_parent.m_buttonsHidden)
            {
                _parent.goNext();
                _parent.pressed();
                _parent.m_mcButtonRightEdge._visible = false;
                _parent.m_mcButtonRightEdgeInverted._visible = true;
            } // end if
        };
        m_mcArrowRightBG.onRelease = function ()
        {
            if (!_parent.m_buttonsHidden)
            {
                _parent.m_mcButtonRightEdge._visible = true;
                _parent.m_mcButtonRightEdgeInverted._visible = false;
            } // end if
        };
        m_mcArrowRightBG.onReleaseOutside = function ()
        {
            if (!_parent.m_buttonsHidden)
            {
                _parent.m_mcButtonRightEdge._visible = true;
                _parent.m_mcButtonRightEdgeInverted._visible = false;
            } // end if
        };
    } // End of the function
    function goFirst()
    {
        this.setPrevValue(m_currentToggleList[1][0].id);
        this.setLabel(m_currentToggleList[1][1]);
        this.setValue(m_currentToggleList[1][0].id);
        this.setObject(m_currentToggleList[1][0]);
    } // End of the function
    function goNext()
    {
        var _loc2 = m_currentToggleIndex;
        if (_loc2 < m_currentToggleList.length - 1)
        {
            _loc2 = _loc2 + 1;
        }
        else
        {
            _loc2 = 1;
        } // end else if
        if (_loc2 > 0)
        {
            this.goIndex(_loc2);
        } // end if
    } // End of the function
    function goPrevious()
    {
        var _loc2 = m_currentToggleIndex;
        if (_loc2 > 1)
        {
            _loc2 = _loc2 - 1;
        }
        else
        {
            _loc2 = m_currentToggleList.length - 1;
        } // end else if
        if (_loc2 > 0)
        {
            this.goIndex(_loc2);
        } // end if
    } // End of the function
    function goIndex(newIndex)
    {
        if (newIndex > 0)
        {
            this.setPrevValue(m_currentToggleList[m_currentToggleIndex][0].id);
            m_currentToggleIndex = newIndex;
            this.setLabel(m_currentToggleList[m_currentToggleIndex][1]);
            this.setValue(m_currentToggleList[m_currentToggleIndex][0].id);
            this.setObject(m_currentToggleList[m_currentToggleIndex][0]);
        } // end if
    } // End of the function
    function gotoId(searchId)
    {
        for (var _loc2 = 0; _loc2 < m_currentToggleList.length; ++_loc2)
        {
            if (m_currentToggleList[_loc2][0].id == searchId)
            {
                this.setLabel(m_currentToggleList[_loc2][1]);
                this.setValue(m_currentToggleList[_loc2][0].id);
                this.setObject(m_currentToggleList[_loc2][0]);
                break;
            } // end if
        } // end of for
    } // End of the function
    function setLabel(setLabelString)
    {
        if (this.m_mcLabel && !this.m_useImage)
        {
            with (this.m_mcLabel)
            {
                with (toggleTextField)
                {
                    text = setLabelString;
                } // End of with
            } // End of with
        } // end if
        this.m_labelText = setLabelString;
        this.m_changed = true;
    } // End of the function
    function setList(listArray)
    {
        if (listArray.length < 3)
        {
            m_buttonsHidden = true;
            this.hideButtons();
        }
        else
        {
            m_buttonsHidden = false;
            this.showButtons();
        } // end else if
        var _loc4 = 1;
        for (var _loc2 = 1; _loc2 < listArray.length; ++_loc2)
        {
            if (listArray[_loc2][0].selected)
            {
                _loc4 = _loc2;
            } // end if
        } // end of for
        m_currentToggleList = listArray;
        m_currentToggleIndex = _loc4;
        if (m_currentToggleList.length == 0)
        {
            m_currentToggleIndex = -1;
            this.setLabel("Empty list callback");
        }
        else
        {
            this.setPrevValue(m_currentToggleList[_loc4][0].id);
            this.setValue(m_currentToggleList[_loc4][0].id);
            this.setObject(m_currentToggleList[_loc4][0]);
            this.setLabel(m_currentToggleList[_loc4][1]);
        } // end else if
        this.runCallback();
        return (m_currentToggleIndex);
        m_updating = false;
    } // End of the function
    function getIndex()
    {
        return (m_currentToggleIndex);
    } // End of the function
    function getValue()
    {
        return (m_value);
    } // End of the function
    function getObject()
    {
        return (m_object);
    } // End of the function
    function setObject(sObj)
    {
        m_object = sObj;
    } // End of the function
    function setValue(sValue)
    {
        m_value = sValue;
    } // End of the function
    function getPrevValue()
    {
        return (m_prevValue);
    } // End of the function
    function setPrevValue(sValue)
    {
        m_prevValue = sValue;
    } // End of the function
    function setListId(id)
    {
        g_listObject.setId(id);
        m_listId = id;
        g_listObject.flush();
    } // End of the function
    function hideButtons()
    {
        this.setColor(m_mcArrowRightBG, m_scrollArrowBGColorDisabled);
        m_mcArrowRight._alpha = 80;
        m_mcArrowRightInverted._visible = true;
        m_mcButtonRightEdge._visible = false;
        m_mcButtonRightEdgeInverted._visible = false;
        m_mcButtonRightEdgeDisabled._visible = true;
        this.setColor(m_mcArrowLeftBG, m_scrollArrowBGColorDisabled);
        m_mcArrowLeft._alpha = 10;
        m_mcArrowLeftInverted._visible = true;
        m_mcButtonLeftEdge._visible = false;
        m_mcButtonLeftEdgeInverted._visible = false;
        m_mcButtonLeftEdgeDisabled._visible = true;
        m_buttonsHidden = true;
    } // End of the function
    function showButtons()
    {
        this.setColor(m_mcArrowRightBG, m_scrollArrowBGColor);
        m_mcArrowRight._visible = true;
        m_mcArrowRight._alpha = 100;
        m_mcArrowRightInverted._visible = false;
        m_mcButtonRightEdge._visible = true;
        m_mcButtonRightEdgeInverted._visible = false;
        m_mcButtonRightEdgeDisabled._visible = false;
        this.setColor(m_mcArrowLeftBG, m_scrollArrowBGColor);
        m_mcArrowLeft._visible = true;
        m_mcArrowLeft._alpha = 100;
        m_mcArrowLeftInverted._visible = false;
        m_mcButtonLeftEdge._visible = true;
        m_mcButtonLeftEdgeInverted._visible = false;
        m_mcButtonLeftEdgeDisabled._visible = false;
        m_buttonsHidden = false;
    } // End of the function
    function flush()
    {
        g_listObject.flush();
    } // End of the function
    function updateManager()
    {
        this.update();
        return (m_updating);
    } // End of the function
    var m_arrowBGAlpha = dice.UI.prototype.m_UIBGAlpha;
    var m_fieldBGColor = dice.UI.prototype.m_UIBGColor;
    var m_labelColor = dice.UI.prototype.m_UITriggerColor;
    var m_scrollArrowBGColor = dice.UI.prototype.m_UIBGColor;
    var m_scrollArrowBGColorDisabled = dice.UI.prototype.m_UIBGColor;
    var m_sliderBevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_sliderBevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_sliderDisabledBevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_sliderDisabledBevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_BGAlpha = dice.UI.prototype.m_UIBGAlpha;
    var m_bevelAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_buttonsHidden = false;
    var m_currentToggleList = new Array();
    var m_currentToggleIndex = 0;
    var m_value = "";
    var m_labelText = "";
    var m_prevValue = -1;
    var m_listId = "";
    var m_changed = false;
} // End of Class
