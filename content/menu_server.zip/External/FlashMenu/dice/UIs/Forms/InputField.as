class dice.UIs.Forms.InputField extends dice.UIs.Form
{
    var __get__textValue, m_labelX, __get__labelX, m_useLabel, m_inAuthorMode, __get__useLabel, m_maxCharacters, __get__maxCharacters, m_restrictChars, __get__restrictChars, m_numbersOnly, __get__numbersOnly, m_tabIndex, __get__textTabIndex, m_inputPassword, __get__inputIsPassword, m_inputMarginWidth, __get__inputMarginWidth, m_inputMarginHeight, __get__inputMarginHeight, m_baseColor, __get__baseColor, m_inputX, __get__inputXOffset, m_inputY, __get__inputYOffset, inputValue, __get__inputStartValue, mcBoundingBox, _parent, setCallbackObject, setCallbackGetObject, getNextHighestDepth, createEmptyMovieClip, m_mcInputBG, m_mcInputBGGlow, m_mcBevel, attachMovie, m_localizationId, m_mcInputFieldTitle, m_glowBackgroundEnabled, setColor, m_glowAlphaEnabled, m_glowAlpha, _alpha, m_callbackFunctionSpecial, m_mcInput, _name, runCallbackSpecial, m_mcLabelTextSet, text, m_changed, __set__baseColor, __set__inputIsPassword, __set__inputMarginHeight, __set__inputMarginWidth, __set__inputStartValue, __set__inputXOffset, __set__inputYOffset, __set__labelX, __set__maxCharacters, __set__numbersOnly, __set__restrictChars, __set__textTabIndex, __set__textValue, __set__useLabel;
    function InputField(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set textValue(nValue)
    {
        m_textValue = nValue;
        //return (this.textValue());
        null;
    } // End of the function
    function get textValue()
    {
        return (m_textValue);
    } // End of the function
    function set labelX(nValue)
    {
        m_labelX = nValue;
        //return (this.labelX());
        null;
    } // End of the function
    function get labelX()
    {
        return (m_labelX);
    } // End of the function
    function set useLabel(nValue)
    {
        m_useLabel = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.useLabel());
        null;
    } // End of the function
    function get useLabel()
    {
        return (m_useLabel);
    } // End of the function
    function set maxCharacters(Value)
    {
        m_maxCharacters = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.maxCharacters());
        null;
    } // End of the function
    function get maxCharacters()
    {
        return (m_maxCharacters);
    } // End of the function
    function set restrictChars(Value)
    {
        m_restrictChars = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.restrictChars());
        null;
    } // End of the function
    function get restrictChars()
    {
        return (m_restrictChars);
    } // End of the function
    function set numbersOnly(Value)
    {
        m_numbersOnly = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.numbersOnly());
        null;
    } // End of the function
    function get numbersOnly()
    {
        return (m_numbersOnly);
    } // End of the function
    function set textTabIndex(Value)
    {
        m_tabIndex = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.textTabIndex());
        null;
    } // End of the function
    function get textTabIndex()
    {
        return (m_tabIndex);
    } // End of the function
    function set inputIsPassword(Value)
    {
        m_inputPassword = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.inputIsPassword());
        null;
    } // End of the function
    function get inputIsPassword()
    {
        return (m_inputPassword);
    } // End of the function
    function set inputMarginWidth(Value)
    {
        m_inputMarginWidth = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.inputMarginWidth());
        null;
    } // End of the function
    function get inputMarginWidth()
    {
        return (m_inputMarginWidth);
    } // End of the function
    function set inputMarginHeight(Value)
    {
        m_inputMarginHeight = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.inputMarginHeight());
        null;
    } // End of the function
    function get inputMarginHeight()
    {
        return (m_inputMarginHeight);
    } // End of the function
    function set baseColor(nValue)
    {
        m_baseColor = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.baseColor());
        null;
    } // End of the function
    function get baseColor()
    {
        return (m_baseColor);
    } // End of the function
    function set inputXOffset(Value)
    {
        m_inputX = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.inputXOffset());
        null;
    } // End of the function
    function get inputXOffset()
    {
        return (m_inputX);
    } // End of the function
    function set inputYOffset(Value)
    {
        m_inputY = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.inputYOffset());
        null;
    } // End of the function
    function get inputYOffset()
    {
        return (m_inputY);
    } // End of the function
    function set inputStartValue(sValue)
    {
        inputValue = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.inputStartValue());
        null;
    } // End of the function
    function get inputStartValue()
    {
        return (inputValue);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        this.setCallbackObject(_parent);
        this.setCallbackGetObject(this);
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcInputBG", this.getNextHighestDepth());
        with (this.m_mcInputBG)
        {
            lineStyle(0, _parent.m_baseColor, 0);
            beginFill(_parent.m_baseColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcInputBGGlow", this.getNextHighestDepth());
        with (this.m_mcInputBGGlow)
        {
            lineStyle(0, _parent.m_baseColor, 0);
            beginFill(_parent.m_baseColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
            _alpha = 0;
        } // End of with
        this.createEmptyMovieClip("m_mcBevel", this.getNextHighestDepth());
        with (this.m_mcBevel)
        {
            lineStyle(0, _parent.m_bevelTopLeftColor, _parent.m_bevelAlpha);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_bevelBottomRightColor, _parent.m_bevelAlpha);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
    } // End of the function
    function createChildren()
    {
        if (m_useLabel)
        {
            this.attachMovie("mcInputFieldLabel", "m_mcInputFieldTitle", this.getNextHighestDepth());
            if (m_localizationId.length > 0)
            {
                mx.lang.Locale.addDelayedInstance(m_mcInputFieldTitle.title, m_localizationId);
            } // end if
        } // end if
        this.attachMovie("mcInput", "m_mcInput", this.getNextHighestDepth());
    } // End of the function
    function setGlow(glow, glowColor)
    {
        if (m_glowBackgroundEnabled)
        {
            this.setColor(m_mcInputBGGlow, glowColor);
            m_mcInputBGGlow._alpha = glow;
        } // end if
        if (m_glowAlphaEnabled)
        {
            _alpha = m_glowAlpha;
        } // end if
    } // End of the function
    function startEnterCheck()
    {
        if (m_callbackFunctionSpecial.length > 0)
        {
            _root.updateManager1.setEnterCheck(this);
        } // end if
    } // End of the function
    function hasFocus()
    {
        return (m_mcInput.inputField._focus);
    } // End of the function
    function checkFocus()
    {
        var _loc2 = this.hasFocus();
        if (_loc2)
        {
            if (Key.isDown(13) && m_enterCheckRunning)
            {
                trace ("enter down!");
                m_enterCheckRunning = false;
                this.runEnterFunction();
                return (false);
            } // end if
        } // end if
        if (m_enterCheckRunning == false)
        {
            _loc2 = false;
        } // end if
        return (_loc2);
    } // End of the function
    function runEnterFunction()
    {
        trace ("ENTER function runs: " + _name);
        m_mcInput.inputField._focus = false;
        this.runCallbackSpecial();
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (!this.m_mcLabelTextSet && this.m_mcInputFieldTitle)
        {
            this.m_mcLabelTextSet = true;
            with (this.m_mcInputFieldTitle)
            {
                _x = 0;
                _y = _parent.m_initHeight / 2 - title._height / 2;
                with (title)
                {
                    _x = 0;
                    _y = 0;
                    textColor = _parent._parent.m_labelColor;
                    _width = _parent._parent.m_labelX - 5;
                    if (_parent._parent.m_localizationId.length > 0)
                    {
                        text = _parent._parent.m_localizationId;
                    }
                    else
                    {
                        text = _parent._parent.m_textValue;
                    } // end if
                } // End of with
            } // End of with
        } // end else if
        if (this.m_mcInput)
        {
            with (this.m_mcInput)
            {
                with (inputField)
                {
                    maxChars = _parent._parent.m_maxCharacters;
                    tabIndex = _parent._parent.m_tabIndex;
                    textColor = _parent._parent.m_inputColor;
                    text = _parent._parent.inputValue;
                    _width = _parent._parent.m_initWidth - (_parent._parent.m_inputMarginWidth * 2 + _parent._parent.m_labelX);
                    _height = _parent._parent.m_initHeight - _parent._parent.m_inputMarginHeight * 2;
                    password = _parent._parent.m_inputPassword;
                } // End of with
                _x = _parent.m_inputMarginWidth + _parent.m_labelX;
                _y = _parent.m_inputMarginHeight;
            } // End of with
            if (this.m_tabIndex == 1)
            {
                this.m_mcInput.inputField._focus = true;
                this.startEnterCheck();
            } // end if
            if (this.m_numbersOnly && this.m_restrictChars.length <= 0)
            {
                this.m_mcInput.inputField.restrict = "0123456789.";
            }
            else if (this.m_restrictChars.length > 0)
            {
                trace ("setting restrict to: " + this.m_restrictChars);
                this.m_mcInput.inputField.restrict = this.m_restrictChars;
            } // end if
        } // end else if
        if (this.m_mcInputBG)
        {
            with (this.m_mcInputBG)
            {
                _y = 0;
                _x = _parent.m_labelX;
                _width = _parent.m_initWidth - _parent.m_labelX;
                _height = _parent.m_initHeight;
                _alpha = _parent.m_BGAlpha;
            } // End of with
        } // end if
        this.setColor(this.m_mcInputBG, this.m_inputBGColor);
        if (this.m_mcBevel)
        {
            with (this.m_mcBevel)
            {
                _x = _parent.m_mcInputBG._x;
                _y = _parent.m_mcInputBG._y;
                _width = _parent.m_mcInputBG._width;
                _height = _parent.m_mcInputBG._height;
            } // End of with
        } // end if
        if (this.m_mcInputBGGlow)
        {
            with (this.m_mcInputBGGlow)
            {
                _y = _parent.m_mcInputBG._y;
                _x = _parent.m_mcInputBG._x;
                _width = _parent.m_mcInputBG._width;
                _height = _parent.m_mcInputBG._height;
            } // End of with
        } // end if
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function update()
    {
        super.update();
    } // End of the function
    function setEvents()
    {
        m_mcInput.inputField.onSetFocus = function (oldFocus)
        {
            _parent._parent.startEnterCheck();
        };
        m_mcInput.inputField.onChanged = function ()
        {
            _parent._parent.inputValue = text;
            _parent._parent.runCallback();
        };
    } // End of the function
    function getValue()
    {
        return (m_mcInput.inputField.text);
    } // End of the function
    function setValue(sValue)
    {
        inputValue = sValue;
        this.arrange();
        m_changed = true;
    } // End of the function
    var m_textValue = "";
    var m_bevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_bevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_bevelAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_BGAlpha = dice.UI.prototype.m_UIBGAlpha;
    var m_inputBGColor = dice.UI.prototype.m_UIBGColor;
    var m_inputColor = dice.UI.prototype.m_UITriggerColor;
    var m_labelColor = dice.UI.prototype.m_UITriggerColorSelected;
    var m_enterFloodProt = false;
    var m_enterPressed = 0;
    var m_enterCheckRunning = false;
} // End of Class
