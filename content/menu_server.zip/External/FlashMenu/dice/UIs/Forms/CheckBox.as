class dice.UIs.Forms.CheckBox extends dice.UIs.Form
{
    var _parent, setCallbackObject, setCallbackGetObject, __get__checkBoxX, m_labelLength, m_label, __get__label, m_labelColor, __get__labelColor, m_labelYOffset, __get__labelYOffset, m_labelX, __get__labelX, m_labelXOffset, __get__labelXOffset, m_inAuthorMode, __get__isChecked, __get__iconColor, mcBoundingBox, m_callbackFrequency, getNextHighestDepth, createEmptyMovieClip, m_mcCheckBoxBG, m_mcButtonEdge, m_mcButtonBGGlow, attachMovie, m_localizationId, m_mcLabel, m_mcIcon, m_btCheckBoxSpecial, setColor, m_enabled, m_enableStatusChanged, __alpha, _alpha, runCallback, m_updating, __set__checkBoxX, __set__iconColor, __set__isChecked, __set__label, __set__labelColor, __set__labelX, __set__labelXOffset, __set__labelYOffset;
    function CheckBox(cancelInit)
    {
        super(true);
        this.setCallbackObject(_parent);
        this.setCallbackGetObject(this);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set checkBoxX(nValue)
    {
        m_checkBoxX = nValue;
        //return (this.checkBoxX());
        null;
    } // End of the function
    function get checkBoxX()
    {
        return (m_checkBoxX);
    } // End of the function
    function set label(sValue)
    {
        var _loc2 = new String(sValue);
        m_labelLength = _loc2.length;
        m_label = sValue;
        //return (this.label());
        null;
    } // End of the function
    function get label()
    {
        return (m_label);
    } // End of the function
    function set labelColor(nValue)
    {
        m_labelColor = nValue;
        //return (this.labelColor());
        null;
    } // End of the function
    function get labelColor()
    {
        return (m_labelColor);
    } // End of the function
    function set labelYOffset(Value)
    {
        m_labelYOffset = Value;
        //return (this.labelYOffset());
        null;
    } // End of the function
    function get labelYOffset()
    {
        return (m_labelYOffset);
    } // End of the function
    function set labelX(Value)
    {
        m_labelX = Value;
        //return (this.labelX());
        null;
    } // End of the function
    function get labelX()
    {
        return (m_labelX);
    } // End of the function
    function set labelXOffset(Value)
    {
        m_labelXOffset = Value;
        //return (this.labelXOffset());
        null;
    } // End of the function
    function get labelXOffset()
    {
        return (m_labelXOffset);
    } // End of the function
    function set isChecked(nValue)
    {
        checked = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.isChecked());
        null;
    } // End of the function
    function get isChecked()
    {
        return (checked);
    } // End of the function
    function set iconColor(nValue)
    {
        m_iconColor = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.iconColor());
        null;
    } // End of the function
    function get iconColor()
    {
        return (m_iconColor);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        _root.updateManager1.registerCallback(this, "updateManager", m_callbackFrequency);
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcCheckBoxBG", this.getNextHighestDepth());
        with (this.m_mcCheckBoxBG)
        {
            lineStyle(0, _parent.m_baseColor, 0);
            beginFill(_parent.m_baseColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcButtonEdge", this.getNextHighestDepth());
        with (this.m_mcButtonEdge)
        {
            lineStyle(0, _parent.m_sliderBevelTopLeftColor, 100);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelBottomRightColor, 100);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcButtonBGGlow", this.getNextHighestDepth());
        with (this.m_mcButtonBGGlow)
        {
            lineStyle(0, _parent.m_buttonGlowColor, 0);
            beginFill(_parent.m_buttonGlowColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
    } // End of the function
    function createChildren()
    {
        this.attachMovie("mcCheckBoxLabel", "m_mcLabel", this.getNextHighestDepth());
        if (m_localizationId.length > 0)
        {
            mx.lang.Locale.addDelayedInstance(m_mcLabel.labelCheckBox, m_localizationId);
        } // end if
        this.attachMovie("btCheckBoxSpecial", "m_btCheckBoxSpecial", this.getNextHighestDepth());
        this.attachMovie("mcCheckIcon", "m_mcIcon", this.getNextHighestDepth());
        if (!m_inAuthorMode)
        {
            m_mcIcon.loadMovie("images/components/checkBox_x.png");
        } // end if
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                _x = _parent.m_labelXOffset + _parent.m_labelX;
                _y = _parent.m_initHeight / 2 - labelCheckBox._height / 2 + _parent.m_labelYOffset;
                if (labelCheckBox)
                {
                    with (labelCheckBox)
                    {
                        if (_parent._parent.m_localizationId.length > 0)
                        {
                            text = _parent._parent.m_localizationId;
                        }
                        else
                        {
                            text = _parent._parent.m_label;
                        } // end else if
                        if (_parent._parent.m_checkBoxX > _parent._x)
                        {
                            _width = _parent._parent.m_checkBoxX - (5 + _parent._x);
                        }
                        else
                        {
                            _width = _parent._parent.m_initWidth - _parent._x;
                        } // end else if
                        textColor = _parent._parent.m_labelColor;
                        _x = 0;
                        _y = 0;
                    } // End of with
                } // end if
            } // End of with
        } // end if
        if (this.m_btCheckBoxSpecial)
        {
            with (this.m_btCheckBoxSpecial)
            {
                _x = _parent.m_checkBoxX;
                _y = 0;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
                _alpha = 0;
            } // End of with
        } // end if
        this.setColor(this.m_mcCheckBoxBG, this.m_buttonBGColor);
        if (this.m_mcCheckBoxBG)
        {
            with (this.m_mcCheckBoxBG)
            {
                _x = _parent.m_checkBoxX;
                _y = 0;
                _width = _parent.m_initHeight;
                _height = _parent.m_initHeight;
                _alpha = _parent.m_buttonBGAlpha;
            } // End of with
        } // end if
        if (this.m_mcButtonEdge)
        {
            with (this.m_mcButtonEdge)
            {
                _x = _parent.m_mcCheckBoxBG._x;
                _y = _parent.m_mcCheckBoxBG._y;
                _width = _parent.m_mcCheckBoxBG._width;
                _height = _parent.m_mcCheckBoxBG._height;
                _alpha = _parent.m_bevelAlpha;
            } // End of with
        } // end if
        if (this.m_mcButtonBGGlow)
        {
            with (this.m_mcButtonBGGlow)
            {
                _x = _parent.m_mcCheckBoxBG._x;
                _y = _parent.m_mcCheckBoxBG._y;
                _width = _parent.m_mcCheckBoxBG._width;
                _height = _parent.m_mcCheckBoxBG._height;
                _alpha = _parent.m_glowInit;
            } // End of with
        } // end if
        if (this.m_mcIcon)
        {
            with (this.m_mcIcon)
            {
                _width = _parent.m_initHeight - _parent.m_initHeight / 4;
                _height = _parent.m_initHeight - _parent.m_initHeight / 4;
                _x = _parent.m_checkBoxX + (_parent.m_initHeight / 2 - _width / 2);
                _y = _parent.m_initHeight / 2 - _height / 2;
                _visible = false;
            } // End of with
        } // end if
        this.toggleCheck(this.checked, false);
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function glow()
    {
        var _loc4 = m_mcButtonBGGlow._alpha;
        var _loc2 = _loc4;
        var _loc3 = _loc2 / m_glowMax;
        if (m_glowUp)
        {
            _loc2 = _loc2 + (m_glowMax - m_glowMin) / m_glowTime;
            _loc3 = _loc2 / m_glowMax;
            if (_loc2 <= m_glowMax)
            {
                m_mcButtonBGGlow._alpha = _loc2;
                return (true);
            }
            else
            {
                m_glowUp = false;
                return (true);
            } // end else if
        }
        else
        {
            _loc2 = _loc2 - (m_glowMax - m_glowMin) / m_glowTime;
            _loc3 = _loc2 / m_glowMax;
            if (_loc2 >= m_glowMin)
            {
                m_mcButtonBGGlow._alpha = _loc2;
            }
            else
            {
                m_glowingInProgress = false;
                m_mcLabel.labelTextField.textColor = m_labelColor;
                return (false);
            } // end else if
            return (true);
        } // end else if
        return (false);
    } // End of the function
    function update()
    {
        super.update();
        if (!m_enabled && m_enableStatusChanged)
        {
            _alpha = __alpha / 2;
            m_enableStatusChanged = false;
        } // end if
    } // End of the function
    function setEvents()
    {
        function onRollOver()
        {
            if (m_enabled)
            {
                if (m_useGlow)
                {
                    if (!m_glowingInProgress)
                    {
                        _root.updateManager1.registerCallback(this, "glow", _parent.m_callbackFrequency);
                    } // end if
                    m_glowingInProgress = true;
                    m_glowUp = true;
                } // end if
            } // end if
        } // End of the function
        function onRollOut()
        {
            if (m_enabled)
            {
                if (m_useGlow)
                {
                    m_glowUp = false;
                } // end if
            } // end if
        } // End of the function
        function onPress()
        {
            this.pressEvent();
        } // End of the function
        function onReleaseOutside()
        {
            if (m_enabled)
            {
                if (m_useGlow)
                {
                    m_glowUp = false;
                } // end if
            } // end if
        } // End of the function
    } // End of the function
    function toggleCheck(overRide, useSounds)
    {
        checked = overRide;
        if (checked)
        {
            checked = true;
            m_mcIcon._visible = true;
            if (useSounds)
            {
                dice.bf2.Sound.playSound("checkboxCheck");
            } // end if
        }
        else
        {
            if (useSounds)
            {
                dice.bf2.Sound.playSound("checkboxUnCheck");
            } // end if
            checked = false;
            m_mcIcon._visible = false;
        } // end else if
        m_changed = true;
        return (checked);
    } // End of the function
    function pressEvent()
    {
        if (m_enabled)
        {
            if (checked)
            {
                this.setValue(false, false, true);
            }
            else
            {
                this.setValue(true, false, true);
            } // end if
        } // end else if
    } // End of the function
    function setValue(bValue, noCallback, useSounds)
    {
        trace ("setChecked: " + bValue + " nm: " + m_label);
        this.toggleCheck(bValue, useSounds);
        if (!noCallback)
        {
            this.runCallback();
        } // end if
        m_changed = true;
    } // End of the function
    function getValue()
    {
        return (checked);
    } // End of the function
    function updateManager()
    {
        this.update();
        return (m_updating);
    } // End of the function
    var m_buttonBGColor = dice.UI.prototype.m_UIBGColor;
    var m_buttonBGAlpha = dice.UI.prototype.m_UIBGAlpha;
    var m_bevelAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_sliderBevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_sliderBevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_iconColor = dice.UI.prototype.m_baseDetailColorSelected;
    var m_checkboxIconColor = dice.UI.prototype.m_baseTextColor;
    var m_buttonGlowColor = dice.UI.prototype.m_UIGlowColor;
    var m_glowUp = false;
    var m_glowMax = 25;
    var m_glowMin = 0;
    var m_glowInit = dice.UIs.Forms.CheckBox.prototype.m_glowMin;
    var m_glowingInProgress = false;
    var m_glowTime = 4;
    var m_glowText = false;
    var m_useGlow = true;
    var checked = false;
    var m_changed = false;
    var m_checkBoxX = 0;
} // End of Class
