class dice.UIs.Forms.Slider extends dice.UIs.Form
{
    var m_initPercent, runCallbackInit, m_runCBOnUpdate, __get__callbackRunsOnDrag, __get__textValue, m_labelX, __get__labelX, m_sliderX, __get__sliderX, __get__sliderInitPercent, m_numDecimals, m_inAuthorMode, __get__numDecimals, m_labelMultiplier, __get__labelMultiplier, m_labelAddonEnd, __get__labelAddonEnd, m_useLabel, __get__useLabel, m_granularityValue, __get__granularityValue, m_bottomValue, __get__bottomValue, m_topValue, __get__topValue, m_sliderWidth, __get__sliderWidth, m_edgeThickness, mcBoundingBox, _parent, setCallbackObject, setCallbackGetObject, m_soundId, getNextHighestDepth, createEmptyMovieClip, m_mcSliderContainer, attachMovie, m_localizationId, m_mcLabelText, m_mcLabel, m_initWidth, setColor, m_dragYToggle, m_dragXToggle, m_dragMC, _height, _ymouse, _width, _xmouse, m_changed, runCallback, m_updating, __set__bottomValue, __set__callbackRunsOnDrag, __set__granularityValue, __set__labelAddonEnd, __set__labelMultiplier, __set__labelX, __set__numDecimals, __set__sliderInitPercent, __set__sliderWidth, __set__sliderX, __set__textValue, __set__topValue, __set__useLabel;
    function Slider(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
            if (m_initPercent > 0)
            {
                this.setPercent(m_initPercent);
            } // end if
            this.runCallbackInit();
        } // end if
    } // End of the function
    function set callbackRunsOnDrag(nValue)
    {
        m_runCBOnUpdate = nValue;
        //return (this.callbackRunsOnDrag());
        null;
    } // End of the function
    function get callbackRunsOnDrag()
    {
        return (m_runCBOnUpdate);
    } // End of the function
    function set textValue(nValue)
    {
        m_textValue = nValue;
        //return (this.textValue());
        null;
    } // End of the function
    function get textValue()
    {
        return (m_textValue);
    } // End of the function
    function set labelX(nValue)
    {
        m_labelX = nValue;
        //return (this.labelX());
        null;
    } // End of the function
    function get labelX()
    {
        return (m_labelX);
    } // End of the function
    function set sliderX(nValue)
    {
        m_sliderX = nValue;
        //return (this.sliderX());
        null;
    } // End of the function
    function get sliderX()
    {
        return (m_sliderX);
    } // End of the function
    function set sliderInitPercent(nValue)
    {
        m_initPercent = nValue;
        //return (this.sliderInitPercent());
        null;
    } // End of the function
    function get sliderInitPercent()
    {
        return (m_initPercent);
    } // End of the function
    function set numDecimals(nValue)
    {
        m_numDecimals = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.numDecimals());
        null;
    } // End of the function
    function get numDecimals()
    {
        return (m_numDecimals);
    } // End of the function
    function set labelMultiplier(nValue)
    {
        m_labelMultiplier = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelMultiplier());
        null;
    } // End of the function
    function get labelMultiplier()
    {
        return (m_labelMultiplier);
    } // End of the function
    function set labelAddonEnd(nValue)
    {
        m_labelAddonEnd = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelAddonEnd());
        null;
    } // End of the function
    function get labelAddonEnd()
    {
        return (m_labelAddonEnd);
    } // End of the function
    function set useLabel(nValue)
    {
        m_useLabel = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.useLabel());
        null;
    } // End of the function
    function get useLabel()
    {
        return (m_useLabel);
    } // End of the function
    function set granularityValue(nValue)
    {
        m_granularityValue = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.granularityValue());
        null;
    } // End of the function
    function get granularityValue()
    {
        return (m_granularityValue);
    } // End of the function
    function set bottomValue(nValue)
    {
        m_bottomValue = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.bottomValue());
        null;
    } // End of the function
    function get bottomValue()
    {
        return (m_bottomValue);
    } // End of the function
    function set topValue(nValue)
    {
        m_topValue = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.topValue());
        null;
    } // End of the function
    function get topValue()
    {
        return (m_topValue);
    } // End of the function
    function set sliderWidth(nValue)
    {
        m_sliderWidth = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.sliderWidth());
        null;
    } // End of the function
    function get sliderWidth()
    {
        return (m_sliderWidth);
    } // End of the function
    function init()
    {
        super.init();
        m_edgeThickness = 1;
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        this.setCallbackObject(_parent);
        this.setCallbackGetObject(this);
        m_soundId = "sliderDrag";
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcSliderContainer", this.getNextHighestDepth());
        with (this.m_mcSliderContainer)
        {
            createEmptyMovieClip("background", getNextHighestDepth());
            with (background)
            {
                lineStyle(0, _parent._parent.m_baseColor, 0);
                beginFill(_parent._parent.m_baseColor, 100);
                moveTo(0, 0);
                lineTo(0, 100);
                lineTo(100, 100);
                lineTo(100, 0);
                endFill();
            } // End of with
            createEmptyMovieClip("bevel", getNextHighestDepth());
            with (bevel)
            {
                lineStyle(0, _parent._parent.m_bevelTopLeftColor, 100);
                moveTo(0, 100);
                lineTo(0, 0);
                lineTo(100, 0);
                lineStyle(0, _parent._parent.m_bevelBottomRightColor, 100);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
            } // End of with
            createEmptyMovieClip("slider", getNextHighestDepth());
            with (slider)
            {
                lineStyle(0, _parent._parent.m_sliderColor, 0);
                beginFill(_parent._parent.m_sliderColor, 100);
                moveTo(0, 0);
                lineTo(0, 100);
                lineTo(100, 100);
                lineTo(100, 0);
                endFill();
            } // End of with
            createEmptyMovieClip("sliderBevel", getNextHighestDepth());
            with (sliderBevel)
            {
                lineStyle(0, _parent._parent.m_sliderBevelTopLeftColor, 100);
                moveTo(0, 100);
                lineTo(0, 0);
                lineTo(100, 0);
                lineStyle(0, _parent._parent.m_sliderBevelBottomRightColor, 100);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
            } // End of with
        } // End of with
    } // End of the function
    function createChildren()
    {
        if (m_useLabel)
        {
            this.attachMovie("mcSliderLabel", "m_mcLabel", this.getNextHighestDepth());
            this.attachMovie("mcSliderLabelText", "m_mcLabelText", this.getNextHighestDepth());
            if (m_localizationId.length > 0)
            {
                mx.lang.Locale.addDelayedInstance(m_mcLabelText.titleText, m_localizationId);
            } // end if
        } // end if
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_mcLabel)
        {
            if (!this.m_mcLabelTextSet)
            {
                this.m_mcLabelTextSet = true;
                with (this.m_mcLabelText)
                {
                    _x = _parent.m_labelXOffset;
                    _y = _parent.m_initHeight / 2 - titleText._height / 2 + _parent.m_labelYOffset;
                    with (titleText)
                    {
                        textColor = _parent._parent.m_labelTitleColor;
                        _width = _parent._parent.m_labelX - 5;
                        if (_parent._parent.m_localizationId.length > 0)
                        {
                            text = _parent._parent.m_localizationId;
                        }
                        else
                        {
                            text = _parent._parent.m_textValue;
                        } // end if
                    } // End of with
                } // End of with
            } // end else if
            with (this.m_mcLabel)
            {
                _x = _parent.m_labelX + _parent.m_labelXOffset;
                _y = _parent.m_initHeight / 2 - title._height / 2 + _parent.m_labelYOffset;
                with (title)
                {
                    textColor = _parent._parent.m_labelColor;
                    _width = _parent._parent.m_sliderX - 5 - _parent._parent.m_labelX;
                    if (_parent._parent.m_labelAddonEnd.length > 0)
                    {
                        text = dice.bf2.Logic.setDecimals(_parent._parent.m_value, _parent._parent.m_numDecimals) + _parent._parent.m_labelAddonEnd;
                    }
                    else
                    {
                        text = dice.bf2.Logic.setDecimals(_parent._parent.m_value, _parent._parent.m_numDecimals);
                    } // end if
                } // End of with
            } // End of with
        } // end else if
        if (this.m_mcSliderContainer)
        {
            var m_containerWidth = 0;
            if (this.m_useLabel)
            {
                m_containerWidth = this.m_initWidth - this.m_sliderX;
            }
            else
            {
                m_containerWidth = this.m_initWidth;
            } // end else if
            with (this.m_mcSliderContainer)
            {
                if (_parent.m_sliderX)
                {
                    _x = _parent.m_sliderX;
                } // end if
                with (background)
                {
                    _width = m_containerWidth;
                    _height = _parent._parent.m_initHeight;
                    _x = 0;
                    _y = 0;
                    _alpha = _parent._parent.m_baseAlpha;
                } // End of with
                with (bevel)
                {
                    _x = 0;
                    _y = 0;
                    _width = _parent.background._width;
                    _height = _parent.background._height;
                    _alpha = _parent._parent.m_bevelAlpha;
                } // End of with
                with (slider)
                {
                    if (_parent._parent.m_sliderWidth <= 0)
                    {
                        _width = m_containerWidth / _parent._parent.m_topValue;
                    }
                    else
                    {
                        _width = _parent._parent.m_sliderWidth;
                    } // end else if
                    _height = _parent._parent.m_initHeight - 4;
                    _x = (m_containerWidth - 4 - _width) * _parent._parent.m_percent + 2;
                    _y = 2;
                    _alpha = _parent._parent.m_sliderAlpha;
                } // End of with
                with (sliderBevel)
                {
                    _x = _parent.slider._x;
                    _y = _parent.slider._y;
                    _width = _parent.slider._width;
                    _height = _parent.slider._height;
                    _alpha = _parent._parent.m_sliderBevelAlpha;
                    _visible = _parent._parent.m_showSliderBevel;
                } // End of with
            } // End of with
        } // end if
        this.setColor(this.m_mcSliderContainer.background, this.m_sliderBgColor);
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function setGlow(glow, glowColor)
    {
    } // End of the function
    function update()
    {
        super.update();
        m_dragYToggle = true;
        m_dragXToggle = true;
        if (m_dragMC._parent._ymouse - m_dragClickYOffset <= m_dragTop)
        {
            m_dragYToggle = false;
            m_dragMC._y = m_dragTop;
        } // end if
        if (m_dragMC._parent._ymouse - m_dragClickYOffset > m_dragBottom - m_dragMC._height)
        {
            m_dragYToggle = false;
            if (m_dragRight == m_dragLeft)
            {
                m_dragMC._y = m_dragBottom - m_dragMC._height;
            }
            else
            {
                m_dragMC._y = m_dragBottom;
            } // end if
        } // end else if
        if (m_dragMC._parent._xmouse - m_dragClickXOffset <= m_dragLeft)
        {
            m_dragXToggle = false;
            m_dragMC._x = m_dragLeft;
        } // end if
        if (m_dragMC._parent._xmouse - m_dragClickXOffset > m_dragRight - m_dragMC._width)
        {
            m_dragXToggle = false;
            if (m_dragTop == m_dragBottom)
            {
                m_dragMC._x = m_dragRight - m_dragMC._width;
            }
            else
            {
                m_dragMC._x = m_dragRight;
            } // end if
        } // end else if
        if (m_dragYToggle)
        {
            m_dragMC._y = m_dragMC._parent._ymouse - m_dragClickYOffset;
        } // end if
        if (m_dragXToggle)
        {
            m_dragMC._x = m_dragMC._parent._xmouse - m_dragClickXOffset;
        } // end if
        m_percent = (m_mcSliderContainer.slider._x - 2) / (m_mcSliderContainer.background._width - 4 - m_mcSliderContainer.slider._width);
        this.setPercent(m_percent);
    } // End of the function
    function setEvents()
    {
        m_mcSliderContainer.slider.onPress = function ()
        {
            if (_parent._parent.m_enabled)
            {
                _root.updateManager1.registerCallback(_parent._parent, "updateManager", _parent._parent.m_callbackFrequency);
                _parent._parent.m_updating = true;
                _parent._parent.m_dragMC = this;
                _parent._parent.setBoundaries(_parent._parent.m_mcSliderContainer, true);
                _parent._parent.m_dragClickYOffset = _height * (_ymouse / 100);
                _parent._parent.m_dragClickXOffset = _width * (_xmouse / 100);
            } // end if
        };
        m_mcSliderContainer.slider.onRelease = function ()
        {
            if (_parent._parent.m_enabled)
            {
                _parent._parent.m_updating = false;
                if (!_parent._parent.m_runCBOnUpdate)
                {
                    _parent._parent.runCallback();
                } // end if
            } // end if
        };
        m_mcSliderContainer.slider.onReleaseOutside = function ()
        {
            if (_parent._parent.m_enabled)
            {
                _parent._parent.m_updating = false;
                _parent._parent.runCallback();
            } // end if
        };
    } // End of the function
    function setBoundaries(mcScrollParent)
    {
        m_dragTop = mcScrollParent.slider._y;
        m_dragBottom = mcScrollParent.slider._y;
        m_dragLeft = mcScrollParent.background._x + 2;
        m_dragRight = mcScrollParent.background._x + 2 + (mcScrollParent.background._width - 4);
    } // End of the function
    function setPercent(nValue)
    {
        m_percent = nValue;
        if (nValue >= 1)
        {
            m_percent = 1;
            m_value = m_topValue;
        }
        else if (nValue <= 0)
        {
            m_percent = 0;
            m_value = m_bottomValue;
        }
        else
        {
            m_value = m_percent * (m_topValue - m_bottomValue) + m_bottomValue;
            m_value = Math.round(m_value / m_granularityValue) * m_granularityValue;
        } // end else if
        m_changed = true;
        this.arrange();
    } // End of the function
    function setValue(nValue)
    {
        var _loc3 = nValue / (m_topValue - m_bottomValue);
        var _loc2 = nValue;
        _loc2 = Math.round(_loc2 / m_granularityValue) * m_granularityValue;
        _loc3 = (_loc2 - m_bottomValue) / (m_topValue - m_bottomValue);
        if (nValue >= m_topValue)
        {
            _loc2 = m_topValue;
            _loc3 = 1;
        }
        else if (nValue <= 0)
        {
            _loc2 = m_bottomValue;
            _loc3 = 0;
        } // end else if
        m_percent = _loc3;
        m_value = _loc2;
        m_changed = true;
        this.arrange();
        this.runCallback();
    } // End of the function
    function getPercent()
    {
        return (m_percent);
    } // End of the function
    function getValue()
    {
        var _loc3;
        var _loc2 = m_value / m_labelMultiplier;
        return (_loc2.toString());
    } // End of the function
    function updateManager()
    {
        this.update();
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                if (_parent.m_labelAddonEnd.length > 0)
                {
                    title.text = dice.bf2.Logic.setDecimals(_parent.m_value, _parent.m_numDecimals) + _parent.m_labelAddonEnd;
                }
                else
                {
                    title.text = dice.bf2.Logic.setDecimals(_parent.m_value, _parent.m_numDecimals);
                } // end if
            } // End of with
        } // end else if
        if (this.m_lastValue != this.m_value)
        {
            if (this.m_soundId.length > 0)
            {
                dice.bf2.Sound.playSound(this.m_soundId);
            } // end if
            this.m_lastValue = this.m_value;
            if (this.m_runCBOnUpdate)
            {
                this.runCallback();
            } // end if
        } // end if
        return (this.m_updating);
    } // End of the function
    var m_sliderBgColor = dice.UI.prototype.m_UIBGColor;
    var m_bevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_bevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_sliderBevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_sliderBevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_baseAlpha = dice.UI.prototype.m_UIBGAlpha;
    var m_sliderAlpha = 100;
    var m_sliderBevelAlpha = 0;
    var m_showSliderBevel = false;
    var m_bevelAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_sliderColor = dice.UI.prototype.m_UITriggerColor;
    var m_labelColor = dice.UI.prototype.m_UITriggerColor;
    var m_labelTitleColor = dice.UI.prototype.m_UITriggerColorSelected;
    var m_labelXOffset = 0;
    var m_labelYOffset = 1;
    var m_lastValue = -1;
    var m_dragToggle = false;
    var m_dragTop = 0;
    var m_dragBottom = 0;
    var m_dragLeft = 0;
    var m_dragRight = 0;
    var m_dragClickYOffset = 0;
    var m_dragClickXOffset = 0;
    var m_percent = 0;
    var m_value = 0;
    var m_textValue = "";
    var m_mcLabelTextSet = false;
} // End of Class
