class dice.UIs.Forms.Radio extends dice.UIs.Form
{
    var _parent, m_radioX, __get__radioX, m_labelX, __get__labelX, __get__groupId, m_inAuthorMode, __get__isChecked, m_iconColor, __get__iconColor, m_labelFontCharPixelWidth, __get__labelFontCharPixelWidth, m_iconXOffset, __get__iconXOffset, m_iconYOffset, __get__iconYOffset, m_labelXOffset, __get__labelXOffset, m_labelYOffset, __get__labelYOffset, m_labelColor, __get__labelColor, m_labelLength, m_label, __get__label, mcBoundingBox, setCallbackObject, setCallbackGetObject, getNextHighestDepth, attachMovie, m_localizationId, m_mcLabel, m_mcRadioEdge, m_mcIconSelected, m_mcIcon, m_btSpecial, m_glowBackgroundEnabled, m_mcRadioBGGlow, setColor, m_glowAlphaEnabled, m_glowAlpha, _alpha, runCallback, m_changed, __set__groupId, __set__iconColor, __set__iconXOffset, __set__iconYOffset, __set__isChecked, __set__label, __set__labelColor, __set__labelFontCharPixelWidth, __set__labelX, __set__labelXOffset, __set__labelYOffset, __set__radioX;
    function Radio(cancelInit)
    {
        super(true);
        if (!_parent[identifier])
        {
            _parent[identifier] = new Array();
        } // end if
        _parent[identifier].push(this);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set radioX(nValue)
    {
        m_radioX = nValue;
        //return (this.radioX());
        null;
    } // End of the function
    function get radioX()
    {
        return (m_radioX);
    } // End of the function
    function set labelX(nValue)
    {
        m_labelX = nValue;
        //return (this.labelX());
        null;
    } // End of the function
    function get labelX()
    {
        return (m_labelX);
    } // End of the function
    function set groupId(nValue)
    {
        identifier = nValue;
        //return (this.groupId());
        null;
    } // End of the function
    function get groupId()
    {
        return (identifier);
    } // End of the function
    function set isChecked(nValue)
    {
        checked = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.isChecked());
        null;
    } // End of the function
    function get isChecked()
    {
        return (checked);
    } // End of the function
    function set iconColor(nValue)
    {
        m_iconColor = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.iconColor());
        null;
    } // End of the function
    function get iconColor()
    {
        return (m_iconColor);
    } // End of the function
    function set labelFontCharPixelWidth(nValue)
    {
        m_labelFontCharPixelWidth = nValue;
        //return (this.labelFontCharPixelWidth());
        null;
    } // End of the function
    function get labelFontCharPixelWidth()
    {
        return (m_labelFontCharPixelWidth);
    } // End of the function
    function set iconXOffset(Value)
    {
        m_iconXOffset = Value;
        //return (this.iconXOffset());
        null;
    } // End of the function
    function get iconXOffset()
    {
        return (m_iconXOffset);
    } // End of the function
    function set iconYOffset(Value)
    {
        m_iconYOffset = Value;
        //return (this.iconYOffset());
        null;
    } // End of the function
    function get iconYOffset()
    {
        return (m_iconYOffset);
    } // End of the function
    function set labelXOffset(Value)
    {
        m_labelXOffset = Value;
        //return (this.labelXOffset());
        null;
    } // End of the function
    function get labelXOffset()
    {
        return (m_labelXOffset);
    } // End of the function
    function set labelYOffset(Value)
    {
        m_labelYOffset = Value;
        //return (this.labelYOffset());
        null;
    } // End of the function
    function get labelYOffset()
    {
        return (m_labelYOffset);
    } // End of the function
    function set labelColor(nValue)
    {
        m_labelColor = nValue;
        //return (this.labelColor());
        null;
    } // End of the function
    function get labelColor()
    {
        return (m_labelColor);
    } // End of the function
    function set label(sValue)
    {
        var _loc2 = new String(sValue);
        m_labelLength = _loc2.length;
        m_label = sValue;
        //return (this.label());
        null;
    } // End of the function
    function get label()
    {
        return (m_label);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        this.setCallbackObject(_parent);
        this.setCallbackGetObject(this);
    } // End of the function
    function draw()
    {
    } // End of the function
    function createChildren()
    {
        this.attachMovie("mcRadioIcon", "m_mcIcon", this.getNextHighestDepth());
        this.attachMovie("mcRadioIcon_selected", "m_mcIconSelected", this.getNextHighestDepth());
        this.attachMovie("mcRadioLabel", "m_mcLabel", this.getNextHighestDepth());
        if (m_localizationId.length > 0)
        {
            mx.lang.Locale.addDelayedInstance(m_mcLabel.labelRadio, m_localizationId);
        } // end if
        this.attachMovie("mcRadioEdge", "m_mcRadioEdge", this.getNextHighestDepth());
        this.attachMovie("btRadioSpecial", "m_btSpecial", this.getNextHighestDepth());
        if (!m_inAuthorMode)
        {
            m_mcRadioEdge.loadMovie("images/components/radioButton_frame.png");
            m_mcIconSelected.loadMovie("images/components/radioButton_1.png");
            m_mcIcon.loadMovie("images/components/radioButton_0.png");
        } // end if
        if (m_localizationId.length > 0)
        {
            mx.lang.Locale.addDelayedInstance(m_mcLabel.labelRadio, m_localizationId);
        } // end if
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_btSpecial)
        {
            with (this.m_btSpecial)
            {
                _x = _parent.m_radioX;
                _y = 0;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
                _alpha = 0;
            } // End of with
        } // end if
        if (this.m_mcRadioEdge)
        {
            with (this.m_mcRadioEdge)
            {
                _y = 0;
                _x = _parent.m_radioX;
                _width = _parent.m_initHeight;
                _height = _parent.m_initHeight;
            } // End of with
        } // end if
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                _x = _parent.m_labelX + _parent.m_labelXOffset;
                _y = _parent.m_initHeight / 2 - labelRadio._height / 2 + _parent.m_labelYOffset;
                if (labelRadio)
                {
                    with (labelRadio)
                    {
                        if (_parent._parent.m_localizationId.length > 0)
                        {
                            text = _parent._parent.m_localizationId;
                        }
                        else
                        {
                            text = _parent._parent.m_label;
                        } // end else if
                        if (_parent._parent.m_radioX > _parent._x)
                        {
                            _width = _parent._parent.m_radioX - (5 + _parent._x);
                        }
                        else
                        {
                            _width = _parent._parent.m_initWidth - _parent._x;
                        } // end else if
                        textColor = _parent._parent.m_labelColor;
                        _x = 0;
                        _y = 0;
                    } // End of with
                } // end if
            } // End of with
        } // end if
        if (this.m_mcIcon)
        {
            with (this.m_mcIcon)
            {
                _width = _parent.m_mcRadioEdge._height - _parent.m_edgeThickness * 6;
                _height = _parent.m_mcRadioEdge._height - _parent.m_edgeThickness * 6;
                _x = _parent.m_edgeThickness * 3 + _parent.m_radioX;
                _y = _parent.m_edgeThickness * 3;
                _alpha = 0;
            } // End of with
        } // end if
        if (this.m_mcIconSelected)
        {
            with (this.m_mcIconSelected)
            {
                _width = _parent.m_mcRadioEdge._height - _parent.m_edgeThickness * 6;
                _height = _parent.m_mcRadioEdge._height - _parent.m_edgeThickness * 6;
                _x = _parent.m_edgeThickness * 3 + _parent.m_radioX;
                _y = _parent.m_edgeThickness * 3;
                _alpha = 0;
            } // End of with
        } // end if
        this.toggleCheck(this.checked);
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function setGlow(glow, glowColor)
    {
        if (m_glowBackgroundEnabled)
        {
            this.setColor(m_mcRadioBGGlow, glowColor);
            m_mcRadioBGGlow._alpha = glow;
        } // end if
        if (m_glowAlphaEnabled)
        {
            _alpha = m_glowAlpha;
        } // end if
    } // End of the function
    function update()
    {
        var _loc2 = false;
        if (super.update())
        {
            _loc2 = true;
        } // end if
        return (_loc2);
    } // End of the function
    function setEvents()
    {
        m_btSpecial.onPress = function ()
        {
            dice.bf2.Sound.playSound("radioSelect");
            _parent.toggleCheck(true);
        };
    } // End of the function
    function toggleCheck(overRide, noCallback)
    {
        if (overRide == true)
        {
            var _loc3 = _parent[identifier];
            if (_loc3)
            {
                for (var _loc5 in _loc3)
                {
                    var _loc2 = _loc3[_loc5];
                    if (_loc2 != this)
                    {
                        _loc2.toggleCheck(false, noCallback);
                    } // end if
                } // end of for...in
            } // end if
            checked = true;
            if (!noCallback)
            {
                this.runCallback();
            } // end if
            m_mcIconSelected._alpha = 100;
            m_mcIcon._alpha = 0;
        }
        else if (overRide == false)
        {
            checked = false;
            m_mcIconSelected._alpha = 0;
            m_mcIcon._alpha = 100;
        } // end else if
        m_changed = true;
        return (checked);
    } // End of the function
    function setValue(bValue, noCallback)
    {
        this.toggleCheck(bValue, noCallback);
    } // End of the function
    function getValue()
    {
        return (checked);
    } // End of the function
    var m_buttonBGColor = 201249;
    var m_buttonBGAlpha = 70;
    var checked = false;
    var identifier = "";
} // End of Class
