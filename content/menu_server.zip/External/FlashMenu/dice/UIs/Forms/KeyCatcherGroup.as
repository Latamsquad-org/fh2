class dice.UIs.Forms.KeyCatcherGroup extends dice.UIs.Form
{
    var m_inAuthorMode, __get__superceedAllControlMaps, m_localizationId2, __get__localizationId2, __get__primaryLabelText, __get__secondaryLabelText, m_catcherX, __get__catcherX, __get__enableSecondary, __get__enableNegative, m_isCommon, __get__isCommon, m_keyId, __get__keyId, m_stringValuePress, __get__stringValuePress, _parent, mcBoundingBox, m_mcPPLabel, m_mcPPBGGlow, m_mcPNLabel, m_mcPNBGGlow, m_mcSPLabel, m_mcSPBGGlow, m_mcSNLabel, m_mcSNBGGlow, m_labelGlowColor, mixColors, getNextHighestDepth, createEmptyMovieClip, m_mcPPBG, m_mcSPBG, m_mcPNBG, m_mcSNBG, attachMovie, m_localizationId, m_mcPrimaryLabel, m_mcNegativeLabel, m_initWidth, m_initHeight, setColor, __set__catcherX, __set__enableNegative, __set__enableSecondary, __set__isCommon, __set__keyId, __set__localizationId2, __set__primaryLabelText, __set__secondaryLabelText, __set__stringValuePress, __set__superceedAllControlMaps;
    function KeyCatcherGroup(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set superceedAllControlMaps(nValue)
    {
        m_superceed = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.superceedAllControlMaps());
        null;
    } // End of the function
    function get superceedAllControlMaps()
    {
        return (m_superceed);
    } // End of the function
    function set localizationId2(nValue)
    {
        m_localizationId2 = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.localizationId2());
        null;
    } // End of the function
    function get localizationId2()
    {
        return (m_localizationId2);
    } // End of the function
    function set primaryLabelText(sValue)
    {
        m_primaryLabelText = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.primaryLabelText());
        null;
    } // End of the function
    function get primaryLabelText()
    {
        return (m_primaryLabelText);
    } // End of the function
    function set secondaryLabelText(sValue)
    {
        m_secondaryLabelText = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.secondaryLabelText());
        null;
    } // End of the function
    function get secondaryLabelText()
    {
        return (m_secondaryLabelText);
    } // End of the function
    function set catcherX(sValue)
    {
        m_catcherX = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.catcherX());
        null;
    } // End of the function
    function get catcherX()
    {
        return (m_catcherX);
    } // End of the function
    function set enableSecondary(sValue)
    {
        m_enableSecondary = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.enableSecondary());
        null;
    } // End of the function
    function get enableSecondary()
    {
        return (m_enableSecondary);
    } // End of the function
    function set enableNegative(sValue)
    {
        m_enableNegative = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.enableNegative());
        null;
    } // End of the function
    function get enableNegative()
    {
        return (m_enableNegative);
    } // End of the function
    function set isCommon(sValue)
    {
        m_isCommon = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.isCommon());
        null;
    } // End of the function
    function get isCommon()
    {
        return (m_isCommon);
    } // End of the function
    function set keyId(sValue)
    {
        m_keyId = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.keyId());
        null;
    } // End of the function
    function get keyId()
    {
        return (m_keyId);
    } // End of the function
    function set stringValuePress(sValue)
    {
        m_stringValuePress = sValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.stringValuePress());
        null;
    } // End of the function
    function get stringValuePress()
    {
        return (m_stringValuePress);
    } // End of the function
    function init()
    {
        super.init();
        if (!_parent.keygroups)
        {
            _parent.keygroups = new Array();
        } // end if
        _parent.keygroups.push(this);
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
    } // End of the function
    function glowPP()
    {
        var _loc2 = this.glow(m_mcPPBGGlow, m_mcPPLabel, m_glowUpPP);
        m_glowingInProgressPP = _loc2;
        return (_loc2);
    } // End of the function
    function glowPN()
    {
        var _loc2 = this.glow(m_mcPNBGGlow, m_mcPNLabel, m_glowUpPN);
        m_glowingInProgressPN = _loc2;
        return (_loc2);
    } // End of the function
    function glowSP()
    {
        var _loc2 = this.glow(m_mcSPBGGlow, m_mcSPLabel, m_glowUpSP);
        m_glowingInProgressSP = _loc2;
        return (_loc2);
    } // End of the function
    function glowSN()
    {
        var _loc2 = this.glow(m_mcSNBGGlow, m_mcSNLabel, m_glowUpSN);
        m_glowingInProgressSN = _loc2;
        return (_loc2);
    } // End of the function
    function glow(glowMc, textFieldMc, glowUpState)
    {
        var _loc5 = glowMc._alpha;
        var _loc2 = _loc5;
        var _loc3 = _loc2 / m_glowMax;
        if (glowUpState)
        {
            _loc2 = _loc2 + (m_glowMax - m_glowMin) / m_glowTime;
            _loc3 = _loc2 / m_glowMax;
            if (_loc2 <= m_glowMax)
            {
                glowMc._alpha = _loc2;
                if (m_glowText)
                {
                    textFieldMc.keyCatcherGroupField.textColor = this.mixColors(m_labelColor, m_labelGlowColor, _loc3);
                } // end if
                return (true);
            } // end if
        }
        else
        {
            _loc2 = _loc2 - (m_glowMax - m_glowMin) / m_glowTime;
            _loc3 = _loc2 / m_glowMax;
            if (_loc2 >= m_glowMin)
            {
                glowMc._alpha = _loc2;
                if (m_glowText)
                {
                    textFieldMc.keyCatcherGroupField.textColor = this.mixColors(m_labelColor, m_labelGlowColor, _loc3);
                } // end if
                return (true);
            } // end if
            textFieldMc.keyCatcherGroupField.textColor = m_labelColor;
            return (false);
        } // end else if
        return (false);
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcPPBG", this.getNextHighestDepth());
        with (this.m_mcPPBG)
        {
            lineStyle(0, _parent.m_keyCatcherColor, 0);
            beginFill(_parent.m_keyCatcherColor, _parent.m_keyCatcherAlpha);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        if (this.m_enableSecondary)
        {
            this.createEmptyMovieClip("m_mcSPBG", this.getNextHighestDepth());
            with (this.m_mcSPBG)
            {
                lineStyle(0, _parent.m_keyCatcherColor, 0);
                beginFill(_parent.m_keyCatcherColor, _parent.m_keyCatcherAlpha);
                moveTo(0, 0);
                lineTo(0, 100);
                lineTo(100, 100);
                lineTo(100, 0);
                endFill();
            } // End of with
        } // end if
        if (this.m_enableNegative)
        {
            this.createEmptyMovieClip("m_mcPNBG", this.getNextHighestDepth());
            with (this.m_mcPNBG)
            {
                lineStyle(0, _parent.m_keyCatcherColor, 0);
                beginFill(_parent.m_keyCatcherColor, _parent.m_keyCatcherAlpha);
                moveTo(0, 0);
                lineTo(0, 100);
                lineTo(100, 100);
                lineTo(100, 0);
                endFill();
            } // End of with
            if (this.m_enableSecondary)
            {
                this.createEmptyMovieClip("m_mcSNBG", this.getNextHighestDepth());
                with (this.m_mcSNBG)
                {
                    lineStyle(0, _parent.m_keyCatcherColor, 0);
                    beginFill(_parent.m_keyCatcherColor, _parent.m_keyCatcherAlpha);
                    moveTo(0, 0);
                    lineTo(0, 100);
                    lineTo(100, 100);
                    lineTo(100, 0);
                    endFill();
                } // End of with
            } // end if
        } // end if
    } // End of the function
    function createChildren()
    {
        this.attachMovie("mcKeyCatcherGroup", "m_mcPrimaryLabel", this.getNextHighestDepth());
        if (m_localizationId.length > 0)
        {
            mx.lang.Locale.addDelayedInstance(m_mcPrimaryLabel.keyCatcherGroupField, m_localizationId);
        } // end if
        if (m_enableNegative)
        {
            this.attachMovie("mcKeyCatcherGroup", "m_mcNegativeLabel", this.getNextHighestDepth());
            if (m_localizationId.length > 0)
            {
                mx.lang.Locale.addDelayedInstance(m_mcNegativeLabel.keyCatcherGroupField, m_localizationId2);
            } // end if
        } // end if
        this.attachMovie("mcKeyCatcherGroupDesc", "m_mcPPLabel", this.getNextHighestDepth());
        if (m_enableSecondary)
        {
            this.attachMovie("mcKeyCatcherGroupDesc", "m_mcSPLabel", this.getNextHighestDepth());
        } // end if
        if (m_enableNegative)
        {
            this.attachMovie("mcKeyCatcherGroupDesc", "m_mcPNLabel", this.getNextHighestDepth());
            if (m_enableSecondary)
            {
                this.attachMovie("mcKeyCatcherGroupDesc", "m_mcSNLabel", this.getNextHighestDepth());
            } // end if
        } // end if
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        var catcherHeight = 0;
        var catcherWidth = 0;
        var catcherAreaWidth = this.m_initWidth - this.m_catcherX;
        if (this.m_enableNegative)
        {
            catcherHeight = (this.m_initHeight - 5) / 2;
        }
        else
        {
            catcherHeight = this.m_initHeight;
        } // end else if
        if (this.m_enableSecondary)
        {
            catcherWidth = (catcherAreaWidth - 5) / 2;
        }
        else
        {
            catcherWidth = catcherAreaWidth;
        } // end else if
        if (this.m_mcPrimaryLabel)
        {
            with (this.m_mcPrimaryLabel)
            {
                _x = 0;
                _y = catcherHeight / 2 - keyCatcherGroupField._height / 2;
                with (keyCatcherGroupField)
                {
                    _width = _parent._parent.m_catcherX - 5;
                    if (_parent._parent.m_localizationId.length > 0)
                    {
                        text = _parent._parent.m_localizationId;
                    }
                    else
                    {
                        text = _parent._parent.m_primaryLabelText;
                    } // end else if
                    textColor = _parent._parent.m_labelColor;
                } // End of with
            } // End of with
        } // end if
        if (this.m_mcNegativeLabel)
        {
            with (this.m_mcNegativeLabel)
            {
                _x = 0;
                _y = _parent.m_initHeight / 2 + (catcherHeight / 2 - keyCatcherGroupField._height / 2);
                with (keyCatcherGroupField)
                {
                    _width = _parent._parent.m_catcherX - 5;
                    if (_parent._parent.m_localizationId2.length > 0)
                    {
                        text = _parent._parent.m_localizationId2;
                    }
                    else
                    {
                        text = _parent._parent.m_secondaryLabelText;
                    } // end else if
                    textColor = _parent._parent.m_labelColor;
                } // End of with
            } // End of with
        } // end if
        if (this.m_mcPPBG)
        {
            with (this.m_mcPPBG)
            {
                _y = 0;
                _x = _parent.m_catcherX;
                _width = catcherWidth;
                _height = catcherHeight;
                _alpha = _parent.m_keyCatcherAlpha;
            } // End of with
        } // end if
        if (this.m_mcPPBGGlow)
        {
            with (this.m_mcPPBGGlow)
            {
                _y = 0;
                _x = _parent.m_catcherX;
                _width = catcherWidth;
                _height = catcherHeight;
                _alpha = _parent.m_glowInit;
            } // End of with
        } // end if
        if (this.m_mcSPBG)
        {
            with (this.m_mcSPBG)
            {
                _y = 0;
                _x = _parent.m_catcherX + (catcherAreaWidth - catcherWidth);
                _width = catcherWidth;
                _height = catcherHeight;
                _alpha = _parent.m_keyCatcherAlpha;
            } // End of with
        } // end if
        if (this.m_mcSPBGGlow)
        {
            with (this.m_mcSPBGGlow)
            {
                _y = 0;
                _x = _parent.m_catcherX + (catcherAreaWidth - catcherWidth);
                _width = catcherWidth;
                _height = catcherHeight;
                _alpha = _parent.m_glowInit;
            } // End of with
        } // end if
        if (this.m_mcPNBG)
        {
            with (this.m_mcPNBG)
            {
                _y = _parent.m_initHeight - catcherHeight;
                _x = _parent.m_catcherX;
                _width = catcherWidth;
                _height = catcherHeight;
                _alpha = _parent.m_keyCatcherAlpha;
            } // End of with
        } // end if
        if (this.m_mcPNBGGlow)
        {
            with (this.m_mcPNBGGlow)
            {
                _y = _parent.m_initHeight - catcherHeight;
                _x = _parent.m_catcherX;
                _width = catcherWidth;
                _height = catcherHeight;
                _alpha = _parent.m_glowInit;
            } // End of with
        } // end if
        if (this.m_mcSNBG)
        {
            with (this.m_mcSNBG)
            {
                _y = _parent.m_initHeight - catcherHeight;
                _x = _parent.m_catcherX + (catcherAreaWidth - catcherWidth);
                _width = catcherWidth;
                _height = catcherHeight;
                _alpha = _parent.m_keyCatcherAlpha;
            } // End of with
        } // end if
        if (this.m_mcSNBGGlow)
        {
            with (this.m_mcSNBGGlow)
            {
                _y = _parent.m_initHeight - catcherHeight;
                _x = _parent.m_catcherX + (catcherAreaWidth - catcherWidth);
                _width = catcherWidth;
                _height = catcherHeight;
                _alpha = _parent.m_glowInit;
            } // End of with
        } // end if
        if (this.m_mcPPLabel)
        {
            with (this.m_mcPPLabel)
            {
                _x = _parent.m_mcPPBG._x;
                _y = _parent.m_mcPPBG._y + (catcherHeight / 2 - keyCatcherGroupField._height / 2);
                with (keyCatcherGroupField)
                {
                    textColor = _parent._parent.m_edgeColor;
                    _width = catcherWidth;
                    text = "";
                } // End of with
            } // End of with
        } // end if
        if (this.m_mcPNLabel)
        {
            with (this.m_mcPNLabel)
            {
                _x = _parent.m_mcPNBG._x;
                _y = _parent.m_mcPNBG._y + (catcherHeight / 2 - keyCatcherGroupField._height / 2);
                with (keyCatcherGroupField)
                {
                    textColor = _parent._parent.m_edgeColor;
                    _width = catcherWidth;
                    text = "";
                } // End of with
            } // End of with
        } // end if
        if (this.m_mcSPLabel)
        {
            with (this.m_mcSPLabel)
            {
                _x = _parent.m_mcSPBG._x;
                _y = _parent.m_mcSPBG._y + (catcherHeight / 2 - keyCatcherGroupField._height / 2);
                with (keyCatcherGroupField)
                {
                    textColor = _parent._parent.m_edgeColor;
                    _width = catcherWidth;
                    text = "";
                } // End of with
            } // End of with
        } // end if
        if (this.m_mcSNLabel)
        {
            with (this.m_mcSNLabel)
            {
                _x = _parent.m_mcSNBG._x;
                _y = _parent.m_mcSNBG._y + (catcherHeight / 2 - keyCatcherGroupField._height / 2);
                with (keyCatcherGroupField)
                {
                    textColor = _parent._parent.m_edgeColor;
                    _width = catcherWidth;
                    text = "";
                } // End of with
            } // End of with
        } // end if
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function update()
    {
        var _loc2 = false;
        if (super.update())
        {
            _loc2 = true;
        } // end if
        return (_loc2);
    } // End of the function
    function getKeyCatcher(isBackground, secondary, negative)
    {
        if (isBackground)
        {
            if (!secondary && !negative)
            {
                return (m_mcPPBG);
            }
            else if (!secondary && negative)
            {
                return (m_mcPNBG);
            }
            else if (secondary && !negative)
            {
                return (m_mcSPBG);
            }
            else
            {
                return (m_mcSNBG);
            } // end else if
        }
        else if (!secondary && !negative)
        {
            return (m_mcPPLabel);
        }
        else if (!secondary && negative)
        {
            return (m_mcPNLabel);
        }
        else if (secondary && !negative)
        {
            return (m_mcSPLabel);
        }
        else
        {
            return (m_mcSNLabel);
        } // end else if
    } // End of the function
    function selectKeyCatcher(deSelect, secondary, negative)
    {
        var _loc2 = this.getKeyCatcher(true, secondary, negative);
        if (deSelect)
        {
            this.setColor(_loc2, m_keyCatcherColor);
            _loc2._alpha = m_keyCatcherAlpha;
        }
        else
        {
            this.setColor(_loc2, m_keyCatcherColorSelected);
            _loc2._alpha = m_keyCatcherAlphaSelected;
        } // end else if
    } // End of the function
    function pressEvent(secondary, negative)
    {
        if (m_inCatchState)
        {
        }
        else
        {
            m_inCatchState = true;
            dice.bf2.ControlSettings.setActiveControlMap(_root.activeControlMap.toString());
            if (m_superceed)
            {
                dice.bf2.ControlSettings.setActiveControlMap("6");
            }
            else if (m_isCommon)
            {
                dice.bf2.ControlSettings.setActiveControlMap("5");
            } // end else if
            var _loc5 = dice.bf2.ControlSettings.mapInput(m_keyId, secondary, negative, m_superceed);
            this.resetValues();
            this.selectKeyCatcher(true, secondary, negative);
            m_inCatchState = false;
        } // end else if
    } // End of the function
    function resetValues()
    {
        trace ("RESET VALUES FOR: " + m_keyId);
        if (m_superceed)
        {
            dice.bf2.ControlSettings.setActiveControlMap("6");
        }
        else if (m_isCommon)
        {
            dice.bf2.ControlSettings.setActiveControlMap("5");
        }
        else
        {
            dice.bf2.ControlSettings.setActiveControlMap(dice.bf2.Logic.getStorageString("currentControlMap", "1"));
        } // end else if
        m_mcPPLabel.keyCatcherGroupField.text = dice.bf2.ControlSettings.getMappedString(m_keyId, false, false);
        m_mcPNLabel.keyCatcherGroupField.text = dice.bf2.ControlSettings.getMappedString(m_keyId, false, true);
        m_mcSPLabel.keyCatcherGroupField.text = dice.bf2.ControlSettings.getMappedString(m_keyId, true, false);
        m_mcSNLabel.keyCatcherGroupField.text = dice.bf2.ControlSettings.getMappedString(m_keyId, true, true);
    } // End of the function
    function setEvents()
    {
        trace ("setEvents");
        m_mcPPBG.onPress = function ()
        {
            if (!_parent.m_inCatchState)
            {
                dice.bf2.Sound.playSound("keyCatcherClick");
                _parent.selectKeyCatcher(false, false, false);
            } // end if
        };
        m_mcPPLabel.onPress = function ()
        {
            if (!_parent.m_inCatchState)
            {
                dice.bf2.Sound.playSound("keyCatcherClick");
                _parent.selectKeyCatcher(false, false, false);
            } // end if
        };
        m_mcPNBG.onPress = function ()
        {
            if (!_parent.m_inCatchState)
            {
                dice.bf2.Sound.playSound("keyCatcherClick");
                _parent.selectKeyCatcher(false, false, true);
            } // end if
        };
        m_mcPNLabel.onPress = function ()
        {
            if (!_parent.m_inCatchState)
            {
                dice.bf2.Sound.playSound("keyCatcherClick");
                _parent.selectKeyCatcher(false, false, true);
            } // end if
        };
        m_mcSPBG.onPress = function ()
        {
            if (!_parent.m_inCatchState)
            {
                dice.bf2.Sound.playSound("keyCatcherClick");
                _parent.selectKeyCatcher(false, true, false);
            } // end if
        };
        m_mcSPLabel.onPress = function ()
        {
            if (!_parent.m_inCatchState)
            {
                dice.bf2.Sound.playSound("keyCatcherClick");
                _parent.selectKeyCatcher(false, true, false);
            } // end if
        };
        m_mcSNBG.onPress = function ()
        {
            if (!_parent.m_inCatchState)
            {
                dice.bf2.Sound.playSound("keyCatcherClick");
                _parent.selectKeyCatcher(false, true, true);
            } // end if
        };
        m_mcSNLabel.onPress = function ()
        {
            if (!_parent.m_inCatchState)
            {
                dice.bf2.Sound.playSound("keyCatcherClick");
                _parent.selectKeyCatcher(false, true, true);
            } // end if
        };
        m_mcPPBG.onRelease = function ()
        {
            _parent.releaseFunction(false, false);
        };
        m_mcPPLabel.onRelease = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.pressEvent(false, false);
            } // end if
        };
        m_mcPNBG.onRelease = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.pressEvent(false, true);
            } // end if
        };
        m_mcPNLabel.onRelease = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.pressEvent(false, true);
            } // end if
        };
        m_mcSPBG.onRelease = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.pressEvent(true, false);
            } // end if
        };
        m_mcSPLabel.onRelease = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.pressEvent(true, false);
            } // end if
        };
        m_mcSNBG.onRelease = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.pressEvent(true, true);
            } // end if
        };
        m_mcSNLabel.onRelease = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.pressEvent(true, true);
            } // end if
        };
        m_mcPPBG.onReleaseOutside = function ()
        {
            _parent.selectKeyCatcher(true, false, false);
        };
        m_mcPPLabel.onReleaseOutside = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.selectKeyCatcher(true, false, false);
            } // end if
        };
        m_mcPNBG.onReleaseOutside = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.selectKeyCatcher(true, false, true);
            } // end if
        };
        m_mcPNLabel.onReleaseOutside = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.selectKeyCatcher(true, false, true);
            } // end if
        };
        m_mcSPBG.onReleaseOutside = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.selectKeyCatcher(true, true, false);
            } // end if
        };
        m_mcSPLabel.onReleaseOutside = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.selectKeyCatcher(true, true, false);
            } // end if
        };
        m_mcSNBG.onReleaseOutside = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.selectKeyCatcher(true, true, true);
            } // end if
        };
        m_mcSNLabel.onReleaseOutside = function ()
        {
            if (!_parent.m_inCatchState)
            {
                _parent.selectKeyCatcher(true, true, true);
            } // end if
        };
    } // End of the function
    var m_glowUpPP = false;
    var m_glowUpPN = false;
    var m_glowUpSP = false;
    var m_glowUpSN = false;
    var m_glowMax = 25;
    var m_glowMin = 0;
    var m_glowInit = dice.UIs.Forms.KeyCatcherGroup.prototype.m_glowMin;
    var m_glowingInProgressPP = false;
    var m_glowingInProgressPN = false;
    var m_glowingInProgressSP = false;
    var m_glowingInProgressSN = false;
    var m_glowTime = 4;
    var m_glowText = false;
    var m_keyCatcherColor = dice.UI.prototype.m_UIBGColor;
    var m_keyCatcherAlpha = dice.UI.prototype.m_UIBGAlpha;
    var m_keyCatcherColorSelected = 5195313;
    var m_keyCatcherAlphaSelected = 100;
    var m_labelColor = 16777215;
    var m_primaryLabelText = "";
    var m_secondaryLabelText = "";
    var m_inCatchState = false;
    var m_PPinCatchState = false;
    var m_PNinCatchState = false;
    var m_SPinCatchState = false;
    var m_SNinCatchState = false;
    var m_enableSecondary = true;
    var m_enableNegative = false;
    var m_superceed = false;
} // End of Class
