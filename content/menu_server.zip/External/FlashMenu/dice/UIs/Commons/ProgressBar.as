class dice.UIs.Commons.ProgressBar extends dice.UIs.Common
{
    var m_labelOffsetX, m_inAuthorMode, __get__labelOffsetX, m_labelOffsetY, __get__labelOffsetY, m_labelUsesNegatoryData, __get__labelUsesNegatoryData, m_labelMultiplier, __get__labelMultiplier, __get__labelAddonEnd, m_labelWidth, __get__labelWidth, m_decimalsVisible, __get__decimalsVisible, m_useLabel, __get__useLabel, __get__progressInitPercent, m_progressColorLow, __get__progressColorLow, m_progressColorHigh, __get__progressColorHigh, mcBoundingBox, _parent, setCallbackObject, setCallbackGetObject, getNextHighestDepth, createEmptyMovieClip, m_mcProgressContainer, attachMovie, m_mcLabel, m_initWidth, setColor, m_changed, m_callbackFrequency, runCallback, __set__decimalsVisible, __set__labelAddonEnd, __set__labelMultiplier, __set__labelOffsetX, __set__labelOffsetY, __set__labelUsesNegatoryData, __set__labelWidth, __set__progressColorHigh, __set__progressColorLow, __set__progressInitPercent, __set__useLabel;
    function ProgressBar(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set labelOffsetX(nValue)
    {
        m_labelOffsetX = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelOffsetX());
        null;
    } // End of the function
    function get labelOffsetX()
    {
        return (m_labelOffsetX);
    } // End of the function
    function set labelOffsetY(nValue)
    {
        m_labelOffsetY = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelOffsetY());
        null;
    } // End of the function
    function get labelOffsetY()
    {
        return (m_labelOffsetY);
    } // End of the function
    function set labelUsesNegatoryData(nValue)
    {
        m_labelUsesNegatoryData = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelUsesNegatoryData());
        null;
    } // End of the function
    function get labelUsesNegatoryData()
    {
        return (m_labelUsesNegatoryData);
    } // End of the function
    function set labelMultiplier(nValue)
    {
        m_labelMultiplier = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelMultiplier());
        null;
    } // End of the function
    function get labelMultiplier()
    {
        return (m_labelMultiplier);
    } // End of the function
    function set labelAddonEnd(nValue)
    {
        m_labelAddonEnd = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelAddonEnd());
        null;
    } // End of the function
    function get labelAddonEnd()
    {
        return (m_labelAddonEnd);
    } // End of the function
    function set labelWidth(nValue)
    {
        m_labelWidth = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelWidth());
        null;
    } // End of the function
    function get labelWidth()
    {
        return (m_labelWidth);
    } // End of the function
    function set decimalsVisible(nValue)
    {
        m_decimalsVisible = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.decimalsVisible());
        null;
    } // End of the function
    function get decimalsVisible()
    {
        return (m_decimalsVisible);
    } // End of the function
    function set useLabel(nValue)
    {
        m_useLabel = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.useLabel());
        null;
    } // End of the function
    function get useLabel()
    {
        return (m_useLabel);
    } // End of the function
    function set progressInitPercent(nValue)
    {
        this.setValue(nValue);
        //return (this.progressInitPercent());
        null;
    } // End of the function
    function get progressInitPercent()
    {
        return (this.getValue());
    } // End of the function
    function set progressColorLow(nValue)
    {
        m_progressColorLow = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.progressColorLow());
        null;
    } // End of the function
    function get progressColorLow()
    {
        return (m_progressColorLow);
    } // End of the function
    function set progressColorHigh(nValue)
    {
        m_progressColorHigh = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.progressColorHigh());
        null;
    } // End of the function
    function get progressColorHigh()
    {
        return (m_progressColorHigh);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        this.setCallbackObject(_parent);
        this.setCallbackGetObject(this);
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcProgressContainer", this.getNextHighestDepth());
        with (this.m_mcProgressContainer)
        {
            createEmptyMovieClip("background", getNextHighestDepth());
            with (background)
            {
                lineStyle(0, _parent._parent.m_baseColor, 0);
                beginFill(_parent._parent.m_baseColor, 100);
                moveTo(0, 0);
                lineTo(0, 100);
                lineTo(100, 100);
                lineTo(100, 0);
                endFill();
            } // End of with
            createEmptyMovieClip("slider", getNextHighestDepth());
            with (slider)
            {
                lineStyle(0, _parent._parent.m_baseColor, 0);
                beginFill(_parent._parent.m_baseColor, 100);
                moveTo(0, 0);
                lineTo(0, 100);
                lineTo(100, 100);
                lineTo(100, 0);
                endFill();
            } // End of with
            createEmptyMovieClip("edge", getNextHighestDepth());
            with (edge)
            {
                lineStyle(0, _parent._parent.m_edgeColor, _parent._parent.m_edgeAlpha);
                moveTo(0, 100);
                lineTo(0, 0);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
            } // End of with
        } // End of with
    } // End of the function
    function createChildren()
    {
        if (m_useLabel)
        {
            this.attachMovie("mcProgressBarLabelLarge", "m_mcLabel", this.getNextHighestDepth());
        } // end if
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                _x = _parent.m_initWidth - _parent.m_labelWidth + _parent.m_labelOffsetX;
                _y = _parent.m_initHeight / 2 - progressLabel._height / 2;
                progressLabel.text = Math.round(_parent.m_percent * _parent.m_labelMultiplier).toString() + _parent.m_labelAddonEnd;
                with (progressLabel)
                {
                    textColor = _parent._parent.m_progressColorHigh;
                    _width = _parent._parent.m_labelWidth;
                } // End of with
            } // End of with
        } // end if
        this.setProgressBar();
        if (this.m_mcProgressContainer)
        {
            var progressWidth = 0;
            if (this.m_useLabel)
            {
                progressWidth = this.m_initWidth - this.m_labelWidth;
            }
            else
            {
                progressWidth = this.m_initWidth;
            } // end else if
            with (this.m_mcProgressContainer)
            {
                if (edge)
                {
                    with (edge)
                    {
                        _x = 0;
                        _y = 0;
                        _width = progressWidth;
                        _height = _parent._parent.m_initHeight;
                    } // End of with
                } // end if
            } // End of with
        } // end if
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function setGlow(glow, glowColor)
    {
    } // End of the function
    function setProgressBar()
    {
        if (this.m_mcProgressContainer)
        {
            var progressWidth = 0;
            if (this.m_useLabel)
            {
                progressWidth = this.m_initWidth - this.m_labelWidth;
            }
            else
            {
                progressWidth = this.m_initWidth;
            } // end else if
            with (this.m_mcProgressContainer)
            {
                with (background)
                {
                    _width = progressWidth;
                    _height = _parent._parent.m_initHeight;
                    _x = 0;
                    _y = 0;
                    _alpha = _parent._parent.m_baseAlpha;
                } // End of with
                with (slider)
                {
                    var tempWidth = progressWidth * _parent._parent.m_percent;
                    if (tempWidth > 0)
                    {
                        _width = tempWidth;
                    }
                    else
                    {
                        _width = 0;
                    } // end else if
                    _height = _parent._parent.m_initHeight;
                    _x = 0;
                    _y = 0;
                    _alpha = _parent._parent.m_sliderAlpha;
                } // End of with
            } // End of with
            this.setColor(this.m_mcProgressContainer.background, this.m_baseColor);
            this.setColor(this.m_mcProgressContainer.slider, this.m_progressColor);
        } // end if
    } // End of the function
    function update()
    {
        super.update();
        var _loc3 = m_changed;
        m_changed = false;
        return (_loc3);
    } // End of the function
    function setEvents()
    {
    } // End of the function
    function startUpdate()
    {
        if (m_stopUpdate)
        {
            m_stopUpdate = false;
            _root.updateManager1.registerCallback(this, "updateManager", m_callbackFrequency);
        } // end if
    } // End of the function
    function updateManager()
    {
        var _loc2 = this.runCallback();
        if (m_stopUpdate)
        {
            return (false);
        }
        else
        {
            return (_loc2);
        } // end else if
    } // End of the function
    function stopUpdates()
    {
        m_stopUpdate = true;
    } // End of the function
    function setValue(nValue)
    {
        if (nValue > 1)
        {
            nValue = 1;
        } // end if
        this.m_percent = nValue;
        this.m_changed = true;
        var nValue = this.m_percent * 100;
        var sCurrentValue = nValue.toString().length;
        var sCurrentMatch = Math.round(nValue).toString().length + this.m_decimalsVisible;
        var decimalZeros = "";
        var sReturnValue = "";
        if (sCurrentValue != sCurrentMatch && this.m_decimalsVisible > 0)
        {
            decimalZeros = "";
            var removeAmount = 0;
            if (sCurrentMatch - sCurrentValue > this.m_decimalsVisible)
            {
                removeAmount = sCurrentMatch - sCurrentValue - this.m_decimalsVisible;
                decimalZeros = ".";
            } // end if
            var i = 0;
            while (i < sCurrentMatch - sCurrentValue - removeAmount)
            {
                decimalZeros = decimalZeros + "0";
                ++i;
            } // end while
            sReturnValue = nValue.toString() + decimalZeros;
        }
        else
        {
            sReturnValue = Math.round(nValue).toString();
        } // end else if
        if (this.m_mcLabel)
        {
            var labelPercent = this.m_percent;
            if (this.m_labelUsesNegatoryData)
            {
                labelPercent = (labelPercent - 1) * -1;
            } // end if
            var labelValue = Math.round(labelPercent * this.m_labelMultiplier);
            with (this.m_mcLabel)
            {
                progressLabel.text = labelValue + _parent.m_labelAddonEnd;
            } // End of with
        } // end if
        this.setProgressBar();
    } // End of the function
    function setLabelType(multiplier, addon, negateLabel)
    {
        m_labelMultiplier = multiplier;
        m_labelAddonEnd = addon;
        m_labelUsesNegatoryData = negateLabel;
    } // End of the function
    function getValue()
    {
        return (m_percent);
    } // End of the function
    var m_edgeColor = 16777215;
    var m_edgeAlpha = 20;
    var m_sliderAlpha = 100;
    var m_progressColor = dice.UI.prototype.m_UITriggerColorSelected;
    var m_baseColor = dice.UI.prototype.m_UIBGColor;
    var m_baseAlpha = 0;
    var m_labelAddonEnd = "";
    var m_percent = 0;
    var m_stopUpdate = true;
} // End of Class
