class dice.UIs.Commons.TextContainer extends dice.UIs.Common
{
    var m_isTitle, m_inAuthorMode, __get__textFormat_isColumnTitle, m_dynamicText, __get__textFormat_isDynamic, m_dynamicTextLarge, __get__textFormat_dynamicLarge, m_bold, __get__textFormat_bold, m_multiline, __get__textFormat_multiline, m_labelColor, __get__labelColor, m_align, __get__textFormat_align, m_labelXOffset, __get__labelXOffset, m_labelYOffset, __get__labelYOffset, m_labelLength, m_label, __get__label, m_useInternalScroll, __get__useInternalScroll, _parent, scrollTainer, mcBoundingBox, m_mcAuthorTextBG, getNextHighestDepth, createEmptyMovieClip, m_mcLabel, attachMovie, setColor, m_localizationId, m_initWidth, _alpha, m_enabled, __set__label, __set__labelColor, __set__labelXOffset, __set__labelYOffset, __set__textFormat_align, __set__textFormat_bold, __set__textFormat_dynamicLarge, __set__textFormat_isColumnTitle, __set__textFormat_isDynamic, __set__textFormat_multiline, __set__useInternalScroll;
    function TextContainer(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set textFormat_isColumnTitle(Value)
    {
        m_isTitle = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.textFormat_isColumnTitle());
        null;
    } // End of the function
    function get textFormat_isColumnTitle()
    {
        return (m_isTitle);
    } // End of the function
    function set textFormat_isDynamic(Value)
    {
        m_dynamicText = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.textFormat_isDynamic());
        null;
    } // End of the function
    function get textFormat_isDynamic()
    {
        return (m_dynamicText);
    } // End of the function
    function set textFormat_dynamicLarge(Value)
    {
        m_dynamicTextLarge = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.textFormat_dynamicLarge());
        null;
    } // End of the function
    function get textFormat_dynamicLarge()
    {
        return (m_dynamicTextLarge);
    } // End of the function
    function set textFormat_bold(Value)
    {
        m_bold = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.textFormat_bold());
        null;
    } // End of the function
    function get textFormat_bold()
    {
        return (m_bold);
    } // End of the function
    function set textFormat_multiline(Value)
    {
        m_multiline = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.textFormat_multiline());
        null;
    } // End of the function
    function get textFormat_multiline()
    {
        return (m_multiline);
    } // End of the function
    function set labelColor(Value)
    {
        m_labelColor = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelColor());
        null;
    } // End of the function
    function get labelColor()
    {
        return (m_labelColor);
    } // End of the function
    function set textFormat_align(Value)
    {
        m_align = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.textFormat_align());
        null;
    } // End of the function
    function get textFormat_align()
    {
        return (m_align);
    } // End of the function
    function set labelXOffset(Value)
    {
        m_labelXOffset = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelXOffset());
        null;
    } // End of the function
    function get labelXOffset()
    {
        return (m_labelXOffset);
    } // End of the function
    function set labelYOffset(Value)
    {
        m_labelYOffset = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.labelYOffset());
        null;
    } // End of the function
    function get labelYOffset()
    {
        return (m_labelYOffset);
    } // End of the function
    function set label(sValue)
    {
        var _loc2 = new String(sValue);
        m_labelLength = _loc2.length;
        m_label = sValue;
        //return (this.label());
        null;
    } // End of the function
    function get label()
    {
        return (m_label);
    } // End of the function
    function set useInternalScroll(bValue)
    {
        m_useInternalScroll = bValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.useInternalScroll());
        null;
    } // End of the function
    function get useInternalScroll()
    {
        return (m_useInternalScroll);
    } // End of the function
    function init()
    {
        super.init();
        scrollTainer = _parent._parent._parent;
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
    } // End of the function
    function setScrollSize()
    {
        if (scrollTainer.isScroller)
        {
            var _loc3 = m_textWidth;
            var _loc2 = m_textHeight + 20;
            if (m_useInternalScroll)
            {
                scrollTainer.setContentSize(_loc3, _loc2, 0);
                scrollTainer.scrollToTop();
            } // end if
        } // end if
    } // End of the function
    function draw()
    {
        if (this.m_inAuthorMode)
        {
            if (this.m_mcAuthorTextBG)
            {
                this.m_mcAuthorTextBG.removeMovieClip();
            } // end if
            this.createEmptyMovieClip("m_mcAuthorTextBG", this.getNextHighestDepth());
            with (this.m_mcAuthorTextBG)
            {
                lineStyle(0, 9940189, 0);
                beginFill(9940189, 40);
                moveTo(0, 0);
                lineTo(0, 100);
                lineTo(100, 100);
                lineTo(100, 0);
                endFill();
            } // End of with
        } // end if
    } // End of the function
    function setEvents()
    {
    } // End of the function
    function glow()
    {
    } // End of the function
    function createChildren()
    {
        if (m_mcLabel)
        {
            m_mcLabel.removeMovieClip();
        } // end if
        if (m_dynamicText)
        {
            if (m_dynamicTextLarge)
            {
                if (m_multiline)
                {
                    if (m_align == 0)
                    {
                        this.attachMovie("mcDynamicLargeMultilineLeft", "m_mcLabel", this.getNextHighestDepth());
                    }
                    else if (m_align == 1)
                    {
                        this.attachMovie("mcDynamicLargeMultilineCenter", "m_mcLabel", this.getNextHighestDepth());
                    }
                    else if (m_align == 2)
                    {
                        this.attachMovie("mcDynamicLargeMultilineRight", "m_mcLabel", this.getNextHighestDepth());
                    } // end else if
                }
                else if (m_align == 0)
                {
                    this.attachMovie("mcDynamicLargeLeft", "m_mcLabel", this.getNextHighestDepth());
                }
                else if (m_align == 1)
                {
                    this.attachMovie("mcDynamicLargeCenter", "m_mcLabel", this.getNextHighestDepth());
                }
                else if (m_align == 2)
                {
                    this.attachMovie("mcDynamicLargeRight", "m_mcLabel", this.getNextHighestDepth());
                } // end else if
            }
            else if (m_multiline)
            {
                if (m_align == 0)
                {
                    this.attachMovie("mcDynamicMultilineLeft", "m_mcLabel", this.getNextHighestDepth());
                }
                else if (m_align == 1)
                {
                    this.attachMovie("mcDynamicMultilineCenter", "m_mcLabel", this.getNextHighestDepth());
                }
                else if (m_align == 2)
                {
                    this.attachMovie("mcDynamicMultilineRight", "m_mcLabel", this.getNextHighestDepth());
                } // end else if
            }
            else if (m_align == 0)
            {
                this.attachMovie("mcDynamicLeft", "m_mcLabel", this.getNextHighestDepth());
            }
            else if (m_align == 1)
            {
                this.attachMovie("mcDynamicCenter", "m_mcLabel", this.getNextHighestDepth());
            }
            else if (m_align == 2)
            {
                this.attachMovie("mcDynamicRight", "m_mcLabel", this.getNextHighestDepth());
            } // end else if
        }
        else if (m_isTitle)
        {
            if (m_align == 0)
            {
                this.attachMovie("mcTitlesLeft", "m_mcLabel", this.getNextHighestDepth());
            }
            else if (m_align == 1)
            {
                this.attachMovie("mcTitlesCenter", "m_mcLabel", this.getNextHighestDepth());
            }
            else if (m_align == 2)
            {
                this.attachMovie("mcTitlesRight", "m_mcLabel", this.getNextHighestDepth());
            } // end else if
        }
        else if (m_multiline)
        {
            if (m_bold)
            {
                if (m_align == 0)
                {
                    this.attachMovie("mcMultiLineLeftBold", "m_mcLabel", this.getNextHighestDepth());
                }
                else if (m_align == 1)
                {
                    this.attachMovie("mcMultiLineCenterBold", "m_mcLabel", this.getNextHighestDepth());
                }
                else if (m_align == 2)
                {
                    this.attachMovie("mcMultiLineRightBold", "m_mcLabel", this.getNextHighestDepth());
                } // end else if
            }
            else if (m_align == 0)
            {
                this.attachMovie("mcMultiLineLeft", "m_mcLabel", this.getNextHighestDepth());
            }
            else if (m_align == 1)
            {
                this.attachMovie("mcMultiLineCenter", "m_mcLabel", this.getNextHighestDepth());
            }
            else if (m_align == 2)
            {
                this.attachMovie("mcMultiLineRight", "m_mcLabel", this.getNextHighestDepth());
            } // end else if
        }
        else if (m_bold)
        {
            if (m_align == 0)
            {
                this.attachMovie("mcSingleLineLeftBold", "m_mcLabel", this.getNextHighestDepth());
            }
            else if (m_align == 1)
            {
                this.attachMovie("mcSingleLineCenterBold", "m_mcLabel", this.getNextHighestDepth());
            }
            else if (m_align == 2)
            {
                this.attachMovie("mcSingleLineRightBold", "m_mcLabel", this.getNextHighestDepth());
            } // end else if
        }
        else if (m_align == 0)
        {
            this.attachMovie("mcSingleLineLeft", "m_mcLabel", this.getNextHighestDepth());
        }
        else if (m_align == 1)
        {
            this.attachMovie("mcSingleLineCenter", "m_mcLabel", this.getNextHighestDepth());
        }
        else if (m_align == 2)
        {
            this.attachMovie("mcSingleLineRight", "m_mcLabel", this.getNextHighestDepth());
        } // end else if
        if (m_dynamicText)
        {
            if (m_inAuthorMode)
            {
                this.setColor(m_mcAuthorTextBG, 15986309);
            } // end if
        }
        else
        {
            this.setLocID(m_localizationId);
        } // end else if
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_mcAuthorTextBG)
        {
            with (this.m_mcAuthorTextBG)
            {
                _x = 0;
                _y = 0;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
            } // End of with
        } // end if
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                _x = _parent.m_labelXOffset;
                _y = _parent.m_labelYOffset;
                if (labelTextField)
                {
                    with (labelTextField)
                    {
                        if (_parent._parent.m_localizationId.length > 0)
                        {
                            text = _parent._parent.m_localizationId;
                        }
                        else
                        {
                            text = _parent._parent.m_label;
                        } // end else if
                        maxChars = 4096;
                        _width = _parent._parent.m_initWidth;
                        _height = _parent._parent.m_initHeight;
                        textColor = _parent._parent.m_labelColor;
                        embedFonts = true;
                        _x = 0;
                        _y = 0;
                    } // End of with
                } // end if
            } // End of with
        } // end if
    } // End of the function
    function authorModeUpdate()
    {
        this.draw();
        this.createChildren();
        this.arrange();
    } // End of the function
    function setLocID(locId)
    {
        if (!m_dynamicText)
        {
            m_localizationId = locId;
            if (locId.length > 0)
            {
                mx.lang.Locale.addDelayedInstance(m_mcLabel.labelTextField, locId);
                if (m_inAuthorMode)
                {
                    this.setColor(m_mcAuthorTextBG, 14063326);
                } // end if
            }
            else if (m_inAuthorMode)
            {
                this.setColor(m_mcAuthorTextBG, 9940189);
            } // end if
        } // end else if
    } // End of the function
    function getLocID()
    {
        return (m_localizationId);
    } // End of the function
    function setValue(s, isLocalizationID)
    {
        if (isLocalizationID)
        {
            this.setLocID(s);
        } // end if
        this.m_label = s;
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                if (labelTextField)
                {
                    with (labelTextField)
                    {
                        text = _parent._parent.m_label;
                    } // End of with
                    if (m_multiline)
                    {
                        _parent.setComponentHeight(labelTextField.textHeight);
                    } // end if
                } // end if
            } // End of with
        } // end if
    } // End of the function
    function setComponentHeight(nHeight)
    {
        m_mcAuthorTextBG._height = nHeight;
        m_textHeight = nHeight;
        m_textWidth = m_initWidth;
        this.setScrollSize();
        if (m_mcLabel)
        {
            m_mcLabel.labelTextField._height = nHeight;
        } // end if
    } // End of the function
    function getValue()
    {
        return (m_label);
    } // End of the function
    function enable()
    {
        _alpha = 100;
        m_enabled = true;
    } // End of the function
    function disable()
    {
        _alpha = 20;
        m_enabled = false;
    } // End of the function
    function update()
    {
        super.update();
    } // End of the function
    var m_textHeight = 0;
    var m_textWidth = 0;
} // End of Class
