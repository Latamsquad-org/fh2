class dice.UIs.Commons.ImageContainer extends dice.UIs.Common
{
    var m_backgroundColor, m_inAuthorMode, __get__backgroundColor, m_backgroundAlpha, __get__backgroundAlpha, __get__fadeSpeed, m_imageUrl, __get__imageURL, m_XOffset, __get__imageXOffset, m_YOffset, __get__imageYOffset, mcBoundingBox, getNextHighestDepth, createEmptyMovieClip, m_mcAuthorBG, attachMovie, m_mcBackgroundPlate, setColor, m_mcLabel, m_mcLabel2, __alpha, _alpha, m_enabled, m_mcForImageUrl, m_mcBackImage, m_mcBackImageUrl, m_mcForImage, m_initWidth, m_initHeight, __set__backgroundAlpha, __set__backgroundColor, __set__fadeSpeed, __set__imageURL, __set__imageXOffset, __set__imageYOffset;
    function ImageContainer(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set backgroundColor(Value)
    {
        m_backgroundColor = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.backgroundColor());
        null;
    } // End of the function
    function get backgroundColor()
    {
        return (m_backgroundColor);
    } // End of the function
    function set backgroundAlpha(Value)
    {
        m_backgroundAlpha = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.backgroundAlpha());
        null;
    } // End of the function
    function get backgroundAlpha()
    {
        return (m_backgroundAlpha);
    } // End of the function
    function set fadeSpeed(Value)
    {
        m_fadeSpeed = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.fadeSpeed());
        null;
    } // End of the function
    function get fadeSpeed()
    {
        return (m_fadeSpeed);
    } // End of the function
    function set imageURL(Value)
    {
        m_imageUrl = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.imageURL());
        null;
    } // End of the function
    function get imageURL()
    {
        return (m_imageUrl);
    } // End of the function
    function set imageXOffset(Value)
    {
        m_XOffset = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.imageXOffset());
        null;
    } // End of the function
    function get imageXOffset()
    {
        return (m_XOffset);
    } // End of the function
    function set imageYOffset(Value)
    {
        m_YOffset = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.imageYOffset());
        null;
    } // End of the function
    function get imageYOffset()
    {
        return (m_YOffset);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
    } // End of the function
    function draw()
    {
        if (this.m_inAuthorMode)
        {
            this.createEmptyMovieClip("m_mcAuthorBG", this.getNextHighestDepth());
            with (this.m_mcAuthorBG)
            {
                lineStyle(0, _parent.m_baseColor, 0);
                beginFill(65280, 20);
                moveTo(0, 0);
                lineTo(0, 1);
                lineTo(1, 1);
                lineTo(1, 0);
                endFill();
            } // End of with
        } // end if
        this.createEmptyMovieClip("m_mcBackImage", this.getNextHighestDepth());
        this.createEmptyMovieClip("m_mcForImage", this.getNextHighestDepth());
    } // End of the function
    function setEvents()
    {
    } // End of the function
    function glow()
    {
    } // End of the function
    function createChildren()
    {
        if (m_inAuthorMode)
        {
            this.attachMovie("mcURL", "m_mcLabel", this.getNextHighestDepth());
            this.attachMovie("mcURL", "m_mcLabel2", this.getNextHighestDepth());
        } // end if
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_mcAuthorBG)
        {
            with (this.m_mcAuthorBG)
            {
                var xoff = _parent.m_XOffset;
                var yoff = _parent.m_YOffset;
                if (xoff < 0)
                {
                    xoff = 0;
                } // end if
                if (yoff < 0)
                {
                    yoff = 0;
                } // end if
                _x = xoff;
                _y = yoff;
                _width = _parent.m_initWidth - xoff;
                _height = _parent.m_initHeight - yoff;
            } // End of with
        } // end if
        if (this.m_mcBackgroundPlate)
        {
            with (this.m_mcBackgroundPlate)
            {
                _x = _parent.m_XOffset;
                _y = _parent.m_YOffset;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
                _alpha = _parent.m_backgroundAlpha;
            } // End of with
        } // end if
        this.setColor(this.m_mcBackgroundPlate, this.m_backgroundColor);
        this.resetImageContainers();
        this.loadImg(this.m_imageUrl);
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                with (URLField)
                {
                    _x = 0;
                    _y = 0;
                    _width = _parent._parent.m_initWidth;
                    text = _parent._parent.m_imageUrl;
                } // End of with
                _x = 0;
                _y = 0;
            } // End of with
        } // end if
        if (this.m_mcLabel2)
        {
            with (this.m_mcLabel2)
            {
                with (URLField)
                {
                    _x = _parent._parent.m_initWidth;
                    _y = _parent._parent.m_initHeight - 20;
                    _width = 100;
                    text = _parent._parent.m_initWidth + "x" + _parent._parent.m_initHeight;
                } // End of with
                _x = 0;
                _y = 0;
            } // End of with
        } // end if
        this._alpha = this.__alpha;
    } // End of the function
    function authorModeUpdate()
    {
        this.createChildren();
        this.arrange();
    } // End of the function
    function enable()
    {
        _alpha = 100;
        m_enabled = true;
    } // End of the function
    function disable()
    {
        _alpha = 20;
        m_enabled = false;
    } // End of the function
    function update()
    {
        super.update();
    } // End of the function
    function moveToBackground()
    {
        m_mcBackImage.loadMovie(m_mcForImageUrl);
        m_mcBackImageUrl = m_mcForImageUrl;
        m_mcBackImage._alpha = 100;
        m_mcForImage._alpha = 0;
        this.setImageSizes();
    } // End of the function
    function loadImg(imageUrl)
    {
        trace ("loadImg: " + imageUrl);
        if (imageUrl != m_mcForImageUrl)
        {
            m_mcForImage.loadMovie(imageUrl);
            m_mcForImageUrl = imageUrl;
            this.setImageSizes();
            if (m_fadeSpeed < 1)
            {
                m_mcForImage._alpha = 0;
                this.startFade();
            }
            else
            {
                m_mcForImage._alpha = 100;
            } // end if
        } // end else if
    } // End of the function
    function setImageSizes()
    {
        m_mcForImage._width = m_initWidth;
        m_mcForImage._height = m_initHeight;
        m_mcBackImage._width = m_initWidth;
        m_mcBackImage._height = m_initHeight;
    } // End of the function
    function resetImageContainers()
    {
        if (m_fadeSpeed < 1)
        {
            m_mcForImage._alpha = 0;
        } // end if
        m_mcForImage._x = m_XOffset;
        m_mcForImage._y = m_YOffset;
        m_mcBackImage._alpha = 0;
        m_mcBackImage._x = m_XOffset;
        m_mcBackImage._y = m_YOffset;
    } // End of the function
    function startFade()
    {
        if (!m_fadeUpInProgress)
        {
            m_fadeUpInProgress = true;
            m_fadeUpBackChanged = false;
            _root.updateManager1.registerCallback(this, "doFade", 1);
        } // end if
    } // End of the function
    function doFade()
    {
        var _loc2 = m_mcForImage._alpha + m_fadeSpeed * 100;
        var _loc3 = 100;
        m_mcForImage._alpha = _loc2;
        if (_loc2 >= 100)
        {
            this.moveToBackground();
            m_fadeUpInProgress = false;
            return (false);
        }
        else
        {
            return (true);
        } // end else if
        return (false);
    } // End of the function
    var m_backgroundNeedsFadeUp = false;
    var m_fadeUpInProgress = false;
    var m_fadeUpBackChanged = false;
    var m_currentImage = 1;
    var m_lastImageUrl = "";
    var m_currentLoadedImage = "";
    var hasBeenPreLoaded = false;
    var m_fadeInInProgress = false;
    var m_fadeOutInProgress = false;
    var m_fadeSpeed = 1;
} // End of Class
