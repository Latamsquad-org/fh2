class dice.UIs.Commons.StandardButton extends dice.UIs.Common
{
    var m_useLCD, m_inAuthorMode, __get__LCD, m_labelXOffset, __get__labelXOffset, m_labelYOffset, __get__labelYOffset, m_labelLength, m_label, __get__label, mcBoundingBox, m_soundId, m_useGlow, m_UIBGColor, m_buttonBGColor, m_UIGlowColor, m_buttonGlowColor, m_UITriggerColor, m_sliderBevelTopLeftColor, m_sliderBevelBottomRightColor, m_sliderBevelTopLeftColorInversed, m_sliderBevelBottomRightColorInversed, m_buttonBGAlpha, m_labelColor, m_labelColorInversed, m_UITriggerColorLight, m_labelGlowColor, _parent, m_edgeColor, m_UIBevelTopLeftColor, m_UIBevelBottomRightColor, m_UIBGAlpha, m_UIBevelAlpha, m_UITriggerColorGlow, m_initHeight, m_initWidth, m_UITriggerColorSelected, m_disableAlpha, getNextHighestDepth, createEmptyMovieClip, m_mcButtonSpecial, m_mcButtonBG, m_mcButtonBGGlow, m_mcButtonEdge, m_mcButtonEdgeInverted, m_enabled, m_mcLabel, mixColors, attachMovie, m_localizationId, __alpha, _alpha, m_enableStatusChanged, m_initAlpha, __set__LCD, __set__label, __set__labelXOffset, __set__labelYOffset;
    function StandardButton(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function set LCD(Value)
    {
        m_useLCD = Value;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.LCD());
        null;
    } // End of the function
    function get LCD()
    {
        return (m_useLCD);
    } // End of the function
    function set labelXOffset(Value)
    {
        m_labelXOffset = Value;
        //return (this.labelXOffset());
        null;
    } // End of the function
    function get labelXOffset()
    {
        return (m_labelXOffset);
    } // End of the function
    function set labelYOffset(Value)
    {
        m_labelYOffset = Value;
        //return (this.labelYOffset());
        null;
    } // End of the function
    function get labelYOffset()
    {
        return (m_labelYOffset);
    } // End of the function
    function set label(sValue)
    {
        var _loc2 = new String(sValue);
        m_labelLength = _loc2.length;
        m_label = sValue;
        //return (this.label());
        null;
    } // End of the function
    function get label()
    {
        return (m_label);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        m_soundId = "buttonPress";
        m_useGlow = false;
        m_labelBold = false;
        if (m_useLCD == 1)
        {
            m_buttonBGColor = m_UIBGColor;
            m_buttonGlowColor = m_UIGlowColor;
            m_sliderBevelTopLeftColor = m_UITriggerColor;
            m_sliderBevelBottomRightColor = m_UITriggerColor;
            m_sliderBevelTopLeftColorInversed = m_sliderBevelTopLeftColor;
            m_sliderBevelBottomRightColorInversed = m_sliderBevelBottomRightColor;
            m_buttonBGAlpha = 73;
            m_labelColor = m_UITriggerColor;
            m_labelColorInversed = m_labelColor;
            m_bevelAlpha = 10;
            m_labelGlowColor = m_UITriggerColorLight;
            m_glowMax = 10;
            if (!m_glowingInProgress)
            {
                _root.updateManager1.registerCallback(this, "glow", _parent.m_callbackFrequency);
            } // end if
            m_glowingInProgress = true;
            m_glowUp = false;
            m_glowInit = m_glowMax;
            m_useGlow = true;
            m_bevelRelease = false;
            m_soundId = "tabPress";
        }
        else if (m_useLCD == 2)
        {
            m_buttonBGColor = 0;
            m_buttonGlowColor = 3364351;
            m_sliderBevelTopLeftColor = m_edgeColor;
            m_sliderBevelBottomRightColor = m_edgeColor;
            m_sliderBevelTopLeftColorInversed = m_sliderBevelTopLeftColor;
            m_sliderBevelBottomRightColorInversed = m_sliderBevelBottomRightColor;
            m_buttonBGAlpha = 30;
            m_labelColor = 16777215;
            m_labelColorInversed = m_labelColor;
            m_labelGlowColor = m_labelColor;
            m_labelBold = false;
        }
        else if (m_useLCD == 3)
        {
            m_buttonBGColor = m_UIBGColor;
            m_buttonGlowColor = m_UIGlowColor;
            m_sliderBevelTopLeftColor = m_UIBevelTopLeftColor;
            m_sliderBevelBottomRightColor = m_UIBevelBottomRightColor;
            m_sliderBevelTopLeftColorInversed = m_sliderBevelTopLeftColor;
            m_sliderBevelBottomRightColorInversed = m_sliderBevelBottomRightColor;
            m_buttonBGAlpha = m_UIBGAlpha;
            m_labelColor = m_UITriggerColor;
            m_labelColorInversed = m_labelColor;
            m_bevelAlpha = m_UIBevelAlpha;
            m_labelBold = true;
            m_glowText = true;
            m_labelGlowColor = m_UITriggerColorGlow;
            m_glowMax = 10;
            if (!m_glowingInProgress)
            {
                _root.updateManager1.registerCallback(this, "glow", _parent.m_callbackFrequency);
            } // end if
            m_glowingInProgress = true;
            m_glowUp = false;
            m_glowInit = m_glowMax;
            m_useGlow = true;
            m_soundId = "menuButton";
        }
        else if (m_useLCD == 4)
        {
            m_buttonBGColor = m_UIBGColor;
            m_buttonGlowColor = m_UIGlowColor;
            m_sliderBevelTopLeftColor = m_UIBevelTopLeftColor;
            m_sliderBevelBottomRightColor = m_UIBevelBottomRightColor;
            m_sliderBevelTopLeftColorInversed = m_sliderBevelTopLeftColor;
            m_sliderBevelBottomRightColorInversed = m_sliderBevelBottomRightColor;
            m_buttonBGAlpha = m_UIBGAlpha;
            m_labelColor = m_UITriggerColor;
            m_labelColorInversed = m_labelColor;
            m_bevelAlpha = 100;
            m_labelBold = true;
            m_glowText = false;
            m_labelGlowColor = m_UITriggerColorGlow;
            m_glowMax = 10;
            m_glowInit = m_glowMax;
            m_useGlow = false;
            m_soundId = "menuButtonOpen";
        }
        else if (m_useLCD == 5)
        {
            m_buttonBGColor = m_UIBGColor;
            m_buttonGlowColor = m_UIGlowColor;
            m_sliderBevelTopLeftColor = m_UITriggerColorLight;
            m_sliderBevelBottomRightColor = m_UITriggerColorLight;
            m_sliderBevelTopLeftColorInversed = m_sliderBevelTopLeftColor;
            m_sliderBevelBottomRightColorInversed = m_sliderBevelBottomRightColor;
            m_buttonBGAlpha = 73;
            m_labelColor = m_UITriggerColor;
            m_labelColorInversed = m_labelColor;
            m_bevelAlpha = 80;
            m_labelGlowColor = m_UITriggerColorLight;
            m_glowMax = 10;
            if (!m_glowingInProgress)
            {
                _root.updateManager1.registerCallback(this, "glow", _parent.m_callbackFrequency);
            } // end if
            m_glowingInProgress = true;
            m_glowUp = false;
            m_glowInit = m_glowMax;
            m_useGlow = true;
        }
        else if (m_useLCD == 6)
        {
            m_buttonBGColor = m_UIBGColor;
            m_buttonGlowColor = m_UIGlowColor;
            m_sliderBevelTopLeftColor = m_UIBevelTopLeftColor;
            m_sliderBevelBottomRightColor = m_UIBevelBottomRightColor;
            m_sliderBevelTopLeftColorInversed = m_sliderBevelTopLeftColor;
            m_sliderBevelBottomRightColorInversed = m_sliderBevelBottomRightColor;
            m_buttonBGAlpha = m_UIBGAlpha;
            m_labelColor = m_UITriggerColor;
            m_labelColorInversed = m_labelColor;
            m_bevelAlpha = m_UIBevelAlpha;
            m_labelBold = true;
            m_glowText = true;
            m_labelGlowColor = m_UITriggerColorGlow;
            m_glowMax = 10;
            if (!m_glowingInProgress)
            {
                _root.updateManager1.registerCallback(this, "glow", _parent.m_callbackFrequency);
            } // end if
            m_glowingInProgress = true;
            m_glowUp = false;
            m_glowInit = m_glowMax;
            m_useGlow = true;
            m_soundId = "menuButton";
        }
        else if (m_useLCD == 7)
        {
            m_buttonBGColor = m_UIBGColor;
            m_buttonGlowColor = m_UIGlowColor;
            m_sliderBevelTopLeftColor = m_UIBevelTopLeftColor;
            m_sliderBevelBottomRightColor = m_UIBevelBottomRightColor;
            m_sliderBevelTopLeftColorInversed = m_sliderBevelTopLeftColor;
            m_sliderBevelBottomRightColorInversed = m_sliderBevelBottomRightColor;
            m_buttonBGAlpha = m_UIBGAlpha;
            m_labelColor = m_UITriggerColor;
            m_labelColorInversed = m_labelColor;
            m_bevelAlpha = 100;
            m_labelBold = true;
            m_glowText = false;
            m_labelGlowColor = m_UITriggerColorGlow;
            m_glowMax = 10;
            m_glowInit = m_glowMax;
            m_useGlow = false;
            m_soundId = "menuButtonOpen";
        }
        else if (m_useLCD == 8)
        {
            m_useSpecial = true;
            m_specialWidth = m_initHeight * 2;
            m_specialHeight = m_initHeight;
            m_specialY = 0;
            m_specialX = m_initWidth - m_initHeight * 2;
            m_specialUrl = "images/components/playNow.png";
            m_buttonBGColor = 16763648;
            m_buttonGlowColor = m_buttonBGColor;
            m_sliderBevelTopLeftColor = 16777215;
            m_sliderBevelBottomRightColor = 16777215;
            m_sliderBevelTopLeftColorInversed = m_sliderBevelTopLeftColor;
            m_sliderBevelBottomRightColorInversed = m_sliderBevelBottomRightColor;
            m_buttonBGAlpha = 100;
            m_bevelAlpha = 0;
            m_labelColor = 10513415;
            m_labelColorInversed = m_labelColor;
            m_labelBold = true;
            m_soundId = "playNow";
            m_labelGlowColor = m_UITriggerColorSelected;
            m_useGlow = false;
            m_bevelRelease = false;
        }
        else
        {
            m_buttonBGColor = m_UIBGColor;
            m_buttonGlowColor = m_UIGlowColor;
            m_sliderBevelTopLeftColor = m_UIBevelTopLeftColor;
            m_sliderBevelBottomRightColor = m_UIBevelBottomRightColor;
            m_sliderBevelTopLeftColorInversed = m_sliderBevelTopLeftColor;
            m_sliderBevelBottomRightColorInversed = m_sliderBevelBottomRightColor;
            m_buttonBGAlpha = m_UIBGAlpha;
            m_labelColor = m_UITriggerColor;
            m_labelColorInversed = m_labelColor;
            m_bevelAlpha = m_UIBevelAlpha;
            m_glowText = true;
            m_labelGlowColor = m_UITriggerColorGlow;
            m_glowMax = 10;
            if (!m_glowingInProgress)
            {
                _root.updateManager1.registerCallback(this, "glow", _parent.m_callbackFrequency);
            } // end if
            m_glowingInProgress = true;
            m_glowUp = false;
            m_glowInit = m_glowMax;
            m_useGlow = true;
        } // end else if
        m_disableAlpha = 100;
    } // End of the function
    function setPreGlowStart()
    {
        if (!m_glowingInProgress)
        {
            _root.updateManager1.registerCallback(this, "glow", _parent.m_callbackFrequency);
        } // end if
        m_glowingInProgress = true;
        m_glowUp = false;
        m_glowInit = m_glowMax;
    } // End of the function
    function draw()
    {
        if (this.m_useSpecial)
        {
            this.createEmptyMovieClip("m_mcButtonSpecial", this.getNextHighestDepth());
            with (this.m_mcButtonSpecial)
            {
                lineStyle(0, _parent.m_buttonBGColor, 0);
                beginFill(_parent.m_buttonBGColor, 100);
                moveTo(0, 0);
                lineTo(0, 100);
                lineTo(100, 100);
                lineTo(100, 0);
                endFill();
            } // End of with
        } // end if
        this.createEmptyMovieClip("m_mcButtonBG", this.getNextHighestDepth());
        with (this.m_mcButtonBG)
        {
            lineStyle(0, _parent.m_buttonBGColor, 0);
            beginFill(_parent.m_buttonBGColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcButtonBGGlow", this.getNextHighestDepth());
        with (this.m_mcButtonBGGlow)
        {
            lineStyle(0, _parent.m_buttonGlowColor, 0);
            beginFill(_parent.m_buttonGlowColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcButtonEdge", this.getNextHighestDepth());
        with (this.m_mcButtonEdge)
        {
            lineStyle(0, _parent.m_sliderBevelTopLeftColor, 100);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelBottomRightColor, 100);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcButtonEdgeInverted", this.getNextHighestDepth());
        with (this.m_mcButtonEdgeInverted)
        {
            lineStyle(0, _parent.m_sliderBevelBottomRightColorInversed, 100);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelTopLeftColorInversed, 100);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
    } // End of the function
    function setEvents()
    {
        function onRollOver()
        {
            if (m_enabled)
            {
                if (m_useGlow)
                {
                    if (!m_glowingInProgress)
                    {
                        _root.updateManager1.registerCallback(this, "glow", _parent.m_callbackFrequency);
                    } // end if
                    m_glowingInProgress = true;
                    m_glowUp = true;
                } // end if
            } // end if
        } // End of the function
        function onRollOut()
        {
            if (m_enabled)
            {
                if (m_useGlow)
                {
                    m_glowUp = false;
                } // end if
            } // end if
        } // End of the function
        function onPress()
        {
            if (m_enabled)
            {
                if (m_bevelRelease)
                {
                    m_mcButtonEdgeInverted._visible = true;
                } // end if
                m_mcButtonEdge._visible = false;
                m_mcLabel.labelTextField.textColor = m_labelColorInversed;
                if (m_soundId.length > 0)
                {
                    dice.bf2.Sound.playSound(m_soundId);
                } // end if
            } // end if
        } // End of the function
        function onRelease()
        {
            if (m_enabled)
            {
                m_mcButtonEdgeInverted._visible = false;
                m_mcButtonEdge._visible = true;
                m_mcLabel.labelTextField.textColor = m_labelColor;
            } // end if
        } // End of the function
        function onReleaseOutside()
        {
            if (m_enabled)
            {
                if (m_useGlow)
                {
                    m_glowUp = false;
                } // end if
                m_mcButtonEdgeInverted._visible = false;
                m_mcButtonEdge._visible = true;
                m_mcLabel.labelTextField.textColor = m_labelColor;
            } // end if
        } // End of the function
    } // End of the function
    function glow()
    {
        var _loc4 = m_mcButtonBGGlow._alpha;
        var _loc2 = _loc4;
        var _loc3 = _loc2 / m_glowMax;
        if (m_glowUp)
        {
            _loc2 = _loc2 + (m_glowMax - m_glowMin) / m_glowTime;
            _loc3 = _loc2 / m_glowMax;
            if (_loc2 <= m_glowMax)
            {
                m_mcButtonBGGlow._alpha = _loc2;
                if (m_glowText)
                {
                    m_mcLabel.labelTextField.textColor = this.mixColors(m_labelColor, m_labelGlowColor, _loc3);
                } // end if
                return (true);
            }
            else
            {
                m_glowUp = false;
                return (true);
            } // end else if
        }
        else
        {
            _loc2 = _loc2 - (m_glowMax - m_glowMin) / m_glowTime;
            _loc3 = _loc2 / m_glowMax;
            if (_loc2 >= m_glowMin)
            {
                m_mcButtonBGGlow._alpha = _loc2;
                if (m_glowText)
                {
                    m_mcLabel.labelTextField.textColor = this.mixColors(m_labelColor, m_labelGlowColor, _loc3);
                } // end if
            }
            else
            {
                m_glowingInProgress = false;
                m_mcLabel.labelTextField.textColor = m_labelColor;
                return (false);
            } // end else if
            return (true);
        } // end else if
        return (false);
    } // End of the function
    function createChildren()
    {
        if (m_labelBold)
        {
            this.attachMovie("mcStandardButtonLabelBold", "m_mcLabel", this.getNextHighestDepth());
        }
        else
        {
            this.attachMovie("mcStandardButtonLabel", "m_mcLabel", this.getNextHighestDepth());
        } // end else if
        if (m_localizationId.length > 0)
        {
            mx.lang.Locale.addDelayedInstance(m_mcLabel.labelTextField, m_localizationId);
        } // end if
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_mcButtonEdge)
        {
            with (this.m_mcButtonEdge)
            {
                _x = 0;
                _y = 0;
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
                _alpha = _parent.m_bevelAlpha;
            } // End of with
        } // end if
        if (this.m_mcButtonEdgeInverted)
        {
            with (this.m_mcButtonEdgeInverted)
            {
                _x = _parent.m_mcButtonEdge._x;
                _y = _parent.m_mcButtonEdge._y;
                _width = _parent.m_mcButtonEdge._width;
                _height = _parent.m_mcButtonEdge._height;
                _visible = false;
            } // End of with
        } // end if
        if (this.m_mcButtonBG)
        {
            with (this.m_mcButtonBG)
            {
                if (!_parent.m_useSpecial)
                {
                    _x = 0;
                    _y = 0;
                    _width = _parent.m_initWidth;
                    _height = _parent.m_initHeight;
                }
                else
                {
                    _x = 0;
                    _y = 0;
                    _width = _parent.m_initWidth - (_parent.m_specialWidth - 3);
                    _height = _parent.m_initHeight;
                } // end else if
                _alpha = _parent.m_buttonBGAlpha;
            } // End of with
        } // end if
        if (this.m_mcButtonSpecial)
        {
            with (this.m_mcButtonSpecial)
            {
                loadMovie(_parent.m_specialUrl);
                _width = _parent.m_specialWidth;
                _height = _parent.m_specialHeight;
                _y = _parent.m_specialY;
                _x = _parent.m_specialX;
            } // End of with
        } // end if
        if (this.m_mcButtonBGGlow)
        {
            with (this.m_mcButtonBGGlow)
            {
                _x = _parent.m_mcButtonBG._x;
                _y = _parent.m_mcButtonBG._y;
                _width = _parent.m_mcButtonBG._width;
                _height = _parent.m_mcButtonBG._height;
                _alpha = _parent.m_glowInit;
            } // End of with
        } // end if
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                _x = _parent.m_labelXOffset + _parent.m_mcButtonBG._x;
                _y = _parent.m_initHeight / 2 - labelTextField._height / 2 + 4.000000E-001;
                if (labelTextField)
                {
                    with (labelTextField)
                    {
                        if (_parent._parent.m_localizationId.length > 0)
                        {
                            text = _parent._parent.m_localizationId;
                        }
                        else
                        {
                            text = _parent._parent.m_label;
                        } // end else if
                        if (!_parent._parent.m_useSpecial)
                        {
                            _width = _parent._parent.m_initWidth;
                        }
                        else
                        {
                            _width = _parent._parent.m_initWidth - _parent._parent.m_specialWidth / 2;
                        } // end else if
                        textColor = _parent._parent.m_labelColor;
                        embedFonts = true;
                        _x = 0;
                        _y = 0;
                    } // End of with
                } // end if
            } // End of with
        } // end if
        this._alpha = this.__alpha;
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function enable()
    {
        _alpha = 100;
        m_enabled = true;
    } // End of the function
    function disable()
    {
        _alpha = 20;
        m_enabled = false;
    } // End of the function
    function update()
    {
        super.update();
        if (!m_enabled && m_enableStatusChanged)
        {
            _alpha = __alpha / 2;
            m_enableStatusChanged = false;
        }
        else if (m_enableStatusChanged)
        {
            _alpha = m_initAlpha;
            m_enableStatusChanged = false;
        } // end else if
    } // End of the function
    var m_bevelAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_labelFontCharPixelWidth = 8;
    var m_selectedColor = 16711680;
    var m_glowUp = false;
    var m_glowMax = 25;
    var m_glowMin = 0;
    var m_glowInit = dice.UIs.Commons.StandardButton.prototype.m_glowMin;
    var m_glowingInProgress = false;
    var m_glowTime = 4;
    var m_glowText = false;
    var m_labelBold = false;
    var m_bevelRelease = true;
    var m_useSpecial = false;
    var m_specialWidth = 50;
    var m_specialHeight = 50;
    var m_specialY = 0;
    var m_specialX = 0;
    var m_specialUrl = "";
} // End of Class
