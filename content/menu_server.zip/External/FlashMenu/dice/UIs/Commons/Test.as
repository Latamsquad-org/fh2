class dice.UIs.Commons.Test extends dice.UIs.Common
{
    var mcBoundingBox, _parent, setCallbackObject, setCallbackGetObject, getNextHighestDepth, createEmptyMovieClip, m_mcTest;
    function Test(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
        } // end if
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        this.setCallbackObject(_parent);
        this.setCallbackGetObject(this);
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcTest", this.getNextHighestDepth());
        with (this.m_mcTest)
        {
            lineStyle(0, 16711935, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, 16733525, 100);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
    } // End of the function
    function createChildren()
    {
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        if (this.m_mcTest)
        {
            with (this.m_mcTest)
            {
                _width = _parent.m_initWidth;
                _height = _parent.m_initHeight;
                _x = 0;
                _y = 0;
            } // End of with
        } // end if
    } // End of the function
    function authorModeUpdate()
    {
        this.arrange();
    } // End of the function
    function setEvents()
    {
    } // End of the function
} // End of Class
