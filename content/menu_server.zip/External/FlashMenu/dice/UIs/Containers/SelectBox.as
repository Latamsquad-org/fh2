class dice.UIs.Containers.SelectBox extends dice.UIs.Containers.ScrollTainer
{
    var _parent, runCallbackInit, __get__isLocalized, __get__textValue, m_labelX, __get__labelX, __get__groupId, m_selectContainerHeight, __get__selectContainerHeight, mcBoundingBox, m_scrollVerticalVisible, m_scrollHorizontalVisible, m_initHeight, m_contentInternalScrollOffsetY, m_contentInternalScrollOffsetX, m_contentOffsetY, m_contentOffsetX, m_scrollerType, m_callbackFrequency, m_bottomDepth, createEmptyMovieClip, m_mcClickOutside, getNextHighestDepth, m_mcSelectorBlackMask, m_mcSelectorBG, m_mcSelectorBGGlow, m_mcSelectorBevel, attachMovie, m_localizationId, m_mcSelectBoxTitle, m_mcSelectorArrow, m_mcLabel, m_mcContainerBG, m_mcContainerBGBevel, m_initWidth, m_scrollBarResizeWidth, m_scrollBarResizeHeight, m_scrollBarResizeX, m_scrollBarResizeY, setColor, m_mcContainer, m_mcScrollHorizontal, m_mcScrollVertical, m_containerBGEnabled, m_scrollBarsHidden, getActiveScrolledComponent, m_scolledComponent, m_contentInternalScrollCallBackObject, m_contentInternalScrollOffsetXCallback, m_contentInternalScrollOffsetYCallback, m_changed, m_updating, m_callbackInitEnabled, __set__groupId, __set__isLocalized, __set__labelX, __set__selectContainerHeight, __set__textValue;
    function SelectBox(cancelInit)
    {
        super(true);
        if (!_parent[identifier])
        {
            _parent[identifier] = new Array();
        } // end if
        _parent[identifier].push(this);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.setEvents();
            this.arrange();
            this.setValue("none", this.runCallbackInit());
        } // end if
    } // End of the function
    function set isLocalized(nValue)
    {
        m_isLocalized = nValue;
        //return (this.isLocalized());
        null;
    } // End of the function
    function get isLocalized()
    {
        return (m_isLocalized);
    } // End of the function
    function set textValue(nValue)
    {
        m_textValue = nValue;
        //return (this.textValue());
        null;
    } // End of the function
    function get textValue()
    {
        return (m_textValue);
    } // End of the function
    function set labelX(nValue)
    {
        m_labelX = nValue;
        //return (this.labelX());
        null;
    } // End of the function
    function get labelX()
    {
        return (m_labelX);
    } // End of the function
    function set groupId(nValue)
    {
        identifier = nValue;
        //return (this.groupId());
        null;
    } // End of the function
    function get groupId()
    {
        return (identifier);
    } // End of the function
    function set selectContainerHeight(Value)
    {
        m_selectContainerHeight = Value;
        //return (this.selectContainerHeight());
        null;
    } // End of the function
    function get selectContainerHeight()
    {
        return (m_selectContainerHeight);
    } // End of the function
    function getIndex()
    {
        return (m_selectedIndex);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        m_scrollVerticalVisible = false;
        m_scrollHorizontalVisible = false;
        m_contentInternalScrollOffsetY = m_initHeight + m_scrollBoxContentOffsetY;
        m_contentInternalScrollOffsetX = m_labelX;
        m_contentOffsetY = m_contentInternalScrollOffsetY;
        m_contentOffsetX = m_contentInternalScrollOffsetY;
        m_scrollerType = 1;
        _root.updateManager1.registerCallback(this, "updateManager", m_callbackFrequency);
    } // End of the function
    function draw()
    {
        super.draw();
        this.createEmptyMovieClip("m_mcClickOutside", this.m_bottomDepth);
        with (this.m_mcClickOutside)
        {
            lineStyle(0, _parent.m_baseColor, 0);
            beginFill(_parent.m_baseColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcSelectorBlackMask", this.getNextHighestDepth());
        with (this.m_mcSelectorBlackMask)
        {
            lineStyle(0, _parent.m_baseColor, 0);
            beginFill(_parent.m_baseColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcSelectorBG", this.getNextHighestDepth());
        with (this.m_mcSelectorBG)
        {
            lineStyle(0, _parent.m_baseColor, 0);
            beginFill(_parent.m_baseColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcSelectorBGGlow", this.getNextHighestDepth());
        with (this.m_mcSelectorBGGlow)
        {
            lineStyle(0, _parent.m_baseColor, 0);
            beginFill(_parent.m_baseColor, 100);
            moveTo(0, 0);
            lineTo(0, 100);
            lineTo(100, 100);
            lineTo(100, 0);
            endFill();
        } // End of with
        this.createEmptyMovieClip("m_mcSelectorBevel", this.getNextHighestDepth());
        with (this.m_mcSelectorBevel)
        {
            lineStyle(0, _parent.m_sliderBevelTopLeftColor, _parent.m_sliderBevelAlpha);
            moveTo(0, 100);
            lineTo(0, 0);
            lineTo(100, 0);
            lineStyle(0, _parent.m_sliderBevelBottomRightColor, _parent.m_sliderBevelAlpha);
            lineTo(100, 0);
            lineTo(100, 100);
            lineTo(0, 100);
        } // End of with
        this.createEmptyMovieClip("m_mcSelectorArrow", this.getNextHighestDepth());
    } // End of the function
    function createChildren()
    {
        super.createChildren();
        this.attachMovie("mcSelectBoxTitle", "m_mcSelectBoxTitle", this.getNextHighestDepth());
        if (this.m_isLocalized)
        {
            this.attachMovie("mcSelectBoxLocalized", "m_mcLabel", this.getNextHighestDepth());
        }
        else
        {
            this.attachMovie("mcSelectBox", "m_mcLabel", this.getNextHighestDepth());
        } // end else if
        if (this.m_localizationId.length > 0)
        {
            mx.lang.Locale.addDelayedInstance(this.m_mcSelectBoxTitle.labelSelectBox, this.m_localizationId);
        } // end if
        with (this.m_mcSelectorArrow)
        {
            attachMovie("arrowDown", "arrowDown", getNextHighestDepth());
            if (!_parent.m_inAuthorMode)
            {
                arrowDown.loadMovie("images/components/scrollArrow_down.png");
            } // end if
            attachMovie("arrowDownInverted", "arrowDownInverted", getNextHighestDepth());
            if (!_parent.m_inAuthorMode)
            {
                arrowDownInverted.loadMovie("images/components/scrollArrow_downInverted.png");
            } // end if
        } // End of with
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        super.arrange();
        if (this.m_mcClickOutside)
        {
            with (this.m_mcClickOutside)
            {
                _width = 2048;
                _height = 1536;
                _x = -1024;
                _y = -768;
                _alpha = 0;
                _visible = false;
            } // End of with
        } // end if
        if (!this.m_mcLabelTextSet && this.m_mcSelectBoxTitle)
        {
            this.m_mcLabelTextSet = true;
            with (this.m_mcSelectBoxTitle)
            {
                _x = 0;
                _y = _parent.m_initHeight / 2 - labelSelectBox._height / 2;
                with (labelSelectBox)
                {
                    textColor = _parent._parent.m_labelTitleColor;
                    _width = _parent._parent.m_labelX - 5;
                    if (_parent._parent.m_localizationId.length > 0)
                    {
                        text = _parent._parent.m_localizationId;
                    }
                    else
                    {
                        text = _parent._parent.m_textValue;
                    } // end if
                } // End of with
            } // End of with
        } // end else if
        if (this.m_mcLabel)
        {
            with (this.m_mcLabel)
            {
                _x = _parent.m_labelX + 5;
                _y = _parent.m_initHeight / 2 - selectBoxLabel._height / 2;
                with (selectBoxLabel)
                {
                    _width = _parent._parent.m_initWidth - (_parent._parent.m_initHeight + _parent._parent.m_labelX);
                    textWidth = _parent._parent.m_initWidth - _parent._parent.m_initHeight;
                    text = _parent._parent.m_labelStartText;
                    textColor = _parent._parent.m_labelColor;
                } // End of with
            } // End of with
        } // end if
        if (this.m_mcSelectorBG)
        {
            with (this.m_mcSelectorBG)
            {
                _x = _parent.m_labelX;
                _y = 0;
                _width = _parent.m_initWidth - _parent.m_labelX;
                _height = _parent.m_initHeight;
            } // End of with
        } // end if
        if (this.m_mcSelectorBGGlow)
        {
            with (this.m_mcSelectorBGGlow)
            {
                _x = _parent.m_mcSelectorBG._x;
                _y = _parent.m_mcSelectorBG._y;
                _width = _parent.m_mcSelectorBG._width;
                _height = _parent.m_mcSelectorBG._height;
                _alpha = _parent.m_UIBevelAlpha;
                _visible = 0;
            } // End of with
        } // end if
        if (this.m_mcSelectorBevel)
        {
            with (this.m_mcSelectorBevel)
            {
                _x = _parent.m_mcSelectorBG._x;
                _y = _parent.m_mcSelectorBG._y;
                _width = _parent.m_mcSelectorBG._width;
                _height = _parent.m_mcSelectorBG._height;
            } // End of with
        } // end if
        if (this.m_mcSelectorArrow)
        {
            with (this.m_mcSelectorArrow)
            {
                with (arrowDown)
                {
                    _x = _parent._parent.m_initWidth - _parent._parent.m_initHeight + (_parent._parent.m_initHeight / 2 - _parent._parent.m_UIArrowThickness / 2);
                    _y = _parent._parent.m_initHeight / 2 - _parent._parent.m_UIArrowThickness / 2;
                    _width = _parent._parent.m_UIArrowThickness;
                    _height = _parent._parent.m_UIArrowThickness;
                } // End of with
                with (arrowDownInverted)
                {
                    _x = _parent.arrowDown._x;
                    _y = _parent.arrowDown._y;
                    _width = _parent.arrowDown._width;
                    _height = _parent.arrowDown._height;
                    _visible = false;
                } // End of with
            } // End of with
        } // end if
        if (this.m_mcSelectorBlackMask)
        {
            with (this.m_mcSelectorBlackMask)
            {
                _width = _parent.m_initWidth - _parent.m_labelX;
                _height = _parent.m_scrollBoxContentOffsetY;
                _x = _parent.m_labelX;
                _y = _parent.m_initHeight;
                _alpha = 15;
                _visible = false;
            } // End of with
        } // end if
        if (this.m_mcContainerBG)
        {
            with (this.m_mcContainerBG)
            {
                _x = _parent.m_labelX;
                _y = _parent.m_initHeight + _parent.m_scrollBoxContentOffsetY;
                _width = _parent.m_initWidth - _parent.m_labelX;
                _height = _parent.m_selectContainerHeight;
                _visible = false;
                _alpha = _parent.m_containerBGAlpha;
            } // End of with
            this.m_mcContainerBG.onPress = function ()
            {
            };
            this.m_mcContainerBG.onRelease = function ()
            {
            };
            this.m_mcContainerBG.onReleaseOutside = function ()
            {
            };
            this.m_mcContainerBG.onRollOver = function ()
            {
            };
            this.m_mcContainerBG.onRollOut = function ()
            {
            };
        } // end if
        if (this.m_mcContainerBGBevel)
        {
            with (this.m_mcContainerBGBevel)
            {
                _x = _parent.m_mcContainerBG._x;
                _y = _parent.m_mcContainerBG._y;
                _width = _parent.m_mcContainerBG._width;
                _height = _parent.m_mcContainerBG._height;
                _visible = false;
            } // End of with
        } // end if
        this.m_scrollBarResizeWidth = this.m_initWidth;
        this.m_scrollBarResizeHeight = this.m_selectContainerHeight;
        this.m_scrollBarResizeX = 0;
        this.m_scrollBarResizeY = this.m_initHeight + this.m_scrollBoxContentOffsetY;
        this.selectorToggle(true);
        this.setColor(this.m_mcSelectorBG, this.m_selectBoxColor);
        this.setColor(this.m_mcSelectorBGGlow, this.m_columnLineColorSelected);
        this.setColor(this.m_mcContainerBG, this.m_containerBGColor);
        this.setColor(this.m_mcSelectorBlackMask, 0);
    } // End of the function
    function setEvents()
    {
        super.setEvents();
        m_mcClickOutside.onPress = function ()
        {
            if (_parent.m_enabled)
            {
                _parent.selectorToggle(true, true);
            } // end if
        };
        m_mcSelectorBG.onRelease = function ()
        {
            if (_parent.m_enabled)
            {
                _parent.selectorToggle();
            } // end if
        };
        m_mcSelectorArrow.onRelease = function ()
        {
            if (_parent.m_enabled)
            {
                _parent.selectorToggle();
            } // end if
        };
    } // End of the function
    function update()
    {
        var _loc2 = false;
        if (super.update())
        {
            _loc2 = true;
        } // end if
        return (_loc2);
    } // End of the function
    function selectorToggle(hideOverride, runSound)
    {
        if (m_mcContainer._visible || hideOverride)
        {
            if (runSound)
            {
                dice.bf2.Sound.playSound("selectBoxClose");
            } // end if
            m_mcScrollHorizontal._visible = false;
            m_mcScrollVertical._visible = false;
            m_mcContainer._visible = false;
            m_containerBGEnabled = false;
            m_mcContainerBG._visible = false;
            m_mcSelectorBlackMask._visible = false;
            m_scrollBarsHidden = true;
            m_mcSelectorArrow.arrowDown._visible = true;
            m_mcSelectorArrow.arrowDownInverted._visible = false;
            m_mcLabel.selectBoxLabel.textColor = m_labelColor;
            m_mcContainerBGBevel._visible = false;
            m_mcClickOutside._visible = false;
            m_mcSelectorBGGlow._visible = false;
        }
        else
        {
            var _loc3 = _parent[identifier];
            if (_loc3)
            {
                for (var _loc5 in _loc3)
                {
                    var _loc2 = _loc3[_loc5];
                    if (_loc2 != this)
                    {
                        _loc2.selectorToggle(true, runSound);
                    } // end if
                } // end of for...in
            } // end if
            m_mcClickOutside._visible = true;
            m_mcContainerBGBevel._visible = true;
            m_containerBGEnabled = true;
            m_mcContainerBG._visible = true;
            m_mcContainerBG._alpha = 100;
            m_mcSelectorBlackMask._visible = true;
            m_mcContainer._visible = true;
            m_scrollBarsHidden = false;
            m_mcSelectorBGGlow._visible = true;
            m_mcSelectorArrow.arrowDown._visible = false;
            m_mcSelectorArrow.arrowDownInverted._visible = true;
            m_scolledComponent = this.getActiveScrolledComponent();
            m_scolledComponent.deSelectRows();
            m_mcLabel.selectBoxLabel.textColor = m_labelColorInverted;
            if (runSound)
            {
                dice.bf2.Sound.playSound("selectBoxOpen");
            } // end if
            if (m_contentInternalScrollCallBackObject)
            {
                m_contentInternalScrollCallBackObject[m_contentInternalScrollOffsetXCallback](m_contentInternalScrollOffsetX);
                m_contentInternalScrollCallBackObject[m_contentInternalScrollOffsetYCallback](m_contentInternalScrollOffsetY);
            } // end if
            this.update();
        } // end else if
        m_changed = true;
    } // End of the function
    function setValue(setId, setText, index)
    {
        trace ("setValue setId:" + setId + " setText:" + setText + " index: " + index);
        if (this.m_mcLabel && setText.length > 0)
        {
            with (this.m_mcLabel)
            {
                with (selectBoxLabel)
                {
                    text = setText;
                } // End of with
            } // End of with
        } // end if
        this.m_selectedId = setId;
        if (!index == undefined)
        {
            this.m_selectedIndex = index;
        } // end if
        this.m_changed = true;
        this.selectorToggle(true);
    } // End of the function
    function getValue()
    {
        return (m_selectedId);
    } // End of the function
    function updateManager()
    {
        this.update();
        return (m_updating);
    } // End of the function
    function getInitWidth()
    {
        return (m_initWidth - m_labelX);
    } // End of the function
    function flush(noCallback)
    {
        super.flush(noCallback);
        m_callbackInitEnabled = true;
        this.setValue("none", this.runCallbackInit());
    } // End of the function
    var m_selectedIndex = 0;
    var m_labelStartText = "Click to select";
    var m_sliderBevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_sliderBevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_sliderBevelTopLeftColorInverted = dice.UI.prototype.m_UITriggerColorLight;
    var m_sliderBevelBottomRightColorInverted = dice.UI.prototype.m_UITriggerColorLight;
    var m_sliderBevelAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_scrollThickness = 17;
    var m_scrollBoxContentOffsetY = 4;
    var m_mcLabelTextSet = false;
    var m_textValue = "";
    var m_columnLineTextColor = dice.UI.prototype.m_UITriggerColor;
    var m_columnLineTextColorSelected = dice.UI.prototype.m_UITriggerColorLight;
    var m_columnLineTextColorDisabled = 16711680;
    var m_columnLineColor = 16777215;
    var m_columnLineColorSelected = dice.UI.prototype.m_UITriggerColor;
    var m_columnLineColorDisabled = 16764108;
    var m_columnLineColorAlpha = 0;
    var m_columnLineColorSelectedAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_columnLineColorDisabledAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_selectBoxColor = dice.UI.prototype.m_UIBGColor;
    var m_labelColor = dice.UI.prototype.m_UITriggerColor;
    var m_labelTitleColor = dice.UI.prototype.m_UITriggerColorSelected;
    var m_labelColorInverted = dice.UI.prototype.m_UITriggerColor;
    var m_selectBoxColorSelected = dice.UI.prototype.m_UIBGColor;
    var m_containerBGColor = dice.UI.prototype.m_UIBGColor;
    var m_containerBGAlpha = 100;
    var m_selectedId = "";
    var m_isLocalized = false;
    var identifier = "";
    var isScroller = 2;
} // End of Class
