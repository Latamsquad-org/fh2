class dice.UIs.Containers.ScrollTainer extends dice.UIs.Container
{
    var m_callbackFrequency, __get__scrollSliderThicknessMinimum, m_scrollBarsHidden, __get__scrollBarsHidden, m_scrollUsageAuto, __get__scrollUsageAuto, mcBoundingBox, m_initHeight, m_initWidth, setContainerSize, _parent, setCallbackObject, getNextHighestDepth, createEmptyMovieClip, m_mcScrollVertical, m_mcScrollHorizontal, m_containerHeight, m_contentHeight, m_scrollVerticalVisible, m_containerWidth, m_contentWidth, m_scrollHorizontalVisible, m_scrollVerticalOffset, m_scrollHorizontalOffset, _height, _ymouse, _width, _xmouse, m_contentInternalScroll, m_contentInternalScrollCallBackObject, m_activeComponent, m_dragYToggle, m_dragXToggle, m_dragMC, m_contentOffsetY, m_contentOffsetX, m_contentInternalScrollCallBack, m_contentInternalScrollOffsetY, m_oldContentInternalScrollOffsetY, m_contentInternalScrollOffsetYCallback, m_contentInternalScrollOffsetX, m_oldContentInternalScrollOffsetX, m_contentInternalScrollOffsetXCallback, setContentPlacement, m_updating, getContentMc, __set__scrollBarsHidden, __set__scrollSliderThicknessMinimum, __set__scrollUsageAuto;
    function ScrollTainer(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.setEvents();
            this.arrange();
            _root.updateManager1.registerCallback(this, "updateManager", m_callbackFrequency);
        } // end if
    } // End of the function
    function set scrollSliderThicknessMinimum(Value)
    {
        m_scrollSliderThicknessMinimum = Value;
        //return (this.scrollSliderThicknessMinimum());
        null;
    } // End of the function
    function get scrollSliderThicknessMinimum()
    {
        return (m_scrollSliderThicknessMinimum);
    } // End of the function
    function set scrollBarsHidden(Value)
    {
        m_scrollBarsHidden = Value;
        //return (this.scrollBarsHidden());
        null;
    } // End of the function
    function get scrollBarsHidden()
    {
        return (m_scrollBarsHidden);
    } // End of the function
    function set scrollUsageAuto(Value)
    {
        m_scrollUsageAuto = Value;
        //return (this.scrollUsageAuto());
        null;
    } // End of the function
    function get scrollUsageAuto()
    {
        return (m_scrollUsageAuto);
    } // End of the function
    function init()
    {
        super.init();
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        this.setContainerSize(m_initWidth, m_initHeight);
        this.setCallbackObject(_parent);
    } // End of the function
    function draw()
    {
        super.draw();
        this.createEmptyMovieClip("m_mcScrollVertical", this.getNextHighestDepth());
        with (this.m_mcScrollVertical)
        {
            createEmptyMovieClip("sliderBG", getNextHighestDepth());
            with (sliderBG)
            {
                lineStyle(0, _parent._parent.m_scrollSliderBGColor, 0);
                beginFill(_parent._parent.m_scrollSliderBGColor, _parent._parent.m_scrollSliderBGAlpha);
                moveTo(0, 0);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
                endFill();
            } // End of with
            createEmptyMovieClip("sliderBGBevel", getNextHighestDepth());
            with (sliderBGBevel)
            {
                lineStyle(0, _parent._parent.m_bevelTopLeftColor, _parent._parent.m_bevelAlpha);
                moveTo(0, 100);
                lineTo(0, 0);
                lineStyle(0, _parent._parent.m_bevelBottomRightColor, _parent._parent.m_bevelAlpha);
                lineTo(100, 0);
                lineTo(100, 100);
            } // End of with
            createEmptyMovieClip("arrowUpBG", getNextHighestDepth());
            with (arrowUpBG)
            {
                lineStyle(0, _parent._parent.m_scrollArrowBGColor, 0);
                beginFill(_parent._parent.m_scrollArrowBGColor, _parent._parent.m_scrollArrowBGAlpha);
                moveTo(0, 0);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
                endFill();
            } // End of with
            createEmptyMovieClip("arrowUpBGBevel", getNextHighestDepth());
            with (arrowUpBGBevel)
            {
                lineStyle(0, _parent._parent.m_sliderBevelTopLeftColor, _parent._parent.m_bevelAlpha);
                moveTo(0, 100);
                lineTo(0, 0);
                lineTo(100, 0);
                lineStyle(0, _parent._parent.m_sliderBevelBottomRightColor, _parent._parent.m_bevelAlpha);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
            } // End of with
            createEmptyMovieClip("arrowDownBG", getNextHighestDepth());
            with (arrowDownBG)
            {
                lineStyle(0, _parent._parent.m_scrollArrowBGColor, 0);
                beginFill(_parent._parent.m_scrollArrowBGColor, _parent._parent.m_scrollArrowBGAlpha);
                moveTo(0, 0);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
                endFill();
            } // End of with
            createEmptyMovieClip("arrowDownBGBevel", getNextHighestDepth());
            with (arrowDownBGBevel)
            {
                lineStyle(0, _parent._parent.m_sliderBevelTopLeftColor, _parent._parent.m_bevelAlpha);
                moveTo(0, 100);
                lineTo(0, 0);
                lineTo(100, 0);
                lineStyle(0, _parent._parent.m_sliderBevelBottomRightColor, _parent._parent.m_bevelAlpha);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
            } // End of with
            createEmptyMovieClip("slider", getNextHighestDepth());
            with (slider)
            {
                lineStyle(0, _parent._parent.m_scrollSliderColor, 0);
                beginFill(_parent._parent.m_scrollSliderColor, 100);
                moveTo(0, 0);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
                endFill();
            } // End of with
            createEmptyMovieClip("sliderBevel", getNextHighestDepth());
            with (sliderBevel)
            {
                lineStyle(0, _parent._parent.m_sliderBevelTopLeftColor, _parent._parent.m_sliderBevelAlpha);
                moveTo(0, 100);
                lineTo(0, 0);
                lineTo(100, 0);
                lineStyle(0, _parent._parent.m_sliderBevelBottomRightColor, _parent._parent.m_sliderBevelAlpha);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
            } // End of with
        } // End of with
        this.createEmptyMovieClip("m_mcScrollHorizontal", this.getNextHighestDepth());
        with (this.m_mcScrollHorizontal)
        {
            createEmptyMovieClip("sliderBG", getNextHighestDepth());
            with (sliderBG)
            {
                lineStyle(0, _parent._parent.m_scrollSliderBGColor, 0);
                beginFill(_parent._parent.m_scrollSliderBGColor, _parent._parent.m_scrollSliderBGAlpha);
                moveTo(0, 0);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
                endFill();
            } // End of with
            createEmptyMovieClip("sliderBGBevel", getNextHighestDepth());
            with (sliderBGBevel)
            {
                lineStyle(0, _parent._parent.m_bevelTopLeftColor, _parent._parent.m_bevelAlpha);
                moveTo(0, 0);
                lineTo(100, 0);
                lineStyle(0, _parent._parent.m_bevelBottomRightColor, _parent._parent.m_bevelAlpha);
                moveTo(100, 100);
                lineTo(0, 100);
            } // End of with
            createEmptyMovieClip("arrowLeftBG", getNextHighestDepth());
            with (arrowLeftBG)
            {
                lineStyle(0, _parent._parent.m_scrollArrowBGColor, 0);
                beginFill(_parent._parent.m_scrollArrowBGColor, _parent._parent.m_scrollArrowBGAlpha);
                moveTo(0, 0);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
                endFill();
            } // End of with
            createEmptyMovieClip("arrowLeftBGBevel", getNextHighestDepth());
            with (arrowLeftBGBevel)
            {
                lineStyle(0, _parent._parent.m_sliderBevelTopLeftColor, _parent._parent.m_bevelAlpha);
                moveTo(0, 100);
                lineTo(0, 0);
                lineTo(100, 0);
                lineStyle(0, _parent._parent.m_sliderBevelBottomRightColor, _parent._parent.m_bevelAlpha);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
            } // End of with
            createEmptyMovieClip("arrowRightBG", getNextHighestDepth());
            with (arrowRightBG)
            {
                lineStyle(0, _parent._parent.m_scrollArrowBGColor, 0);
                beginFill(_parent._parent.m_scrollArrowBGColor, _parent._parent.m_scrollArrowBGAlpha);
                moveTo(0, 0);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
                endFill();
            } // End of with
            createEmptyMovieClip("arrowRightBGBevel", getNextHighestDepth());
            with (arrowRightBGBevel)
            {
                lineStyle(0, _parent._parent.m_sliderBevelTopLeftColor, _parent._parent.m_bevelAlpha);
                moveTo(0, 100);
                lineTo(0, 0);
                lineTo(100, 0);
                lineStyle(0, _parent._parent.m_sliderBevelBottomRightColor, _parent._parent.m_bevelAlpha);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
            } // End of with
            createEmptyMovieClip("slider", getNextHighestDepth());
            with (slider)
            {
                lineStyle(0, _parent._parent.m_scrollSliderColor, 0);
                beginFill(_parent._parent.m_scrollSliderColor, 100);
                moveTo(0, 0);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
                endFill();
            } // End of with
            createEmptyMovieClip("sliderBevel", getNextHighestDepth());
            with (sliderBevel)
            {
                lineStyle(0, _parent._parent.m_sliderBevelTopLeftColor, 100);
                moveTo(0, 100);
                lineTo(0, 0);
                lineTo(100, 0);
                lineStyle(0, _parent._parent.m_sliderBevelBottomRightColor, 100);
                lineTo(100, 0);
                lineTo(100, 100);
                lineTo(0, 100);
            } // End of with
        } // End of with
    } // End of the function
    function createChildren()
    {
        with (this.m_mcScrollVertical)
        {
            attachMovie("arrowUp", "arrowUp", getNextHighestDepth());
            attachMovie("arrowDown", "arrowDown", getNextHighestDepth());
            if (!_parent.m_inAuthorMode)
            {
                arrowUp.loadMovie("images/components/scrollArrow_up.png");
                arrowDown.loadMovie("images/components/scrollArrow_down.png");
            } // end if
        } // End of with
        with (this.m_mcScrollHorizontal)
        {
            attachMovie("arrowLeft", "arrowLeft", getNextHighestDepth());
            attachMovie("arrowRight", "arrowRight", getNextHighestDepth());
            if (!_parent.m_inAuthorMode)
            {
                arrowLeft.loadMovie("images/components/scrollArrow_left.png");
                arrowRight.loadMovie("images/components/scrollArrow_right.png");
            } // end if
        } // End of with
    } // End of the function
    function arrange(noFullWidthDraw)
    {
        super.arrange();
        if (this.m_mcScrollVertical)
        {
            with (this.m_mcScrollVertical)
            {
                _x = _parent.m_initWidth - _parent.m_scrollThickness;
                _y = 0;
                _xscale = 100;
                _yscale = 100;
                with (sliderBG)
                {
                    _x = 0;
                    _y = _parent._parent.m_scrollThickness;
                    _width = _parent._parent.m_scrollThickness;
                } // End of with
                with (sliderBGBevel)
                {
                    _x = _parent.sliderBG._x;
                    _y = _parent.sliderBG._y;
                    _width = _parent.sliderBG._width;
                } // End of with
                with (arrowUpBG)
                {
                    _x = 0;
                    _y = 0;
                    _width = _parent._parent.m_scrollThickness;
                    _height = _parent._parent.m_scrollThickness;
                } // End of with
                with (arrowUpBGBevel)
                {
                    _x = _parent.arrowUpBG._x;
                    _y = _parent.arrowUpBG._y;
                    _width = _parent.arrowUpBG._width;
                    _height = _parent.arrowUpBG._height;
                } // End of with
                with (arrowDownBG)
                {
                    _x = 0;
                    _width = _parent._parent.m_scrollThickness;
                    _height = _parent._parent.m_scrollThickness;
                } // End of with
                with (arrowDownBGBevel)
                {
                    _x = _parent.arrowDownBG._x;
                    _width = _parent.arrowDownBG._width;
                    _height = _parent.arrowDownBG._height;
                } // End of with
                with (slider)
                {
                    _x = _parent.sliderBG._x + _parent._parent.m_scrollSliderMargin;
                    _y = _parent.sliderBG._y + _parent._parent.m_scrollSliderMargin;
                    _width = _parent._parent.m_scrollThickness - _parent._parent.m_scrollSliderMargin * 2;
                    _height = _parent._parent.m_scrollThickness - _parent._parent.m_scrollSliderMargin * 2;
                } // End of with
                with (sliderBevel)
                {
                    _x = _parent.slider._x;
                    _y = _parent.slider._y;
                    _width = _parent.slider._width;
                    _height = _parent.slider._height;
                } // End of with
                with (arrowUp)
                {
                    _x = _parent._parent.m_edgeThickness * 1.500000E+000;
                    _y = _parent._parent.m_edgeThickness * 1.500000E+000;
                    _width = _parent._parent.m_scrollThickness - _parent._parent.m_edgeThickness * 3;
                    _height = _parent._parent.m_scrollThickness - _parent._parent.m_edgeThickness * 3;
                } // End of with
                with (arrowDown)
                {
                    _x = _parent._parent.m_edgeThickness * 1.500000E+000;
                    _width = _parent._parent.m_scrollThickness - _parent._parent.m_edgeThickness * 3;
                    _height = _parent._parent.m_scrollThickness - _parent._parent.m_edgeThickness * 3;
                } // End of with
            } // End of with
        } // end if
        if (this.m_mcScrollHorizontal)
        {
            with (this.m_mcScrollHorizontal)
            {
                _x = 0;
                _y = _parent.m_initHeight - _parent.m_scrollThickness;
                _xscale = 100;
                _yscale = 100;
                with (sliderBG)
                {
                    _x = _parent._parent.m_scrollThickness;
                    _y = 0;
                    _height = _parent._parent.m_scrollThickness;
                } // End of with
                with (sliderBGBevel)
                {
                    _x = _parent.sliderBG._x;
                    _y = _parent.sliderBG._y;
                    _height = _parent.sliderBG._height;
                } // End of with
                with (arrowLeftBG)
                {
                    _x = 0;
                    _y = 0;
                    _width = _parent._parent.m_scrollThickness;
                    _height = _parent._parent.m_scrollThickness;
                } // End of with
                with (arrowLeftBGBevel)
                {
                    _x = _parent.arrowLeftBG._x;
                    _y = _parent.arrowLeftBG._y;
                    _width = _parent.arrowLeftBG._width;
                    _height = _parent.arrowLeftBG._height;
                } // End of with
                with (arrowRightBG)
                {
                    _y = 0;
                    _width = _parent._parent.m_scrollThickness;
                    _height = _parent._parent.m_scrollThickness;
                } // End of with
                with (arrowRightBGBevel)
                {
                    _y = _parent.arrowRightBG._y;
                    _width = _parent.arrowRightBG._width;
                    _height = _parent.arrowRightBG._height;
                } // End of with
                with (slider)
                {
                    _x = _parent.sliderBG._x + _parent._parent.m_scrollSliderMargin;
                    _y = _parent.sliderBG._y + _parent._parent.m_scrollSliderMargin;
                    _width = _parent._parent.m_scrollThickness - _parent._parent.m_scrollSliderMargin * 2;
                    _height = _parent._parent.m_scrollThickness - _parent._parent.m_scrollSliderMargin * 2;
                } // End of with
                with (sliderBevel)
                {
                    _x = _parent.slider._x;
                    _y = _parent.slider._y;
                    _width = _parent.slider._width;
                    _height = _parent.slider._height;
                } // End of with
                with (arrowLeft)
                {
                    _x = _parent._parent.m_edgeThickness * 1.500000E+000 - 1;
                    _y = _parent._parent.m_edgeThickness * 1.500000E+000;
                    _width = _parent._parent.m_scrollThickness - _parent._parent.m_edgeThickness * 3;
                    _height = _parent._parent.m_scrollThickness - _parent._parent.m_edgeThickness * 3;
                } // End of with
                with (arrowRight)
                {
                    _y = _parent._parent.m_edgeThickness * 1.500000E+000;
                    _width = _parent._parent.m_scrollThickness - _parent._parent.m_edgeThickness * 3;
                    _height = _parent._parent.m_scrollThickness - _parent._parent.m_edgeThickness * 3;
                } // End of with
            } // End of with
        } // end if
        this.scrollBarVisiblity();
        this.scrollBarResize();
    } // End of the function
    function scrollBarVisiblity(hideScrollbars)
    {
        if (m_scrollUsageAuto)
        {
            if (m_containerHeight + 2.000000E-001 < m_contentHeight)
            {
                m_scrollVerticalVisible = true;
            }
            else
            {
                m_scrollVerticalVisible = false;
            } // end else if
            if (m_containerWidth + 2.000000E-001 < m_contentWidth)
            {
                m_scrollHorizontalVisible = true;
            }
            else
            {
                m_scrollHorizontalVisible = false;
            } // end else if
        }
        else
        {
            m_scrollVerticalVisible = true;
            m_scrollHorizontalVisible = true;
        } // end else if
        if (hideScrollbars)
        {
            m_scrollVerticalVisible = false;
            m_scrollHorizontalVisible = false;
        } // end if
        if (m_scrollHorizontalVisible)
        {
            m_scrollVerticalOffset = m_scrollThickness;
        }
        else
        {
            m_scrollVerticalOffset = 0;
        } // end else if
        if (m_scrollVerticalVisible)
        {
            m_scrollHorizontalOffset = m_scrollThickness;
        }
        else
        {
            m_scrollHorizontalOffset = 0;
        } // end else if
    } // End of the function
    function scrollBarResize(width, height, x, y)
    {
        var width;
        var height;
        var x = 0;
        var y = 0;
        if (!this.m_scrollBarResizeWidth)
        {
            width = this.m_initWidth;
        }
        else
        {
            width = this.m_scrollBarResizeWidth;
        } // end else if
        if (!this.m_scrollBarResizeHeight)
        {
            height = this.m_initHeight;
        }
        else
        {
            height = this.m_scrollBarResizeHeight;
        } // end else if
        if (!this.m_scrollBarResizeX)
        {
            x = 0;
        }
        else
        {
            x = this.m_scrollBarResizeX;
        } // end else if
        if (!this.m_scrollBarResizeY)
        {
            y = 0;
        }
        else
        {
            y = this.m_scrollBarResizeY;
        } // end else if
        var tempHeight;
        var tempWidth;
        if (this.m_scrollVerticalVisible)
        {
            tempWidth = width - this.m_scrollThickness;
        }
        else
        {
            tempWidth = width;
        } // end else if
        if (this.m_scrollHorizontalVisible)
        {
            tempHeight = height - this.m_scrollThickness;
        }
        else
        {
            tempHeight = height;
        } // end else if
        this.setContainerSize(tempWidth, tempHeight, x, y);
        if (this.m_mcScrollVertical)
        {
            with (this.m_mcScrollVertical)
            {
                if (_parent.m_scrollVerticalVisible)
                {
                    _visible = true;
                }
                else
                {
                    _visible = false;
                } // end if
            } // End of with
        } // end else if
        if (this.m_mcScrollHorizontal)
        {
            with (this.m_mcScrollHorizontal)
            {
                if (_parent.m_scrollHorizontalVisible)
                {
                    _visible = true;
                }
                else
                {
                    _visible = false;
                } // end if
            } // End of with
        } // end else if
        if (this.m_mcScrollHorizontal)
        {
            with (this.m_mcScrollHorizontal)
            {
                _x = 0 + x;
                _y = height - _parent.m_scrollThickness + y;
                _xscale = 100;
                _yscale = 100;
                with (sliderBG)
                {
                    _width = width - _parent._parent.m_scrollThickness * 2 - _parent._parent.m_scrollHorizontalOffset;
                } // End of with
                with (sliderBGBevel)
                {
                    _width = _parent.sliderBG._width;
                } // End of with
                with (arrowRightBG)
                {
                    _x = width - _parent._parent.m_scrollThickness - _parent._parent.m_scrollHorizontalOffset;
                } // End of with
                with (arrowRightBGBevel)
                {
                    _x = _parent.arrowRightBG._x;
                } // End of with
                with (arrowRight)
                {
                    _x = width - _parent._parent.m_scrollThickness + _parent._parent.m_edgeThickness * 1.500000E+000 + 1 - _parent._parent.m_scrollHorizontalOffset;
                } // End of with
            } // End of with
        } // end if
        if (this.m_mcScrollVertical)
        {
            with (this.m_mcScrollVertical)
            {
                _x = width - _parent.m_scrollThickness + x;
                _y = 0 + y;
                _xscale = 100;
                _yscale = 100;
                with (sliderBG)
                {
                    _height = height - _parent._parent.m_scrollThickness * 2 - _parent._parent.m_scrollVerticalOffset;
                } // End of with
                with (sliderBGBevel)
                {
                    _height = _parent.sliderBG._height;
                } // End of with
                with (arrowDownBG)
                {
                    _y = height - _parent._parent.m_scrollThickness - _parent._parent.m_scrollVerticalOffset;
                } // End of with
                with (arrowDownBGBevel)
                {
                    _y = _parent.arrowDownBG._y;
                } // End of with
                with (arrowDown)
                {
                    _y = height - _parent._parent.m_scrollThickness + _parent._parent.m_edgeThickness * 1.500000E+000 + 1 - _parent._parent.m_scrollVerticalOffset;
                } // End of with
            } // End of with
        } // end if
    } // End of the function
    function setBoundaries(mcScrollParent, isVertical)
    {
        if (isVertical)
        {
            m_dragTop = mcScrollParent.sliderBG._y + m_scrollSliderMargin;
            m_dragBottom = mcScrollParent.sliderBG._y + mcScrollParent.sliderBG._height - m_scrollSliderMargin;
            m_dragLeft = mcScrollParent.slider._x;
            m_dragRight = mcScrollParent.slider._x;
        }
        else
        {
            m_dragTop = mcScrollParent.slider._y;
            m_dragBottom = mcScrollParent.slider._y;
            m_dragLeft = mcScrollParent.sliderBG._x + m_scrollSliderMargin;
            m_dragRight = mcScrollParent.sliderBG._x + mcScrollParent.sliderBG._width - m_scrollSliderMargin;
        } // end else if
    } // End of the function
    function setEvents()
    {
        super.setEvents();
        m_mcScrollVertical.slider.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollSlidePress");
            _parent._parent.m_sliding = true;
            _parent._parent.m_slidingVertical = true;
            _parent._parent.m_dragMC = this;
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollVertical, true);
            _parent._parent.m_dragClickYOffset = _height * (_ymouse / 100);
            _parent._parent.m_dragClickXOffset = _width * (_xmouse / 100);
            _root.updateManager1.registerCallback(_parent._parent, "slide", _parent._parent.m_callbackFrequency);
            this.update();
        };
        m_mcScrollVertical.slider.onRelease = function ()
        {
            _parent._parent.m_sliding = false;
        };
        m_mcScrollVertical.slider.onReleaseOutside = function ()
        {
            _parent._parent.m_sliding = false;
        };
        m_mcScrollHorizontal.slider.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollSlidePress");
            _parent._parent.m_sliding = true;
            _parent._parent.m_slidingVertical = false;
            _parent._parent.m_dragMC = this;
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollHorizontal, false);
            _parent._parent.m_dragClickYOffset = _height * (_ymouse / 100);
            _parent._parent.m_dragClickXOffset = _width * (_xmouse / 100);
            _root.updateManager1.registerCallback(_parent._parent, "slide", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollHorizontal.slider.onRelease = function ()
        {
            _parent._parent.m_sliding = false;
        };
        m_mcScrollHorizontal.slider.onReleaseOutside = function ()
        {
            _parent._parent.m_sliding = false;
        };
        m_mcScrollVertical.sliderBG.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollSkipPress");
            _parent._parent.m_scrollSkipVerticalToggle = true;
            _root.updateManager1.registerCallback(_parent._parent, "skip", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollVertical.sliderBG.onRelease = function ()
        {
            _parent._parent.m_scrollSkipVerticalToggle = false;
        };
        m_mcScrollVertical.sliderBG.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollSkipVerticalToggle = false;
        };
        m_mcScrollHorizontal.sliderBG.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollSkipPress");
            _parent._parent.m_scrollSkipHorizontalToggle = true;
            _root.updateManager1.registerCallback(_parent._parent, "skip", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollHorizontal.sliderBG.onRelease = function ()
        {
            _parent._parent.m_scrollSkipHorizontalToggle = false;
        };
        m_mcScrollHorizontal.sliderBG.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollSkipHorizontalToggle = false;
        };
        m_mcScrollVertical.arrowUp.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollArrowPress");
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollVertical, true);
            _parent._parent.m_scrollUp = true;
            _root.updateManager1.registerCallback(_parent._parent, "scrollUp", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollVertical.arrowUpBG.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollArrowPress");
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollVertical, true);
            _parent._parent.m_scrollUp = true;
            _root.updateManager1.registerCallback(_parent._parent, "scrollUp", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollVertical.arrowUp.onRelease = function ()
        {
            _parent._parent.m_scrollUp = false;
        };
        m_mcScrollVertical.arrowUpBG.onRelease = function ()
        {
            _parent._parent.m_scrollUp = false;
        };
        m_mcScrollVertical.arrowUp.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollUp = false;
            _parent._parent.m_updating = false;
        };
        m_mcScrollVertical.arrowUpBG.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollUp = false;
        };
        m_mcScrollVertical.arrowDown.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollArrowPress");
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollVertical, true);
            _parent._parent.m_scrollDown = true;
            _parent._parent.m_updating = false;
            _root.updateManager1.registerCallback(_parent._parent, "scrollDown", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollVertical.arrowDownBG.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollArrowPress");
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollVertical, true);
            _parent._parent.m_scrollDown = true;
            _root.updateManager1.registerCallback(_parent._parent, "scrollDown", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollVertical.arrowDown.onRelease = function ()
        {
            _parent._parent.m_scrollDown = false;
        };
        m_mcScrollVertical.arrowDownBG.onRelease = function ()
        {
            _parent._parent.m_scrollDown = false;
        };
        m_mcScrollVertical.arrowDown.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollDown = false;
        };
        m_mcScrollVertical.arrowDownBG.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollDown = false;
        };
        m_mcScrollHorizontal.arrowLeft.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollArrowPress");
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollHorizontal, false);
            _parent._parent.m_scrollLeft = true;
            _root.updateManager1.registerCallback(_parent._parent, "scrollLeft", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollHorizontal.arrowLeftBG.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollArrowPress");
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollHorizontal, false);
            _parent._parent.m_scrollLeft = true;
            _root.updateManager1.registerCallback(_parent._parent, "scrollLeft", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollHorizontal.arrowLeft.onRelease = function ()
        {
            _parent._parent.m_scrollLeft = false;
        };
        m_mcScrollHorizontal.arrowLeftBG.onRelease = function ()
        {
            _parent._parent.m_scrollLeft = false;
        };
        m_mcScrollHorizontal.arrowLeft.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollLeft = false;
        };
        m_mcScrollHorizontal.arrowLeftBG.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollLeft = false;
        };
        m_mcScrollHorizontal.arrowRight.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollArrowPress");
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollHorizontal, false);
            _parent._parent.m_scrollRight = true;
            _root.updateManager1.registerCallback(_parent._parent, "scrollRight", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollHorizontal.arrowRightBG.onPress = function ()
        {
            dice.bf2.Sound.playSound("scrollArrowPress");
            _parent._parent.setBoundaries(_parent._parent.m_mcScrollHorizontal, false);
            _parent._parent.m_scrollRight = true;
            _root.updateManager1.registerCallback(_parent._parent, "scrollRight", _parent._parent.m_callbackFrequency);
        };
        m_mcScrollHorizontal.arrowRight.onRelease = function ()
        {
            _parent._parent.m_scrollRight = false;
        };
        m_mcScrollHorizontal.arrowRightBG.onRelease = function ()
        {
            _parent._parent.m_scrollRight = false;
        };
        m_mcScrollHorizontal.arrowRight.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollRight = false;
        };
        m_mcScrollHorizontal.arrowRightBG.onReleaseOutside = function ()
        {
            _parent._parent.m_scrollRight = false;
        };
    } // End of the function
    function update()
    {
        super.update();
        this.scrollBarVisiblity(m_scrollBarsHidden);
        this.scrollBarResize();
        var _loc3 = m_mcScrollVertical.sliderBG._height;
        var _loc6 = m_containerHeight;
        var _loc4 = m_mcScrollHorizontal.sliderBG._width;
        var _loc8 = m_containerWidth;
        if (m_contentHeight > _loc6)
        {
            var _loc7 = _loc3 * (_loc6 / m_contentHeight);
            if (_loc7 < m_scrollThickness)
            {
                m_mcScrollVertical.slider._height = m_scrollThickness - m_scrollSliderMargin * 2;
            }
            else
            {
                m_mcScrollVertical.slider._height = _loc7 - m_scrollSliderMargin * 2;
            } // end else if
        }
        else
        {
            m_mcScrollVertical.slider._height = _loc3 - m_scrollSliderMargin * 2;
        } // end else if
        m_mcScrollVertical.sliderBevel._height = m_mcScrollVertical.slider._height;
        if (m_contentWidth > _loc8)
        {
            var _loc5 = _loc4 * (_loc8 / m_contentWidth);
            if (_loc5 < m_scrollThickness)
            {
                m_mcScrollHorizontal.slider._width = m_scrollThickness - m_scrollSliderMargin * 2;
            }
            else
            {
                m_mcScrollHorizontal.slider._width = _loc5 - m_scrollSliderMargin * 2;
            } // end else if
        }
        else
        {
            m_mcScrollHorizontal.slider._width = _loc4 - m_scrollSliderMargin * 2;
        } // end else if
        m_mcScrollHorizontal.sliderBevel._width = m_mcScrollHorizontal.slider._width;
    } // End of the function
    function scrollUp()
    {
        if (m_scrollUp)
        {
            if (m_contentInternalScroll)
            {
                m_contentInternalScrollCallBackObject.scrollUpOneLine();
                return (true);
            } // end if
        } // end if
        return (false);
    } // End of the function
    function syncSliderToContent()
    {
        var _loc2 = m_activeComponent;
        var _loc9 = _loc2.m_listStartIndex * _loc2.m_lineHeight;
        var _loc8 = _loc2.getTotalHeight();
        var _loc4 = _loc9 / _loc8;
        trace ("contentPercent: " + _loc4);
        var _loc7 = m_mcScrollVertical.slider._height;
        trace ("sliderHeight: " + _loc7);
        var _loc6 = m_mcScrollVertical.sliderBG._height - m_scrollSliderMargin * 3;
        trace ("sliderContainerHeight: " + _loc6);
        var _loc5 = _loc6 * _loc4;
        trace ("sliderPercent: " + _loc5);
        var _loc3 = _loc5 + (m_scrollThickness + m_scrollSliderMargin);
        trace ("sliderPlacement: " + _loc3);
        m_mcScrollVertical.slider._y = _loc3;
        m_mcScrollVertical.sliderBevel._y = _loc3;
    } // End of the function
    function scrollToTop()
    {
        m_mcScrollVertical.slider._y = m_mcScrollVertical.sliderBG._y + m_scrollSliderMargin;
        m_mcScrollVertical.sliderBevel._y = m_mcScrollVertical.slider._y;
        this.placeContent();
    } // End of the function
    function scrollDown()
    {
        if (m_scrollDown)
        {
            if (m_contentInternalScroll)
            {
                m_contentInternalScrollCallBackObject.scrollDownOneLine();
                return (true);
            } // end if
        } // end if
        return (false);
    } // End of the function
    function scrollLeft()
    {
        if (m_scrollLeft)
        {
            var _loc2 = m_dragLeft;
            if (m_mcScrollHorizontal.slider._x - 1 > _loc2)
            {
                m_mcScrollHorizontal.slider._x = m_mcScrollHorizontal.slider._x - m_mcScrollVertical.sliderBG._width / 5;
            }
            else
            {
                m_mcScrollHorizontal.slider._x = m_dragLeft;
            } // end else if
            m_mcScrollHorizontal.sliderBevel._x = m_mcScrollHorizontal.slider._x;
            this.placeContent();
            return (true);
        } // end if
        return (false);
    } // End of the function
    function scrollRight()
    {
        if (m_scrollRight)
        {
            var _loc2 = m_dragRight - m_mcScrollHorizontal.slider._width;
            if (m_mcScrollHorizontal.slider._x + 1 < _loc2)
            {
                m_mcScrollHorizontal.slider._x = m_mcScrollHorizontal.slider._x + m_mcScrollVertical.sliderBG._width / 5;
            }
            else
            {
                m_mcScrollHorizontal.slider._x = _loc2;
            } // end else if
            m_mcScrollHorizontal.sliderBevel._x = m_mcScrollHorizontal.slider._x;
            this.placeContent();
            return (true);
        } // end if
        return (false);
    } // End of the function
    function skip()
    {
        this.update();
        if (m_scrollSkipVerticalToggle)
        {
            m_scrollSkipVertical = _ymouse;
        }
        else
        {
            m_scrollSkipVertical = 0;
        } // end else if
        if (m_scrollSkipVertical > 0)
        {
            if (m_scrollSkipVertical < m_mcScrollVertical.slider._y + m_mcScrollVertical._y)
            {
                if (m_mcScrollVertical.slider._y - m_mcScrollVertical.slider._height > m_mcScrollVertical.sliderBG._y + m_scrollSliderMargin)
                {
                    m_mcScrollVertical.slider._y = m_mcScrollVertical.slider._y - m_mcScrollVertical.slider._height;
                }
                else
                {
                    m_mcScrollVertical.slider._y = m_mcScrollVertical.sliderBG._y + m_scrollSliderMargin;
                } // end else if
            }
            else if (m_scrollSkipVertical > m_mcScrollVertical.slider._y + m_mcScrollVertical._y)
            {
                if (m_mcScrollVertical.slider._y + m_mcScrollVertical.slider._height * 2 < m_mcScrollVertical.sliderBG._height - m_scrollSliderMargin * 2 + (m_mcScrollVertical.sliderBG._y + m_scrollSliderMargin))
                {
                    m_mcScrollVertical.slider._y = m_mcScrollVertical.slider._y + m_mcScrollVertical.slider._height;
                }
                else
                {
                    m_mcScrollVertical.slider._y = m_mcScrollVertical.sliderBG._height - m_scrollSliderMargin + m_mcScrollVertical.sliderBG._y - m_mcScrollVertical.slider._height;
                } // end else if
            } // end else if
            m_mcScrollVertical.sliderBevel._y = m_mcScrollVertical.slider._y;
            this.placeContent();
        } // end if
        if (m_scrollSkipHorizontalToggle)
        {
            m_scrollSkipHorizontal = _xmouse;
        }
        else
        {
            m_scrollSkipHorizontal = 0;
        } // end else if
        if (m_scrollSkipHorizontal > 0)
        {
            if (m_scrollSkipHorizontal < m_mcScrollHorizontal.slider._x + m_mcScrollHorizontal._x)
            {
                if (m_mcScrollHorizontal.slider._x - m_mcScrollHorizontal.slider._width > m_mcScrollHorizontal.sliderBG._x + m_scrollSliderMargin)
                {
                    m_mcScrollHorizontal.slider._x = m_mcScrollHorizontal.slider._x - m_mcScrollHorizontal.slider._width;
                }
                else
                {
                    m_mcScrollHorizontal.slider._x = m_mcScrollHorizontal.sliderBG._x + m_scrollSliderMargin;
                } // end else if
            }
            else if (m_scrollSkipHorizontal > m_mcScrollHorizontal.slider._x + m_mcScrollHorizontal._x)
            {
                if (m_mcScrollHorizontal.slider._x + m_mcScrollHorizontal.slider._width * 2 < m_mcScrollHorizontal.sliderBG._width - m_scrollSliderMargin * 2 + m_mcScrollHorizontal.sliderBG._x)
                {
                    m_mcScrollHorizontal.slider._x = m_mcScrollHorizontal.slider._x + m_mcScrollHorizontal.slider._width;
                }
                else
                {
                    m_mcScrollHorizontal.slider._x = m_mcScrollHorizontal.sliderBG._width - m_scrollSliderMargin + m_mcScrollHorizontal.sliderBG._x - m_mcScrollHorizontal.slider._width;
                } // end else if
            } // end else if
            m_mcScrollHorizontal.sliderBevel._x = m_mcScrollHorizontal.slider._x;
            this.placeContent();
        } // end if
        return (false);
    } // End of the function
    function slide()
    {
        if (m_sliding)
        {
            if (m_slidingVertical)
            {
                this.setBoundaries(m_mcScrollVertical, true);
            }
            else
            {
                this.setBoundaries(m_mcScrollHorizontal, false);
            } // end else if
            m_dragYToggle = true;
            m_dragXToggle = true;
            if (m_dragMC._parent._ymouse - m_dragClickYOffset <= m_dragTop)
            {
                m_dragYToggle = false;
                m_dragMC._y = m_dragTop;
            } // end if
            if (m_dragMC._parent._ymouse - m_dragClickYOffset > m_dragBottom - m_dragMC._height)
            {
                m_dragYToggle = false;
                if (m_dragRight == m_dragLeft)
                {
                    m_dragMC._y = m_dragBottom - m_dragMC._height;
                }
                else
                {
                    m_dragMC._y = m_dragBottom;
                } // end if
            } // end else if
            if (m_dragMC._parent._xmouse - m_dragClickXOffset <= m_dragLeft)
            {
                m_dragXToggle = false;
                m_dragMC._x = m_dragLeft;
            } // end if
            if (m_dragMC._parent._xmouse - m_dragClickXOffset > m_dragRight - m_dragMC._width)
            {
                m_dragXToggle = false;
                if (m_dragTop == m_dragBottom)
                {
                    m_dragMC._x = m_dragRight - m_dragMC._width;
                }
                else
                {
                    m_dragMC._x = m_dragRight;
                } // end if
            } // end else if
            if (m_dragYToggle)
            {
                m_dragMC._y = m_dragMC._parent._ymouse - m_dragClickYOffset;
            } // end if
            if (m_dragXToggle)
            {
                m_dragMC._x = m_dragMC._parent._xmouse - m_dragClickXOffset;
            } // end if
            if (m_slidingVertical)
            {
                m_mcScrollVertical.sliderBevel._y = m_mcScrollVertical.slider._y;
            }
            else
            {
                m_mcScrollHorizontal.sliderBevel._x = m_mcScrollHorizontal.slider._x;
            } // end else if
            this.placeContent();
        } // end if
        if (!m_scrollVerticalVisible && !m_scrollHorizontalVisible)
        {
            m_sliding = false;
        } // end if
        return (m_sliding);
    } // End of the function
    function placeContent()
    {
        var _loc4 = m_containerHeight;
        var _loc5 = m_containerWidth;
        m_scrollYPercent = (m_mcScrollVertical.slider._y - m_scrollSliderMargin - m_mcScrollVertical.sliderBG._y) / (m_mcScrollVertical.sliderBG._height - m_scrollSliderMargin * 2 - m_mcScrollVertical.slider._height);
        m_scrollXPercent = (m_mcScrollHorizontal.slider._x - m_scrollSliderMargin - m_mcScrollHorizontal.sliderBG._x) / (m_mcScrollHorizontal.sliderBG._width - m_scrollSliderMargin * 2 - m_mcScrollHorizontal.slider._width);
        if (m_scrollYPercent < 1.000000E-002)
        {
            m_scrollYPercent = 0;
        } // end if
        if (m_scrollYPercent >= 9.900000E-001)
        {
            m_scrollYPercent = 1;
        } // end if
        if (m_scrollXPercent < 1.000000E-002)
        {
            m_scrollXPercent = 0;
        } // end if
        if (m_scrollXPercent >= 9.900000E-001)
        {
            m_scrollXPercent = 1;
        } // end if
        var _loc3;
        var _loc2;
        if (m_scrollVerticalVisible)
        {
            _loc2 = ((m_contentHeight - _loc4) * m_scrollYPercent - m_contentOffsetY) * -1;
        }
        else
        {
            _loc2 = m_contentOffsetY;
        } // end else if
        if (m_scrollHorizontalVisible)
        {
            _loc3 = ((m_contentWidth - _loc5) * m_scrollXPercent - m_contentOffsetX) * -1;
        }
        else
        {
            _loc3 = m_contentOffsetX;
        } // end else if
        _loc2 = this.applySkip(_loc2, true);
        _loc3 = this.applySkip(_loc3, false);
        if (m_contentInternalScroll)
        {
            if (_loc2 != m_oldY || _loc3 != m_oldX)
            {
                _loc2 = _loc2 - m_contentOffsetY;
                _loc3 = _loc3 - m_contentOffsetX;
                if (_loc2 > 0 || _loc3 > 0)
                {
                    m_contentInternalScrollCallBackObject[m_contentInternalScrollCallBack](0, 0);
                }
                else
                {
                    m_contentInternalScrollCallBackObject[m_contentInternalScrollCallBack](_loc3 * -1, _loc2 * -1);
                } // end if
            } // end else if
            if (m_contentInternalScrollOffsetY > 0 && m_oldContentInternalScrollOffsetY != m_contentInternalScrollOffsetY)
            {
                m_contentInternalScrollCallBackObject[m_contentInternalScrollOffsetYCallback](m_contentInternalScrollOffsetY);
            } // end if
            if (m_contentInternalScrollOffsetX > 0 && m_oldContentInternalScrollOffsetX != m_contentInternalScrollOffsetX)
            {
                m_contentInternalScrollCallBackObject[m_contentInternalScrollOffsetXCallback](m_contentInternalScrollOffsetX);
            } // end if
        }
        else
        {
            this.setContentPlacement(_loc3, _loc2);
        } // end else if
        m_oldY = _loc2;
        m_oldX = _loc3;
        m_oldContentInternalScrollOffsetY = m_contentInternalScrollOffsetY;
        m_oldContentInternalScrollOffsetX = m_contentInternalScrollOffsetX;
    } // End of the function
    function updateManager()
    {
        this.update();
        trace ("updatemanager in scrolltainer " + m_updating);
        return (m_updating);
    } // End of the function
    function applySkip(nPlacement, isVertical)
    {
        var _loc3 = nPlacement;
        var _loc2 = 0;
        if (isVertical)
        {
            _loc2 = this.getVerticalSkips();
            if (_loc2 > 0)
            {
                _loc3 = Math.round(nPlacement / _loc2) * _loc2;
            } // end if
        }
        else
        {
            _loc2 = this.getHorizontalSkips();
            if (_loc2 > 0)
            {
                _loc3 = Math.round(nPlacement / _loc2) * _loc2;
            } // end if
        } // end else if
        return (_loc3);
    } // End of the function
    function setVerticalSkips(nSkipValue)
    {
        m_verticalScrollSkip = nSkipValue;
    } // End of the function
    function getVerticalSkips()
    {
        return (m_verticalScrollSkip);
    } // End of the function
    function setHorizontalSkips(nSkipValue)
    {
        m_horizontalScrollSkip = nSkipValue;
    } // End of the function
    function getHorizontalSkips()
    {
        return (m_horizontalScrollSkip);
    } // End of the function
    function getObject(sContentListId)
    {
        var _loc2 = this.getContentMc();
        if (sContentListId.length > 0)
        {
            return (_loc2[sContentListId].getObject());
        }
        else if (m_activeComponent)
        {
            return (m_activeComponent.getObject());
        } // end else if
    } // End of the function
    function getValue(sContentListId)
    {
        var _loc3 = this.getContentMc();
        var _loc2 = "";
        if (sContentListId.length > 0)
        {
            _loc2 = _loc3[sContentListId].getValue();
        }
        else if (m_activeComponent)
        {
            _loc2 = m_activeComponent.getValue();
        } // end else if
        return (_loc2);
    } // End of the function
    function setActiveScrolledComponent(mcClip)
    {
        m_activeComponent = mcClip;
    } // End of the function
    function getActiveScrolledComponent()
    {
        return (m_activeComponent);
    } // End of the function
    function resetSelection()
    {
        var _loc2 = this.getActiveScrolledComponent();
        if (_loc2)
        {
            _loc2.deSelectRows();
        }
        else
        {
            trace ("no object to reset selection " + _loc2);
        } // end else if
    } // End of the function
    function flush(noCallback)
    {
        var _loc2 = this.getActiveScrolledComponent();
        if (_loc2)
        {
            _loc2.flush(noCallback);
        }
        else
        {
            trace ("no object to flush " + _loc2);
        } // end else if
    } // End of the function
    var m_scrollSliderMargin = 2;
    var m_scrollArrowColor = 0;
    var m_scrollArrowBGColor = dice.UI.prototype.m_UIBGColor;
    var m_scrollArrowBGAlpha = dice.UI.prototype.m_UIBGAlpha;
    var m_scrollThickness = 17;
    var m_scrollSliderThicknessMinimum = 0;
    var m_scrollSliderColor = dice.UI.prototype.m_UITriggerColor;
    var m_scrollSliderBGColor = dice.UI.prototype.m_UIBGColor;
    var m_scrollSliderBGAlpha = dice.UI.prototype.m_UIBGAlpha;
    var m_bevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_bevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_bevelAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_sliderBevelTopLeftColor = dice.UI.prototype.m_UIBevelTopLeftColor;
    var m_sliderBevelBottomRightColor = dice.UI.prototype.m_UIBevelBottomRightColor;
    var m_sliderBevelAlpha = 0;
    var m_scrollPaneInitWidth = 0;
    var m_scrollPaneInitHeight = 0;
    var m_scrollBarResizeWidth = 0;
    var m_scrollBarResizeHeight = 0;
    var m_scrollBarResizeX = 0;
    var m_scrollBarResizeY = 0;
    var m_scrollerType = 0;
    var m_sliding = false;
    var m_slidingVertical = true;
    var m_dragTop = 0;
    var m_dragBottom = 0;
    var m_dragLeft = 0;
    var m_dragRight = 0;
    var m_dragClickYOffset = 0;
    var m_dragClickXOffset = 0;
    var m_scrollDown = false;
    var m_scrollUp = false;
    var m_scrollLeft = false;
    var m_scrollRight = false;
    var m_scrollYPercent = 0;
    var m_scrollXPercent = 0;
    var m_scrollSkipVertical = 0;
    var m_scrollSkipHorizontal = 0;
    var m_scrollSkipVerticalToggle = false;
    var m_scrollSkipHorizontalToggle = false;
    var m_oldX = -1;
    var m_oldY = -1;
    var m_verticalScrollSkip = 0;
    var m_horizontalScrollSkip = 0;
    var isScroller = true;
} // End of Class
