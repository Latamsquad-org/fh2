class dice.UIs.Lists.ColumnList extends dice.UIs.List
{
    var m_inAuthorMode, m_columnTextTypes, __get__columnTextTypes, m_columnTypes, __get__columnTypes, m_columnTextYOffsets, __get__columnTextYOffsets, m_columnTexts, __get__columnTexts, m_columnTextMargins, __get__columnTextMargins, m_columnAligns, __get__columnAligns, m_columnColors, __get__columnColors, m_columnWidths, __get__columnWidths, __get__listIdMarkColor, __get__listIdMarkId, __get__authorListLength, m_rowDrawType, __get__rowDrawType, __get__columnLineTextColor, __get__columnLineColor, __get__columnLineColorAlpha, m_lineHeight, __get__lineHeight, __get__columnToUseTextFrom, m_listId, __get__listId, __get__linesVisible, m_columns, __get__columnsVisible, m_asyncList, __get__asyncList, m_selectionEnabled, __get__selectionEnabled, m_silentSelectionEnabled, __get__silentSelectionEnabled, setCallback, __get__callBackFunction, m_callbackFunction, m_useInternalScroll, __get__useInternalScroll, _parent, scrollTainer, mcBoundingBox, m_listObject, setCallbackObject, setCallbackGetObject, m_initWidth, m_callbackFrequency, getNextHighestDepth, createEmptyMovieClip, m_mcList, m_lastList, rowIndex, m_lineWidth, setCallbackObjectInit, setCallbackInit, setCallbackSpecial, setCallbackGet, m_callbackObjectSpecial, m_selectedRowObject, setColor, runCallback, m_selectedRowCells, m_updating, __set__asyncList, __set__authorListLength, __set__callBackFunction, __set__columnAligns, __set__columnColors, __set__columnLineColor, __set__columnLineColorAlpha, __set__columnLineTextColor, __set__columnTextMargins, __set__columnTextTypes, __set__columnTextYOffsets, __set__columnTexts, __set__columnToUseTextFrom, __set__columnTypes, __set__columnWidths, __set__columnsVisible, __set__lineHeight, __set__linesVisible, __set__listId, __set__listIdMarkColor, __set__listIdMarkId, __set__rowDrawType, __set__selectionEnabled, __set__silentSelectionEnabled, __set__useInternalScroll;
    function ColumnList(cancelInit)
    {
        super(true);
        if (!cancelInit)
        {
            this.init();
            this.draw();
            this.createChildren();
            this.arrange();
            this.setEvents();
            this.flush(false);
            if (m_inAuthorMode)
            {
                this.showAuthColLook();
            } // end if
        } // end if
    } // End of the function
    function set columnTextTypes(sValue)
    {
        var _loc3 = new String(sValue);
        var _loc2 = _loc3.split(",");
        m_columnTextTypes = new Array();
        if (_loc2.length > 1)
        {
            m_columnTextTypes = _loc2;
        }
        else
        {
            m_columnTextTypes[0] = String(sValue);
        } // end else if
        //return (this.columnTextTypes());
        null;
    } // End of the function
    function get columnTextTypes()
    {
        return (m_columnTextTypes);
    } // End of the function
    function set columnTypes(sValue)
    {
        var _loc3 = new String(sValue);
        var _loc2 = _loc3.split(",");
        m_columnTypes = new Array();
        if (_loc2.length > 1)
        {
            m_columnTypes = _loc2;
        }
        else
        {
            m_columnTypes[0] = String(sValue);
        } // end else if
        //return (this.columnTypes());
        null;
    } // End of the function
    function get columnTypes()
    {
        return (m_columnTypes);
    } // End of the function
    function set columnTextYOffsets(sValue)
    {
        var _loc3 = new String(sValue);
        var _loc2 = _loc3.split(",");
        m_columnTextYOffsets = new Array();
        if (_loc2.length > 1)
        {
            m_columnTextYOffsets = _loc2;
        }
        else
        {
            m_columnTextYOffsets[0] = String(sValue);
        } // end else if
        //return (this.columnTextYOffsets());
        null;
    } // End of the function
    function get columnTextYOffsets()
    {
        return (m_columnTextYOffsets);
    } // End of the function
    function set columnTexts(sValue)
    {
        var _loc3 = new String(sValue);
        var _loc2 = _loc3.split(",");
        m_columnTexts = new Array();
        if (_loc2.length > 1)
        {
            m_columnTexts = _loc2;
        }
        else
        {
            m_columnTexts[0] = String(sValue);
        } // end else if
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.columnTexts());
        null;
    } // End of the function
    function get columnTexts()
    {
        return (m_columnTexts);
    } // End of the function
    function set columnTextMargins(sValue)
    {
        var _loc3 = new String(sValue);
        var _loc2 = _loc3.split(",");
        m_columnTextMargins = new Array();
        if (_loc2.length > 1)
        {
            m_columnTextMargins = _loc2;
        }
        else
        {
            m_columnTextMargins[0] = Number(sValue);
        } // end else if
        //return (this.columnTextMargins());
        null;
    } // End of the function
    function get columnTextMargins()
    {
        return (m_columnTextMargins);
    } // End of the function
    function set columnAligns(sValue)
    {
        var _loc3 = new String(sValue);
        var _loc2 = _loc3.split(",");
        m_columnAligns = new Array();
        if (_loc2.length > 1)
        {
            m_columnAligns = _loc2;
        }
        else
        {
            m_columnAligns[0] = Number(sValue);
        } // end else if
        //return (this.columnAligns());
        null;
    } // End of the function
    function get columnAligns()
    {
        return (m_columnAligns);
    } // End of the function
    function set columnColors(sValue)
    {
        var _loc3 = new String(sValue);
        var _loc2 = _loc3.split(",");
        m_columnColors = new Array();
        if (_loc2.length > 1)
        {
            m_columnColors = _loc2;
        }
        else
        {
            m_columnColors[0] = Number(sValue);
        } // end else if
        //return (this.columnColors());
        null;
    } // End of the function
    function get columnColors()
    {
        return (m_columnColors);
    } // End of the function
    function set columnWidths(sValue)
    {
        var _loc3 = new String(sValue);
        var _loc2 = _loc3.split(", ");
        m_columnWidths = new Array();
        if (_loc2.length > 1)
        {
            m_columnWidths = _loc2;
        }
        else
        {
            m_columnWidths[0] = Number(sValue);
        } // end else if
        //return (this.columnWidths());
        null;
    } // End of the function
    function get columnWidths()
    {
        return (m_columnWidths);
    } // End of the function
    function set listIdMarkColor(nValue)
    {
        m_listIdMarkColor = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.listIdMarkColor());
        null;
    } // End of the function
    function get listIdMarkColor()
    {
        return (m_listIdMarkColor);
    } // End of the function
    function set listIdMarkId(nValue)
    {
        m_listIdMarkId = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.listIdMarkId());
        null;
    } // End of the function
    function get listIdMarkId()
    {
        return (m_listIdMarkId);
    } // End of the function
    function set authorListLength(nValue)
    {
        m_authorListLength = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.authorListLength());
        null;
    } // End of the function
    function get authorListLength()
    {
        return (m_authorListLength);
    } // End of the function
    function set rowDrawType(nValue)
    {
        m_rowDrawType = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.rowDrawType());
        null;
    } // End of the function
    function get rowDrawType()
    {
        return (m_rowDrawType);
    } // End of the function
    function set columnLineTextColor(nValue)
    {
        m_columnLineTextColor = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.columnLineTextColor());
        null;
    } // End of the function
    function get columnLineTextColor()
    {
        return (m_columnLineTextColor);
    } // End of the function
    function set columnLineColor(nValue)
    {
        m_columnLineColor = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.columnLineColor());
        null;
    } // End of the function
    function get columnLineColor()
    {
        return (m_columnLineColor);
    } // End of the function
    function set columnLineColorAlpha(nValue)
    {
        m_columnLineColorAlpha = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.columnLineColorAlpha());
        null;
    } // End of the function
    function get columnLineColorAlpha()
    {
        return (m_columnLineColorAlpha);
    } // End of the function
    function set lineHeight(nValue)
    {
        m_lineHeight = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.lineHeight());
        null;
    } // End of the function
    function get lineHeight()
    {
        return (m_lineHeight);
    } // End of the function
    function set columnToUseTextFrom(nValue)
    {
        m_columnToUseTextFrom = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.columnToUseTextFrom());
        null;
    } // End of the function
    function get columnToUseTextFrom()
    {
        return (m_columnToUseTextFrom);
    } // End of the function
    function set listId(nValue)
    {
        m_listId = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.listId());
        null;
    } // End of the function
    function get listId()
    {
        return (m_listId);
    } // End of the function
    function set linesVisible(nValue)
    {
        m_listCount = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.linesVisible());
        null;
    } // End of the function
    function get linesVisible()
    {
        return (m_listCount);
    } // End of the function
    function set columnsVisible(nValue)
    {
        m_columns = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.columnsVisible());
        null;
    } // End of the function
    function get columnsVisible()
    {
        return (m_columns);
    } // End of the function
    function set asyncList(nValue)
    {
        m_asyncList = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.asyncList());
        null;
    } // End of the function
    function get asyncList()
    {
        return (m_asyncList);
    } // End of the function
    function set selectionEnabled(nValue)
    {
        m_selectionEnabled = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.selectionEnabled());
        null;
    } // End of the function
    function get selectionEnabled()
    {
        return (m_selectionEnabled);
    } // End of the function
    function set silentSelectionEnabled(nValue)
    {
        m_silentSelectionEnabled = nValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.silentSelectionEnabled());
        null;
    } // End of the function
    function get silentSelectionEnabled()
    {
        return (m_silentSelectionEnabled);
    } // End of the function
    function set callBackFunction(sValue)
    {
        this.setCallback(sValue);
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.callBackFunction());
        null;
    } // End of the function
    function get callBackFunction()
    {
        return (m_callbackFunction);
    } // End of the function
    function set useInternalScroll(bValue)
    {
        m_useInternalScroll = bValue;
        if (m_inAuthorMode)
        {
            this.authorModeUpdate();
        } // end if
        //return (this.useInternalScroll());
        null;
    } // End of the function
    function get useInternalScroll()
    {
        return (m_useInternalScroll);
    } // End of the function
    function showAuthColLook(isUpdate)
    {
        var _loc5 = new Array();
        _loc5[0] = new Object();
        _loc5[0].id = "testid";
        _loc5[0].testy = "apa";
        var _loc3 = new Array();
        _loc3[0] = new Object();
        _loc3[0].gamespy = 1;
        _loc3[0].size = 2;
        _loc3[0].gameMode = "gpm_cq";
        _loc3[0].maxPlayers = 16;
        _loc3[0].mapName = "wetlands";
        _loc3[0].path = "dalian_plant";
        _loc3[0].disabled = 0;
        _loc3[0].id = 666;
        _loc3[0].password = "Kalle";
        _loc3[0].selected = true;
        for (var _loc2 = 0; _loc2 < m_columnTexts.length; ++_loc2)
        {
            _loc3[_loc2 + 1] = m_columnTexts[_loc2];
        } // end of for
        for (var _loc4 = 0; _loc4 < m_authorListLength; ++_loc4)
        {
            _loc5.push(_loc3);
        } // end of for
        if (!isUpdate)
        {
            this.drawList(_loc5);
        }
        else
        {
            this.fillList(_loc5);
        } // end else if
    } // End of the function
    function init()
    {
        super.init();
        scrollTainer = _parent._parent._parent;
        if (mcBoundingBox)
        {
            mcBoundingBox._visible = false;
            mcBoundingBox._width = 0;
            mcBoundingBox._height = 0;
        } // end if
        m_listObject = new dice.lists.List(m_listId, m_listStartIndex, m_listCount);
        m_listObject.setCallback(this, "drawList");
        _parent.currentListComponent = this;
        this.startUpdate();
        this.setCallbackObject(_parent);
        this.setCallbackGetObject(this);
        m_containerWidth = m_initWidth;
        this.setScrollType();
    } // End of the function
    function startUpdate()
    {
        _root.updateManager1.registerCallback(this, "updateManager", m_callbackFrequency);
    } // End of the function
    function draw()
    {
        this.createEmptyMovieClip("m_mcList", this.getNextHighestDepth());
    } // End of the function
    function createChildren()
    {
    } // End of the function
    function arrange(noFullWidthDraw)
    {
    } // End of the function
    function authorModeUpdate()
    {
    } // End of the function
    function update()
    {
        super.update();
        m_listObject.update();
    } // End of the function
    function setEvents()
    {
    } // End of the function
    function clearFilledContent()
    {
        var _loc6 = m_listStartIndex;
        var _loc5;
        var _loc2;
        for (var _loc4 = _loc6 + 1; _loc4 <= m_listCount + _loc6; ++_loc4)
        {
            _loc5 = m_mcList["rowBG" + (_loc4 - _loc6)];
            if (_loc5)
            {
                _loc5.onPress = function ()
                {
                };
                _loc5.onRelease = function ()
                {
                };
                _loc5.onReleaseOutside = function ()
                {
                };
                _loc5.onDoublePress = function ()
                {
                };
            } // end if
            for (var _loc3 = 1; _loc3 <= m_columns; ++_loc3)
            {
                _loc2 = m_mcList["row" + (_loc4 - _loc6) + "cell" + _loc3];
                if (_loc2.cellText.ColumnListTextField)
                {
                    _loc2.cellText.ColumnListTextField.text = " ";
                    _loc2.cellText._visible = false;
                } // end if
                if (_loc2.cellImage)
                {
                    _loc2.cellImage.removeMovieClip();
                } // end if
            } // end of for
        } // end of for
    } // End of the function
    function drawList(listArray)
    {
        var m_cellWidth = 0;
        var m_currentRow;
        var m_currentRowY = 0;
        var m_currentRowWidth = 0;
        var m_currentCell;
        var m_cellText = "";
        var m_cellTextType = 0;
        var m_cellTextMargin = 0;
        var m_cellAlign = 1;
        var m_cellTextYOffset = 0;
        var m_cellType = 0;
        var m_cellWidth = 0;
        var m_cellXOffset = 0;
        this.m_mcList._y = this.m_listY;
        this.m_mcList._x = this.m_listX;
        m_currentRowY = 0;
        var rowIndex = 1;
        while (rowIndex <= this.m_listCount)
        {
            m_cellWidth = 0;
            this.m_currentCellX = 0;
            m_currentRowWidth = 0;
            with (this.m_mcList)
            {
                m_currentRow = createEmptyMovieClip("rowBG" + rowIndex, getNextHighestDepth());
                m_currentRow.rowIndex = rowIndex;
                with (m_currentRow)
                {
                    lineStyle(0, 0, 0);
                    beginFill(_parent._parent.m_columnLineColor, 100);
                    moveTo(0, 0);
                    lineTo(50, 0);
                    lineTo(50, 50);
                    lineTo(0, 50);
                    endFill();
                    _x = 0;
                    _y = m_currentRowY;
                    _height = _parent._parent.m_lineHeight;
                    if (rowIndex % 2 == 1)
                    {
                        _alpha = _parent._parent.m_columnLineColorAlpha;
                    }
                    else
                    {
                        _alpha = 0;
                    } // end else if
                } // End of with
            } // End of with
            var cellIndex = 1;
            while (cellIndex <= this.m_columns)
            {
                m_cellText = this.getSetting("m_columnTexts", cellIndex);
                m_cellTextType = Number(this.getSetting("m_columnTextTypes", cellIndex));
                m_cellTextMargin = Number(this.getSetting("m_columnTextMargins", cellIndex));
                m_cellTextYOffset = Number(this.getSetting("m_columnTextYOffsets", cellIndex));
                m_cellAlign = Number(this.getSetting("m_columnAligns", cellIndex));
                m_cellType = Number(this.getSetting("m_columnTypes", cellIndex));
                m_cellWidth = Number(this.getSetting("m_columnWidths", cellIndex, true));
                m_cellXOffset = 0;
                if (m_cellTextType == 0)
                {
                    m_cellXOffset = this.m_smallTextOffsetX;
                }
                else if (m_cellTextType == 1)
                {
                    m_cellXOffset = this.m_largeTextOffsetX;
                } // end else if
                with (this.m_mcList)
                {
                    m_currentCell = createEmptyMovieClip("row" + rowIndex + "cell" + cellIndex, getNextHighestDepth());
                    with (m_currentCell)
                    {
                        _y = m_currentRowY;
                        _x = _parent._parent.m_currentCellX + m_cellXOffset;
                    } // End of with
                } // End of with
                if (m_cellType == 0)
                {
                    if (m_cellAlign == 1)
                    {
                        if (m_cellTextType == 0)
                        {
                            m_currentCell.attachMovie("mcColumnListLeft", "cellText", this.getNextHighestDepth());
                        }
                        else
                        {
                            m_currentCell.attachMovie("mcColumnListLeftLarge", "cellText", this.getNextHighestDepth());
                        } // end else if
                    }
                    else if (m_cellAlign == 2)
                    {
                        if (m_cellTextType == 0)
                        {
                            m_currentCell.attachMovie("mcColumnListCenter", "cellText", this.getNextHighestDepth());
                        }
                        else
                        {
                            m_currentCell.attachMovie("mcColumnListCenterLarge", "cellText", this.getNextHighestDepth());
                        } // end else if
                    }
                    else if (m_cellAlign == 3)
                    {
                        if (m_cellTextType == 0)
                        {
                            m_currentCell.attachMovie("mcColumnListRight", "cellText", this.getNextHighestDepth());
                        }
                        else
                        {
                            m_currentCell.attachMovie("mcColumnListRightLarge", "cellText", this.getNextHighestDepth());
                        } // end else if
                    } // end else if
                    m_currentCell.cellText.ColumnListTextField.textColor = this.m_columnLineTextColor;
                    m_currentCell.cellText.ColumnListTextField.text = "";
                    m_currentCell.cellText._y = this.m_lineHeight / 2 - 9 + m_cellTextYOffset;
                    m_currentCell.cellText._x = m_cellTextMargin;
                }
                else if (m_cellType == 2)
                {
                    with (this.m_mcList)
                    {
                    } // End of with
                }
                else if (m_cellType == 4)
                {
                    with (this.m_mcList)
                    {
                    } // End of with
                }
                else if (m_cellType == 3)
                {
                    m_currentCell.attachMovie("mcCreditsTextLocalizedLarge", "cellText2", this.getNextHighestDepth());
                    m_currentCell.attachMovie("mcCreditsTextLocalized", "cellText1", this.getNextHighestDepth());
                    m_currentCell.attachMovie("mcCreditsTextNames", "cellText0", this.getNextHighestDepth());
                    m_currentCell.cellText2._visible = false;
                    m_currentCell.cellText1._visible = false;
                    m_currentCell.cellText0._visible = false;
                    m_currentCell.cellText2.ColumnListTextField.textColor = this.m_columnLineTextColor;
                    m_currentCell.cellText1.ColumnListTextField.textColor = this.m_columnLineTextColor;
                    m_currentCell.cellText0.ColumnListTextField.textColor = this.m_columnLineTextColor;
                    m_currentCell.cellText2.ColumnListTextField.text = "";
                    m_currentCell.cellText1.ColumnListTextField.text = "";
                    m_currentCell.cellText0.ColumnListTextField.text = "";
                    m_currentCell.cellText2._y = this.m_lineHeight / 2 - 9 + m_cellTextYOffset;
                    m_currentCell.cellText1._y = this.m_lineHeight / 2 - 9 + m_cellTextYOffset;
                    m_currentCell.cellText0._y = this.m_lineHeight / 2 - 9 + m_cellTextYOffset;
                    m_currentCell.cellText2._x = m_cellTextMargin;
                    m_currentCell.cellText1._x = m_cellTextMargin;
                    m_currentCell.cellText0._x = m_cellTextMargin;
                } // end else if
                m_currentRowWidth = m_currentRowWidth + m_cellWidth;
                this.m_currentCellX = this.m_currentCellX + m_cellWidth;
                ++cellIndex;
            } // end while
            m_currentRowY = m_currentRowY + this.m_lineHeight;
            if (this.m_containerWidth > 0)
            {
                m_currentRowWidth = this.m_containerWidth;
            } // end if
            if (m_currentRow)
            {
                m_currentRow._width = m_currentRowWidth;
            } // end if
            ++rowIndex;
        } // end while
        m_currentRowWidth = 0;
        this.setNewCallback();
        if (!this.m_inAuthorMode)
        {
            this.fillList(listArray);
        } // end if
    } // End of the function
    function hideAllRows()
    {
        for (var _loc2 = 0; _loc2 < m_lastList.length; ++_loc2)
        {
            var _loc3 = m_mcList["rowBG" + _loc2];
            _loc3._visible = false;
        } // end of for
    } // End of the function
    function setListColor(nColor)
    {
        m_columnLineTextColor = nColor;
        var _loc5;
        var _loc4;
        for (var _loc3 = m_listStartIndex + 1; _loc3 <= m_listCount + m_listStartIndex; ++_loc3)
        {
            _loc5 = m_mcList["rowBG" + _loc3];
            for (var _loc2 = 1; _loc2 <= m_columns; ++_loc2)
            {
                _loc4 = m_mcList["row" + (_loc3 - m_listStartIndex) + "cell" + _loc2];
                this.setTextColors(_loc5, _loc4);
            } // end of for
        } // end of for
    } // End of the function
    function setTextColors(crowObject, cellObject)
    {
        if (cellObject)
        {
            if (cellObject.cellText.ColumnListTextField)
            {
                if (crowObject.disabled == 1)
                {
                    cellObject.cellText.ColumnListTextField.textColor = m_columnLineTextColorWarning;
                    if (cellObject.cellText2)
                    {
                        cellObject.cellText2.ColumnListTextField.textColor = m_columnLineTextColorWarning;
                    } // end if
                    if (cellObject.cellText1)
                    {
                        cellObject.cellText1.ColumnListTextField.textColor = m_columnLineTextColorWarning;
                    } // end if
                    if (cellObject.cellText0)
                    {
                        cellObject.cellText0.ColumnListTextField.textColor = m_columnLineTextColorWarning;
                    } // end if
                }
                else if (crowObject.disabled == 2)
                {
                    cellObject.cellText.ColumnListTextField.textColor = m_columnLineTextColorDisabled;
                    if (cellObject.cellText2)
                    {
                        cellObject.cellText2.ColumnListTextField.textColor = m_columnLineTextColorDisabled;
                    } // end if
                    if (cellObject.cellText1)
                    {
                        cellObject.cellText1.ColumnListTextField.textColor = m_columnLineTextColorDisabled;
                    } // end if
                    if (cellObject.cellText0)
                    {
                        cellObject.cellText0.ColumnListTextField.textColor = m_columnLineTextColorDisabled;
                    } // end if
                }
                else if (crowObject.rowObject[m_listIdMarkId] != 1)
                {
                    cellObject.cellText.ColumnListTextField.textColor = m_columnLineTextColor;
                    if (cellObject.cellText2)
                    {
                        cellObject.cellText2.ColumnListTextField.textColor = m_columnLineTextColor;
                    } // end if
                    if (cellObject.cellText1)
                    {
                        cellObject.cellText1.ColumnListTextField.textColor = m_columnLineTextColor;
                    } // end if
                    if (cellObject.cellText0)
                    {
                        cellObject.cellText0.ColumnListTextField.textColor = m_columnLineTextColor;
                    } // end if
                }
                else
                {
                    cellObject.cellText.ColumnListTextField.textColor = m_listIdMarkColor;
                    if (cellObject.cellText2)
                    {
                        cellObject.cellText2.ColumnListTextField.textColor = m_listIdMarkColor;
                    } // end if
                    if (cellObject.cellText1)
                    {
                        cellObject.cellText1.ColumnListTextField.textColor = m_listIdMarkColor;
                    } // end if
                    if (cellObject.cellText0)
                    {
                        cellObject.cellText0.ColumnListTextField.textColor = m_listIdMarkColor;
                    } // end if
                } // end else if
            } // end else if
        } // end else if
    } // End of the function
    function selectRowTest(nRowIndex)
    {
        if (m_selectionEnabled)
        {
            this.selectRow(nRowIndex, false);
        } // end if
    } // End of the function
    function fillList(listArray)
    {
        m_lastList = listArray;
        this.clearFilledContent();
        var _loc5 = m_listStartIndex;
        var _loc8;
        var _loc15 = -1;
        var _loc10 = 0;
        var _loc9 = "";
        var _loc3 = 0;
        var _loc11 = 0;
        var _loc16 = new String();
        for (var _loc4 = _loc5 + 1; _loc4 <= m_listCount + _loc5; ++_loc4)
        {
            _loc8 = m_mcList["rowBG" + (_loc4 - _loc5)];
            if (_loc8)
            {
                _loc8.rowObject = listArray[_loc4 - _loc5][0];
                _loc8.rowObject.listObject = listArray[0][0];
                _loc8.rowValue = listArray[_loc4 - _loc5][m_columnToUseTextFrom];
                _loc8.rowId = listArray[_loc4 - _loc5][0].id;
                _loc8.listIndex = _loc4;
                _loc8.disabled = listArray[_loc4 - _loc5][0].disabled;
                if (m_selectionEnabled)
                {
                    if (listArray.length - 1 >= _loc4 - _loc5 && _loc8.disabled != 2)
                    {
                        _loc8.onPress = function ()
                        {
                            dice.bf2.Sound.playSound("listSelect");
                            _parent._parent.selectRowTest(rowIndex);
                        };
                        _loc8.onDoublePress = function ()
                        {
                            _parent._parent.runCallbackSpecial();
                        };
                        var _loc14 = new Number(listArray[_loc4 - _loc5][0].selected);
                        if (_loc14 > 0)
                        {
                            _loc15 = _loc4 - _loc5;
                        } // end if
                    } // end if
                }
                else if (listArray[_loc4 - _loc5][0].selected == 2)
                {
                    m_silentSelectionEnabled = true;
                    _loc15 = _loc4 - _loc5;
                } // end if
            } // end else if
            for (var _loc7 = 1; _loc7 <= m_columns; ++_loc7)
            {
                _loc10 = Number(this.getSetting("m_columnTypes", _loc7));
                _loc11 = Number(this.getSetting("m_columnTextMargins", _loc7));
                var _loc2 = m_mcList["row" + (_loc4 - _loc5) + "cell" + _loc7];
                if (listArray.length - 1 >= _loc4 - _loc5)
                {
                    _loc9 = listArray[_loc4 - _loc5][_loc7];
                    _loc3 = Number(this.getSetting("m_columnWidths", _loc7, true));
                    if (_loc10 == 0)
                    {
                        this.setTextColors(_loc8, _loc2);
                        if (_loc2)
                        {
                            if (_loc2.cellText.ColumnListTextField)
                            {
                                _loc2.cellText.ColumnListTextField._width = _loc3;
                                _loc2.cellText.ColumnListTextField.text = _loc9;
                                _loc2.cellText._visible = true;
                            } // end if
                        } // end if
                        continue;
                    } // end if
                    if (_loc10 == 2)
                    {
                        var _loc12 = _loc9;
                        if (_loc2)
                        {
                            if (_loc2.cellImage)
                            {
                                _loc2.cellImage.removeMovieClip();
                            } // end if
                            _loc2.createEmptyMovieClip("cellImage", this.getNextHighestDepth());
                            _loc2.cellImage.loadMovie(_loc12);
                            var _loc13 = 0;
                            if (_loc3 == m_lineHeight)
                            {
                                _loc2.cellImage._width = _loc3;
                                _loc2.cellImage._height = _loc3;
                            }
                            else if (_loc3 < m_lineHeight)
                            {
                                _loc13 = m_lineHeight - _loc3;
                                _loc2.cellImage._x = _loc3 / 2 - _loc3 / 2;
                                _loc2.cellImage._y = m_lineHeight / 2 - _loc3 / 2;
                                _loc2.cellImage._width = _loc3;
                                _loc2.cellImage._height = _loc3;
                            }
                            else
                            {
                                _loc13 = m_lineHeight - _loc3;
                                _loc2.cellImage._x = _loc3 / 2 - m_lineHeight / 2;
                                _loc2.cellImage._y = m_lineHeight / 2 - m_lineHeight / 2;
                                _loc2.cellImage._width = m_lineHeight;
                                _loc2.cellImage._height = m_lineHeight;
                            } // end else if
                        } // end else if
                        continue;
                    } // end if
                    if (_loc10 == 4)
                    {
                        _loc12 = _loc9;
                        if (_loc2)
                        {
                            if (_loc2.cellImage)
                            {
                                _loc2.cellImage.removeMovieClip();
                            } // end if
                            _loc2.createEmptyMovieClip("cellImage", this.getNextHighestDepth());
                            _loc2.cellImage.loadMovie(_loc12);
                            _loc13 = 0;
                            _loc2.cellImage._x = _loc11;
                            _loc2.cellImage._y = _loc11;
                            _loc2.cellImage._width = _loc3 - _loc11 * 2;
                            _loc2.cellImage._height = m_lineHeight - _loc11 * 2;
                        } // end if
                        continue;
                    } // end if
                    if (_loc10 == 3)
                    {
                        this.setTextColors(_loc8, _loc2);
                        if (_loc2)
                        {
                            if (listArray[_loc4][0].size == 2)
                            {
                                _loc2.cellText2._visible = true;
                                _loc2.cellText1._visible = false;
                                _loc2.cellText0._visible = false;
                            }
                            else if (listArray[_loc4][0].size == 1)
                            {
                                _loc2.cellText2._visible = false;
                                _loc2.cellText1._visible = true;
                                _loc2.cellText0._visible = false;
                            }
                            else if (listArray[_loc4][0].size == 0)
                            {
                                _loc2.cellText2._visible = false;
                                _loc2.cellText1._visible = false;
                                _loc2.cellText0._visible = true;
                            } // end else if
                            if (_loc2.cellText2.ColumnListTextField && _loc2.cellText1.ColumnListTextField && _loc2.cellText0.ColumnListTextField)
                            {
                                _loc2.cellText2.ColumnListTextField._width = _loc3;
                                _loc2.cellText1.ColumnListTextField._width = _loc3;
                                _loc2.cellText0.ColumnListTextField._width = _loc3;
                                _loc2.cellText2.ColumnListTextField.text = _loc9;
                                _loc2.cellText1.ColumnListTextField.text = _loc9;
                                _loc2.cellText0.ColumnListTextField.text = _loc9;
                            } // end if
                        } // end if
                    } // end if
                } // end if
            } // end of for
        } // end of for
        if (_loc15 > 0)
        {
            if (m_needsPreSelection && m_preselectionEnabled)
            {
                m_needsPreSelection = false;
                this.selectRowTest(_loc15);
            } // end if
        } // end if
        this.setScrollSize();
    } // End of the function
    function getTotalHeight()
    {
        return (m_listObject.getTotalCount() * m_lineHeight);
    } // End of the function
    function setScrollSize()
    {
        if (scrollTainer.isScroller)
        {
            var _loc2 = m_lineWidth;
            var _loc4 = m_listCount * m_lineHeight;
            var _loc3 = m_listObject.getTotalCount() * m_lineHeight;
            if (m_inAuthorMode)
            {
                _loc3 = m_authorListLength * m_lineHeight;
            } // end if
            if (m_useInternalScroll)
            {
                if (scrollTainer.m_scrollVerticalVisible)
                {
                    m_containerWidth = scrollTainer.getInitWidth() - (scrollTainer.m_scrollThickness + 1);
                }
                else
                {
                    m_containerWidth = scrollTainer.getInitWidth();
                } // end else if
                _loc2 = _loc2 - scrollTainer.m_scrollThickness;
                scrollTainer.setInternalScrollCallback(this, "scrollTo", "setListY", "setListX");
                scrollTainer.setContentSize(_loc2, _loc3, 0);
            } // end if
        } // end if
    } // End of the function
    function setScrollType()
    {
        if (scrollTainer.isScroller)
        {
            if (scrollTainer.m_scrollerType == 1)
            {
                this.setPreselection(false);
                m_closeParentContainerOnSelect = true;
                m_needsPreSelection = scrollTainer.m_needsPreSelection;
                m_columnLineTextColor = scrollTainer.m_columnLineTextColor;
                m_columnLineTextColorSelected = scrollTainer.m_columnLineTextColorSelected;
                m_columnLineTextColorDisabled = scrollTainer.m_columnLineTextColorDisabled;
                m_columnLineColorSelected = scrollTainer.m_columnLineColorSelected;
                m_columnLineColorDisabled = scrollTainer.m_columnLineColorDisabled;
                m_columnLineColorAlpha = scrollTainer.m_columnLineColorAlpha;
                m_columnLineColorSelectedAlpha = scrollTainer.m_columnLineColorSelectedAlpha;
                m_columnLineColorDisabledAlpha = scrollTainer.m_columnLineColorDisabledAlpha;
            } // end if
            scrollTainer.setVerticalSkips(m_lineHeight);
            this.setScrollSize();
            this.setCallbackObjectInit(scrollTainer.getCallbackObjectInit());
            this.setCallbackInit(scrollTainer.getCallbackInit());
            this.setCallbackObject(scrollTainer.getCallbackObject());
            this.setCallback(scrollTainer.getCallback());
            this.setCallbackSpecial(scrollTainer.getCallbackSpecial());
            this.setCallbackGetObject(this);
            this.setCallbackGet(scrollTainer.getCallbackGet());
            m_callbackObjectSpecial = scrollTainer.m_callbackObjectSpecial;
            scrollTainer.setActiveScrolledComponent(this);
        }
        else
        {
            this.setCallbackObject(_parent);
        } // end else if
    } // End of the function
    function closeScroller()
    {
        if (m_closeParentContainerOnSelect)
        {
            scrollTainer.selectorToggle(true);
            scrollTainer.setValue(m_selectedRowId, m_selectedRowText, m_selectedRowClickIndex);
        } // end if
    } // End of the function
    function selectRow(nRowIndex, wasScrolled)
    {
        var _loc2;
        if (nRowIndex != m_selectedRowClickIndex)
        {
            if (!wasScrolled && m_selectedRowClickIndex > 0)
            {
                this.deSelectRows();
            } // end if
        } // end if
        if (m_scrollSelectedRow > 0 && m_scrollSelectedRow <= m_listCount)
        {
            this.deSelectRows();
        } // end if
        _loc2 = m_mcList["rowBG" + nRowIndex];
        m_selectedIndex = nRowIndex;
        _loc2.selected = true;
        m_selectedRowId = _loc2.rowId;
        m_selectedRowText = _loc2.rowValue;
        if (wasScrolled != true)
        {
            m_selectedListIndex = _loc2.listIndex;
        } // end if
        m_selectedRowObject = _loc2.rowObject;
        this.setColor(_loc2, m_columnLineColorSelected);
        _loc2._alpha = m_columnLineColorSelectedAlpha;
        m_hasSelectedRow = true;
        m_selectedRows[m_selectedRows.length] = nRowIndex;
        if (wasScrolled != true)
        {
            m_lastSelectedRowClickIndex = m_selectedRowClickIndex;
            m_selectedRowClickIndex = nRowIndex;
            this.closeScroller(true);
            this.runCallback();
        } // end if
    } // End of the function
    function deSelectRows()
    {
        for (var _loc2 = 0; _loc2 < m_selectedRows.length; ++_loc2)
        {
            this.deSelectRow(m_selectedRows[_loc2]);
        } // end of for
        m_selectedRowId = "";
        m_hasSelectedRow = false;
        m_selectedRows = new Array();
    } // End of the function
    function deSelectRow(nDeselectRow)
    {
        var _loc2;
        _loc2 = m_mcList["rowBG" + nDeselectRow];
        _loc2.selected = false;
        m_selectedRowClickIndex = -1;
        if (nDeselectRow % 2 == 1)
        {
            _loc2._alpha = m_columnLineColorAlpha;
            this.setColor(_loc2, m_columnLineColor);
        }
        else
        {
            _loc2._alpha = 0;
        } // end else if
    } // End of the function
    function getSetting(arrayName, nIndex)
    {
        var _loc3 = "";
        var _loc2 = this[arrayName];
        if (_loc2.length > nIndex - 1)
        {
            _loc3 = _loc2[nIndex - 1];
        }
        else
        {
            _loc3 = _loc2[_loc2.length - 1];
        } // end else if
        return (_loc3);
    } // End of the function
    function setRows(nRows)
    {
        m_listCount = nRows;
    } // End of the function
    function getRows()
    {
        return (m_listCount);
    } // End of the function
    function setListY(nY)
    {
        m_listY = nY;
        m_mcList._y = m_listY;
    } // End of the function
    function setListX(nX)
    {
        m_listX = nX;
        m_mcList._x = m_listX;
    } // End of the function
    function getValue()
    {
        if (m_hasSelectedRow)
        {
            return (m_selectedRowId);
        } // end if
        return ("");
    } // End of the function
    function setValue(nRow)
    {
        this.selectRow(nRow);
    } // End of the function
    function setListId(sId)
    {
        m_needsPreSelection = true;
        m_listObject.setId(sId);
        this.flush();
    } // End of the function
    function getObject()
    {
        if (m_hasSelectedRow)
        {
            return (m_selectedRowObject);
        } // end if
    } // End of the function
    function getCells()
    {
        if (m_hasSelectedRow)
        {
            return (m_selectedRowCells);
        } // end if
    } // End of the function
    function selectRowFromId(sId)
    {
        var _loc3 = -1;
        for (var _loc2 = 1; _loc2 < m_lastList.length; ++_loc2)
        {
            if (m_lastList[_loc2][0].id == sId)
            {
                _loc3 = _loc2;
                break;
            } // end if
        } // end of for
        if (_loc3 > 0)
        {
            this.selectRow(_loc3);
            return (true);
        } // end if
        return (false);
    } // End of the function
    function flush(noCallback)
    {
        dice.bf2.Logic.setAsync(true);
        this.deSelectRows();
        if (noCallback)
        {
            m_needsPreSelection = false;
        }
        else
        {
            m_needsPreSelection = true;
        } // end else if
        m_listObject.flush();
        if (m_asyncList)
        {
            this.startUpdate();
        } // end if
        return (false);
    } // End of the function
    function setNewCallback()
    {
        m_listObject.setCallback(this, "fillList");
        if (m_inAuthorMode)
        {
            this.showAuthColLook(true);
        } // end if
    } // End of the function
    function getSelectedArrayFromRow(rowIndex)
    {
        return (m_listStartIndex + rowIndex);
    } // End of the function
    function getSelectedRow()
    {
        return (m_selectedListIndex - m_listStartIndex);
    } // End of the function
    function scrollRowSelection()
    {
        var _loc2 = 0;
        if (m_selectedRowClickIndex > 0)
        {
            this.deSelectRow(m_selectedRowClickIndex, true);
            m_selectedRowClickIndex = -1;
        } // end if
        if (m_scrollSelectedRow > 0)
        {
            this.deSelectRow(m_scrollSelectedRow);
        } // end if
        _loc2 = this.getSelectedRow();
        m_scrollSelectedRow = -1;
        if (m_hasSelectedRow && _loc2 > 0 && _loc2 <= m_listCount)
        {
            this.selectRow(_loc2, true);
            m_scrollSelectedRow = _loc2;
            m_scrollNeedsReselection = false;
        } // end if
    } // End of the function
    function scrollDownOneLine()
    {
        if (m_useInternalScroll && m_listStartIndex + m_listCount < m_listObject.getTotalCount())
        {
            m_lastListStartIndex = m_listStartIndex;
            ++m_listStartIndex;
            m_listObject.setStart(m_listStartIndex);
            scrollTainer.syncSliderToContent();
            this.scrollRowSelection();
        } // end if
    } // End of the function
    function scrollUpOneLine()
    {
        if (m_useInternalScroll && m_listStartIndex > 0)
        {
            m_lastListStartIndex = m_listStartIndex;
            --m_listStartIndex;
            m_listObject.setStart(m_listStartIndex);
            scrollTainer.syncSliderToContent();
            this.scrollRowSelection();
        } // end if
    } // End of the function
    function scrollTo(nX, nY)
    {
        m_listStartIndex = Math.round(nY / m_lineHeight);
        if (m_listStartIndex != m_lastListStartIndex)
        {
            m_listObject.setStart(m_listStartIndex);
            if (m_useInternalScroll)
            {
                var _loc2 = m_lineWidth;
                _loc2 = _loc2 - scrollTainer.m_scrollThickness;
                var _loc4 = m_listCount * m_lineHeight;
                var _loc3 = m_listObject.getTotalCount() * m_lineHeight;
                var scrollTainer = _parent._parent._parent;
                scrollTainer.setContentSize(_loc2, _loc3, 0);
            } // end if
            this.scrollRowSelection();
            m_listObject.update();
            m_lastListStartIndex = m_listStartIndex;
            if (m_inAuthorMode)
            {
                this.showAuthColLook(true);
            } // end if
        } // end if
    } // End of the function
    function updateManager()
    {
        if (m_asyncList)
        {
            m_updating = dice.bf2.Logic.getAsync();
        } // end if
        this.update();
        return (m_updating);
    } // End of the function
    function setPreselection(bool)
    {
        m_preselectionEnabled = bool;
    } // End of the function
    function getPreselection()
    {
        return (m_preselectionEnabled);
    } // End of the function
    var m_largeTextOffsetX = -2.500000E+000;
    var m_smallTextOffsetX = -2.500000E+000;
    var m_listIdMarkId = "";
    var m_listIdMarkColor = 65280;
    var m_selectedIndex = 0;
    var m_currentCellX = 0;
    var m_containerWidth = 0;
    var m_authorListLength = 0;
    var m_listY = 0;
    var m_listX = 0;
    var m_lineSliderTextYOffset = 0;
    var m_columnLineSliderColor = 11184810;
    var m_columnLineSliderColorSelected = 16777215;
    var m_columnLineSliderColorDisabled = 16733525;
    var m_columnLineSliderBGColor = 8947848;
    var m_columnLineSliderBGColorSelected = 14540253;
    var m_columnLineSliderBGColorDisabled = 16724787;
    var m_columnLineTextColor = dice.UI.prototype.m_UITriggerColorSelected;
    var m_columnLineTextColorSelected = dice.UI.prototype.m_UITriggerColorSelected;
    var m_columnLineTextColorWarning = 16729156;
    var m_columnLineTextColorDisabled = 12303291;
    var m_columnLineColorSelected = dice.UI.prototype.m_UITriggerColor;
    var m_columnLineColorDisabled = 16772846;
    var m_columnLineColorAlpha = 0;
    var m_columnLineColor = dice.UI.prototype.m_UITriggerColorSelected;
    var m_columnLineColorSelectedAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_columnLineColorDisabledAlpha = dice.UI.prototype.m_UIBevelAlpha;
    var m_columnLineDividerColor = 0;
    var m_columnLineDividerVerticalAlpha = 5;
    var m_columnLineDividerHorizontalAlpha = 0;
    var m_rowDividerVerticalYOffset = 0;
    var m_columnToUseTextFrom = 1;
    var m_nextFlushNoCallback = false;
    var m_listStartIndex = 0;
    var m_lastListStartIndex = -1;
    var m_oldListStartIndex = -1;
    var m_listCount = 3;
    var m_selectedRows = new Array();
    var m_scrollNeedsReselection = false;
    var m_scrollSelectedRow = -1;
    var m_fillListSelectedRow = -1;
    var m_hasSelectedRow = false;
    var m_closeParentContainerOnSelect = false;
    var m_selectedRowId = "";
    var m_selectedRowText = "";
    var m_selectedListIndex = -1;
    var m_selectedRowClickIndex = -1;
    var m_lastSelectedRowClickIndex = -2;
    var m_deSelectedRowIndex = -1;
    var m_oldStartIndex = -1;
    var m_needsPreSelection = true;
    var m_preselectionEnabled = true;
    var m_callbackEnabled = false;
} // End of Class
