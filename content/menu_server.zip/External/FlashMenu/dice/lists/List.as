class dice.lists.List
{
    var m_start, m_count, m_revision, m_filters, m_id, m_mc, m_funcName;
    function List(sId, nStart, nCount)
    {
        m_start = nStart;
        m_count = nCount;
        m_revision = 0;
        m_filters = new Array();
        this.setId(sId);
    } // End of the function
    function getTotalCount()
    {
        return (m_totalCount);
    } // End of the function
    function setCount(nCount)
    {
        if (nCount == m_count)
        {
            return;
        } // end if
        m_count = nCount;
        if (m_revision == -1 || dice.General.getListRevision(m_id) == -1)
        {
            this.flush();
        }
        else
        {
            m_revision = 0;
        } // end else if
    } // End of the function
    function getCount()
    {
        return (m_count);
    } // End of the function
    function setStart(nStart)
    {
        if (m_start == nStart)
        {
            return;
        } // end if
        m_start = nStart;
        if (m_revision == -1 || dice.General.getListRevision(m_id) == -1)
        {
            this.flush();
        }
        else
        {
            m_revision = 0;
        } // end else if
    } // End of the function
    function getStart()
    {
        return (m_start);
    } // End of the function
    function setId(id)
    {
        m_id = id;
    } // End of the function
    function setCallback(mc, funcName)
    {
        m_mc = mc;
        m_funcName = funcName;
    } // End of the function
    function setSortOrder(column, descending)
    {
        dice.General.setSortOrder(m_id, column, descending);
    } // End of the function
    function setFilter(id, str)
    {
        var _loc6 = "filter" + Number;
        for (var _loc4 in m_filters)
        {
            if (m_filters[_loc4].filterId == id)
            {
                m_filters[_loc4].filter = str;
                dice.General.setFilter(m_id, m_filters);
                return;
            } // end if
        } // end of for...in
        m_filters.push({filterId: id, filter: str});
        dice.General.setFilter(m_id, m_filters);
    } // End of the function
    function flush()
    {
        m_revision = dice.General.flushList(m_id);
        if (m_revision == -1)
        {
            var _loc2 = dice.General.getListEntries(m_id, m_start, m_count);
            if (_loc2)
            {
                m_totalCount = _loc2[0].totalCount;
                m_mc[m_funcName](_loc2);
            } // end if
        } // end if
    } // End of the function
    function update()
    {
        if (m_revision == -1)
        {
            return;
        } // end if
        var _loc3 = dice.General.getListRevision(m_id);
        if (m_revision != _loc3)
        {
            m_revision = _loc3;
            var _loc2 = dice.General.getListEntries(m_id, m_start, m_count);
            if (_loc2)
            {
                m_totalCount = _loc2[0].totalCount;
                m_mc[m_funcName](_loc2);
            } // end if
        } // end if
    } // End of the function
    var m_totalCount = 20;
} // End of Class
