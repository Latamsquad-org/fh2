class dice.MessageHandler
{
    function MessageHandler()
    {
    } // End of the function
    static function getPunkBusterMessage()
    {
        return ("punkbustermessage");
    } // End of the function
    static function enableMessageHandler(bValue)
    {
    } // End of the function
    static function raiseMessage(errorString, type, code)
    {
    } // End of the function
    static function getNumMessages()
    {
        return (0);
    } // End of the function
    static function getLastText()
    {
        return ("TestError long and difficult text, and you should be reading this carefully and nicely.");
    } // End of the function
    static function getLastType()
    {
        return (1);
    } // End of the function
    static function getLastCode()
    {
        return (0);
    } // End of the function
    static function removeLast()
    {
    } // End of the function
    static function clear()
    {
    } // End of the function
} // End of Class
