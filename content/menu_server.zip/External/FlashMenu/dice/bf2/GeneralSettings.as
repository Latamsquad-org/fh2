class dice.bf2.GeneralSettings
{
    function GeneralSettings()
    {
    } // End of the function
    static function removeServer(serverid)
    {
    } // End of the function
    static function cancel()
    {
    } // End of the function
    static function initValues()
    {
    } // End of the function
    static function setConnectionType(n)
    {
    } // End of the function
    static function getConnectionType()
    {
        return (4);
    } // End of the function
    static function getAutoReady()
    {
        return (true);
    } // End of the function
    static function setAutoReady(b)
    {
    } // End of the function
    static function setAutoReload(bool)
    {
    } // End of the function
    static function getAutoReload()
    {
        return (true);
    } // End of the function
    static function getAllowPunkBuster()
    {
        return (true);
    } // End of the function
    static function setAllowPunkBuster(bool)
    {
    } // End of the function
    static function apply()
    {
    } // End of the function
    static function setItemSelectionReverseItems(v)
    {
    } // End of the function
    static function getItemSelectionReverseItems()
    {
        return (true);
    } // End of the function
    static function setVOArmyLanguage(v)
    {
    } // End of the function
    static function getVOArmyLanguage()
    {
        return (true);
    } // End of the function
    static function setSortKey(v)
    {
    } // End of the function
    static function getSortKey()
    {
        return ("sortKey");
    } // End of the function
    static function setSortOrder(v)
    {
    } // End of the function
    static function getSortOrder()
    {
        return (0);
    } // End of the function
    static function setNumRoundsPlayed(v)
    {
    } // End of the function
    static function getNumRoundsPlayed()
    {
        return (0);
    } // End of the function
    static function setServerFilter(v)
    {
    } // End of the function
    static function getServerFilter()
    {
        return ("sortKey");
    } // End of the function
    static function setHUDTransparency(v)
    {
    } // End of the function
    static function getHUDTransparency()
    {
        return (100);
    } // End of the function
    static function setCrosshairColor(r, g, b)
    {
    } // End of the function
    static function getCrosshairColor()
    {
        return (0);
    } // End of the function
    static function setBuddytagColor(r, g, b)
    {
    } // End of the function
    static function getBuddytagColor()
    {
        return (0);
    } // End of the function
    static function setSquadtagColor(r, g, b)
    {
    } // End of the function
    static function getSquadtagColor()
    {
        return (0);
    } // End of the function
    static function setMinimapRotate(v)
    {
    } // End of the function
    static function getMinimapRotate()
    {
        return (true);
    } // End of the function
    static function setMinimapTransparency(v)
    {
    } // End of the function
    static function getMinimapTransparency()
    {
        return (4.000000E-001);
    } // End of the function
    static function setMapIconTransparency(v)
    {
    } // End of the function
    static function getMapIconTransparency()
    {
        return (4.000000E-001);
    } // End of the function
    static function setViewIntroMovie(v)
    {
    } // End of the function
    static function getViewIntroMovie()
    {
        return (true);
    } // End of the function
    static function setOutOfVoting(v)
    {
    } // End of the function
    static function getOutOfVoting()
    {
        return (true);
    } // End of the function
    static function setBFTVSaveDirectory(v)
    {
    } // End of the function
    static function getBFTVSaveDirectory()
    {
        return ("sortKey");
    } // End of the function
    static function setPlayedVOHelp(v)
    {
    } // End of the function
    static function checkPlayedVOHelp()
    {
        return (false);
    } // End of the function
    static function setConfirmQuit(v)
    {
    } // End of the function
    static function getConfirmQuit()
    {
        return (false);
    } // End of the function
    static function setUseBots(bool)
    {
    } // End of the function
    static function getUseBots()
    {
        return (true);
    } // End of the function
    static function setMaxBots(num)
    {
    } // End of the function
    static function getMaxBots()
    {
        return (1);
    } // End of the function
    static function setMaxBotsIncludeHumans(bool)
    {
    } // End of the function
    static function getMaxBotsIncludeHumans()
    {
        return (true);
    } // End of the function
    static function setBotSkill(num)
    {
    } // End of the function
    static function getBotSkill()
    {
        return (3.000000E-001);
    } // End of the function
} // End of Class
