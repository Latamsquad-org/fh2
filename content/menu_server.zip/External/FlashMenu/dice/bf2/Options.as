class dice.bf2.Options
{
    function Options()
    {
    } // End of the function
} // End of Class
