class dice.bf2.Locale
{
    function Locale()
    {
    } // End of the function
    static function getString(stringId)
    {
        return ("stringId");
    } // End of the function
    static function getLanguage()
    {
        return ("Swedish");
    } // End of the function
} // End of Class
