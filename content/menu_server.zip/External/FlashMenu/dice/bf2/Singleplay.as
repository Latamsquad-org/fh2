class dice.bf2.Singleplay
{
    function Singleplay()
    {
    } // End of the function
    static function chooseMission(mapId)
    {
    } // End of the function
    static function getBotSkills()
    {
        return (1);
    } // End of the function
    static function setBotSkills(skill)
    {
    } // End of the function
} // End of Class
