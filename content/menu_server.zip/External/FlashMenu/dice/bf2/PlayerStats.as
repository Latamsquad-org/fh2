class dice.bf2.PlayerStats
{
    function PlayerStats()
    {
    } // End of the function
    static function getLeaderboardDate()
    {
        return ("2005-04-04 22:30");
    } // End of the function
    static function getNumPlayersInLeaderboard()
    {
        return (100);
    } // End of the function
    static function getPromotedRank()
    {
        return (1);
    } // End of the function
    static function getNextPromotionRank(n)
    {
        return (2);
    } // End of the function
    static function getDemotedRank()
    {
        return (1);
    } // End of the function
    static function getNextDemomotionRank(n)
    {
        return (2);
    } // End of the function
    static function getOpponentName()
    {
        return ("name1");
    } // End of the function
    static function getOpponentRankId()
    {
        return (2);
    } // End of the function
    static function getVictimName()
    {
        return ("name2");
    } // End of the function
    static function getVictimRankId()
    {
        return (3);
    } // End of the function
    static function getFavouriteName(n)
    {
        return ("name");
    } // End of the function
    static function getFavouriteId(n)
    {
        return ("1");
    } // End of the function
    static function getFavouriteTime(n)
    {
        return ("time");
    } // End of the function
    static function getRoadKills()
    {
        return (23);
    } // End of the function
    static function getKitAccuracy()
    {
        return (45);
    } // End of the function
    static function getNextRankLevel()
    {
        return (1);
    } // End of the function
    static function getPreviousRankLevel()
    {
        return (1);
    } // End of the function
    static function getRankString(n)
    {
        return ("Rankname localized");
    } // End of the function
    static function clearRankNotification()
    {
    } // End of the function
    static function getRankNotification()
    {
        return (0);
    } // End of the function
    static function getRankNotificationLevel()
    {
        return (1);
    } // End of the function
    static function getNumUnlockableItems()
    {
        return (0);
    } // End of the function
    static function selectFirstUnlock()
    {
    } // End of the function
    static function selectUnlock(id)
    {
    } // End of the function
    static function getCurrentUnlockDescription()
    {
        return ("description localized");
    } // End of the function
    static function unlock(id)
    {
    } // End of the function
    static function refreshStats(profileId)
    {
        return (true);
    } // End of the function
    static function getStats(profileId)
    {
        return (true);
    } // End of the function
} // End of Class
