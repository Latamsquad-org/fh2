class dice.bf2.EndOfRound
{
    function EndOfRound()
    {
    } // End of the function
    static function hasMap()
    {
        return (true);
    } // End of the function
    static function getTeamNameOfPlayerAtPosition(n)
    {
        return ("US");
    } // End of the function
    static function getSquadTeamName(n)
    {
        return ("aa");
    } // End of the function
    static function getKitNameFromId(n)
    {
        return ("assault");
    } // End of the function
    static function getPreviousMapPath()
    {
        return ("PREV path");
    } // End of the function
    static function getPreviousMapName()
    {
        return ("PREV Mapname");
    } // End of the function
    static function getPreviousMapDescription()
    {
        return ("PREV Map desc localized");
    } // End of the function
    static function getPreviousMapGameMode()
    {
        return ("PREV gpm_cq");
    } // End of the function
    static function getPreviousMapGameModeDescription()
    {
        return ("PREV Gamemode description localized");
    } // End of the function
    static function getPreviousMapGameModeName()
    {
        return ("PREV Conquest");
    } // End of the function
    static function getPreviousMapSize()
    {
        return (16);
    } // End of the function
    static function getPreviousMapMaxPlayers()
    {
        return (16);
    } // End of the function
    static function getMapPath()
    {
        return ("path");
    } // End of the function
    static function getMapName()
    {
        return ("Mapname");
    } // End of the function
    static function getMapDescription()
    {
        return ("Map desc localized");
    } // End of the function
    static function getMapGameMode()
    {
        return ("gpm_cq");
    } // End of the function
    static function getMapGameModeDescription()
    {
        return ("Gamemode description localized");
    } // End of the function
    static function getMapGameModeName()
    {
        return ("Conquest");
    } // End of the function
    static function getMapSize()
    {
        return (16);
    } // End of the function
    static function getMapMaxPlayers()
    {
        return (16);
    } // End of the function
    static function getTeamName(team)
    {
        return ("US");
    } // End of the function
    static function getPreviousTeamName(team)
    {
        return ("CH");
    } // End of the function
    static function getNumVictories(team)
    {
        return (666);
    } // End of the function
    static function getWinningTeam()
    {
        return (1);
    } // End of the function
    static function getTicketHistorySum(nValue)
    {
        return (245);
    } // End of the function
    static function getMyTeam()
    {
        return (1);
    } // End of the function
} // End of Class
