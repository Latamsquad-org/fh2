class dice.bf2.ControlSettings
{
    function ControlSettings()
    {
    } // End of the function
    static function resetDefault()
    {
    } // End of the function
    static function setActiveControlMap(controlMap)
    {
    } // End of the function
    static function getActiveControlMap()
    {
        return ("0");
    } // End of the function
    static function mapInput(playerInput, secondary, negative, isCommon)
    {
        return (true);
    } // End of the function
    static function getMappedString(playerInput, secondary, negative)
    {
        return ("mappedKey");
    } // End of the function
    static function apply()
    {
    } // End of the function
    static function cancel()
    {
    } // End of the function
    static function reset()
    {
    } // End of the function
    static function getMouseSensitivity()
    {
        return (0);
    } // End of the function
    static function setMouseSensitivity(n)
    {
    } // End of the function
    static function getMouseSensitivityMultiplier()
    {
        return (0);
    } // End of the function
    static function setMouseSensitivityMultiplier(n)
    {
    } // End of the function
    static function getMouseSmoothing()
    {
        return (0);
    } // End of the function
    static function setMouseSmoothing(n)
    {
    } // End of the function
    static function getMouseYAWFactor()
    {
        return (0);
    } // End of the function
    static function setMouseYAWFactor(n)
    {
    } // End of the function
    static function getMousePITCHFactor()
    {
        return (0);
    } // End of the function
    static function setMousePITCHFactor(n)
    {
    } // End of the function
    static function getInvertMouse()
    {
        return (false);
    } // End of the function
    static function setInvertMouse(n)
    {
    } // End of the function
    static function getKeyboardSensitivity()
    {
        return (0);
    } // End of the function
    static function setKeyboardSensitivity(n)
    {
    } // End of the function
} // End of Class
