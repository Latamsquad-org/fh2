class dice.bf2.Profile
{
    function Profile()
    {
    } // End of the function
    static function setNamePrefix(s)
    {
    } // End of the function
    static function getNamePrefix()
    {
        return ("testy");
    } // End of the function
    static function getNumOnlineProfiles()
    {
        return (2);
    } // End of the function
    static function getNumOfflineProfiles()
    {
        return (2);
    } // End of the function
    static function getRankProgress()
    {
        return (4.000000E-001);
    } // End of the function
    static function getNumLocalProfiles()
    {
        return (0);
    } // End of the function
    static function getNumTimesLoggedIn()
    {
        return (2);
    } // End of the function
    static function getFirstCountry()
    {
        return ("Andorra");
    } // End of the function
    static function loginOnlineAccountWithNick(nick, password)
    {
        return (true);
    } // End of the function
    static function deleteCurrentProfile()
    {
        return (true);
    } // End of the function
    static function newGamespyProfile(sNick)
    {
        return (false);
    } // End of the function
    static function hasAward()
    {
        return (true);
    } // End of the function
    static function selectLatestAward(sId)
    {
        return (true);
    } // End of the function
    static function selectAward(sId)
    {
        return (false);
    } // End of the function
    static function getAwardName()
    {
        return ("Name");
    } // End of the function
    static function getAwardLevel()
    {
        return (2);
    } // End of the function
    static function hasThisAward(s)
    {
        return (false);
    } // End of the function
    static function getAwardLatestDate()
    {
        return ("2005-02-01 22:20");
    } // End of the function
    static function getAwardFirstDate()
    {
        return ("2005-01-01 22:20");
    } // End of the function
    static function getAwardDescription()
    {
        return ("Long text about the award and it\'s long forgotten past.");
    } // End of the function
    static function getSprint(teamId, kitId)
    {
        return (3.000000E-001);
    } // End of the function
    static function setSelectedUnlockEquipment(equipmentId)
    {
    } // End of the function
    static function setSelectedEquipment(equipmentId)
    {
    } // End of the function
    static function getEquipmentName(equipmentId)
    {
        return ("weaponname!");
    } // End of the function
    static function getEquipmentDescription(equipmentId)
    {
        return ("description");
    } // End of the function
    static function deleteLocalProfile(sId)
    {
    } // End of the function
    static function createOfflineAccount(sProfileName, sNickname)
    {
        return (true);
    } // End of the function
    static function loginOfflineAccount(nId)
    {
        return (true);
    } // End of the function
    static function createOnlineAccount(sNickname, sEmail, sPassword, sConfirmPassword, bRememberPassword, sFirstName, sLastName, nBirthYear, nBirthMonth, nBirthDay, sCountry, nGender)
    {
        return (true);
    } // End of the function
    static function loginOnlineAccount(nId, sPassword, bRememberPassword)
    {
        return (true);
    } // End of the function
    static function loginOnlineAccountWithEmail(sEmail, sPassword, bRememberPassword)
    {
        return (true);
    } // End of the function
    static function getLoginStatus()
    {
        return (0);
    } // End of the function
    static function logout()
    {
    } // End of the function
    static function searchUniquePlayer(sNick)
    {
        return (-1);
    } // End of the function
    static function searchPlayer(sNick)
    {
        return (true);
    } // End of the function
    static function setComparePlayer(nId, sNick)
    {
    } // End of the function
    static function clearComparePlayer()
    {
    } // End of the function
    static function setStatPlayer(nId)
    {
        trace ("SETTING STAT TO: " + nId);
    } // End of the function
    static function getStatPlayerName()
    {
        return ("nickname");
    } // End of the function
    static function getStatPlayer()
    {
        return (1);
    } // End of the function
    static function setActivePlayer(sNick)
    {
    } // End of the function
    static function getActivePlayer()
    {
        return ("nickname");
    } // End of the function
    static function isMyProfile(nId)
    {
        return (true);
    } // End of the function
    static function setUseAdvancedServerBrowser(bool)
    {
    } // End of the function
    static function getUseAdvancedServerBrowser()
    {
        return (true);
    } // End of the function
    static function getCurrentRankString()
    {
        return ("major");
    } // End of the function
    static function getNextRankString()
    {
        return ("sergant major");
    } // End of the function
    static function getCurrentRankId()
    {
        return (0);
    } // End of the function
    static function getNumRanks()
    {
        return (11);
    } // End of the function
} // End of Class
