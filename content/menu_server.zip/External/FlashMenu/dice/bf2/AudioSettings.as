class dice.bf2.AudioSettings
{
    function AudioSettings()
    {
    } // End of the function
    static function getEnableEAX()
    {
        return (true);
    } // End of the function
    static function setEnableEAX(b)
    {
    } // End of the function
    static function isInCriticalState()
    {
        return (true);
    } // End of the function
    static function apply()
    {
        return (true);
    } // End of the function
    static function applyVolume()
    {
        return (true);
    } // End of the function
    static function cancel()
    {
    } // End of the function
    static function reset()
    {
    } // End of the function
    static function canApply()
    {
        return (true);
    } // End of the function
    static function hasEax()
    {
        return (true);
    } // End of the function
    static function hasZenithBoard()
    {
        return (true);
    } // End of the function
    static function getVoipEnabled()
    {
        return (true);
    } // End of the function
    static function setVoipEnabled(enable)
    {
    } // End of the function
    static function getVoipPlaybackVolume()
    {
        return (0);
    } // End of the function
    static function setVoipPlaybackVolume(value)
    {
    } // End of the function
    static function getVoipCaptureVolume()
    {
        return (0);
    } // End of the function
    static function setVoipCaptureVolume(value)
    {
    } // End of the function
    static function getVoipCaptureThreshold()
    {
        return (0);
    } // End of the function
    static function setVoipCaptureThreshold(value)
    {
    } // End of the function
    static function getVoipBoostEnabled()
    {
        return (true);
    } // End of the function
    static function setVoipBoostEnabled(enable)
    {
    } // End of the function
    static function getProvider()
    {
        return ("0");
    } // End of the function
    static function getSelectedProvider()
    {
        return ("selectedprovider");
    } // End of the function
    static function setProvider(value)
    {
    } // End of the function
    static function getMasterVolume()
    {
        return (3.000000E-001);
    } // End of the function
    static function setMasterVolume(value)
    {
    } // End of the function
    static function getMusicVolume()
    {
        return (4.000000E-001);
    } // End of the function
    static function setMusicVolume(value)
    {
    } // End of the function
    static function getEffectsVolume()
    {
        return (4.000000E-001);
    } // End of the function
    static function setEffectsVolume(value)
    {
    } // End of the function
    static function getSoundQuality()
    {
        return (4.000000E-001);
    } // End of the function
    static function getSelectedSoundQuality()
    {
        return ("selectedsoundquality");
    } // End of the function
    static function setSoundQuality(value)
    {
    } // End of the function
    static function getSoundDetail()
    {
        return (4.000000E-001);
    } // End of the function
    static function getSelectedSoundDetail()
    {
        return ("sounddetail");
    } // End of the function
    static function setSoundDetail(value)
    {
    } // End of the function
    static function getNumberOfVoices()
    {
        return (0);
    } // End of the function
    static function getSelectedNumVoices()
    {
        return ("2");
    } // End of the function
    static function setNumberOfVoices(value)
    {
    } // End of the function
    static function getChannels()
    {
        return (0);
    } // End of the function
    static function setChannels(value)
    {
    } // End of the function
    static function getEnglishOnlyVoices()
    {
        return (true);
    } // End of the function
    static function setEnglishOnlyVoices(value)
    {
    } // End of the function
    static function getVoiceOverVolume()
    {
        return (1);
    } // End of the function
    static function setVoiceOverVolume(v)
    {
    } // End of the function
} // End of Class
