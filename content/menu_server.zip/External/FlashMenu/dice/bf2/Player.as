class dice.bf2.Player
{
    function Player()
    {
    } // End of the function
} // End of Class
