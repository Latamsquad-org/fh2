class dice.bf2.Clans
{
    function Clans()
    {
    } // End of the function
} // End of Class
