class dice.bf2.Client
{
    function Client()
    {
    } // End of the function
    static function getPlayerName(sDefault)
    {
        return ("String from Client.as flash version");
    } // End of the function
    static function setPlayerName(s)
    {
        trace ("s: " + s);
    } // End of the function
    static function getCommandlineOption()
    {
        return ("String from Client.as flash version");
    } // End of the function
    static function setCommandlineOption(sValue)
    {
        trace ("sValue: " + sValue);
    } // End of the function
    static function getLoadProgress()
    {
        return (2.000000E-001);
    } // End of the function
    static function getEORType()
    {
        return (0);
    } // End of the function
    static function getTimeUntilRestart()
    {
        return (15);
    } // End of the function
    static function getTotalTimeUntilRestart()
    {
        return (45);
    } // End of the function
    static function getCurrentLoadFile()
    {
        return ("currentFile");
    } // End of the function
    static function hasUserEscapedFromGame()
    {
        return (false);
    } // End of the function
} // End of Class
