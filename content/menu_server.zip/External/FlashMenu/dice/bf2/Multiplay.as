class dice.bf2.Multiplay
{
    function Multiplay()
    {
    } // End of the function
    static function setHighestPing(n)
    {
    } // End of the function
    static function refreshBrowser()
    {
    } // End of the function
    static function stopBrowser()
    {
    } // End of the function
    static function isBrowsing()
    {
        return (false);
    } // End of the function
    static function hasDemoDownloadFailed()
    {
        return (true);
    } // End of the function
    static function getSelectedFilterGameModeId()
    {
        return ("spa");
    } // End of the function
    static function getScrollFadeSpeed()
    {
        return (200);
    } // End of the function
    static function getConnectToIpPort()
    {
        return (29999);
    } // End of the function
    static function setConnectToIpPort(n)
    {
    } // End of the function
    static function getConnectToIpHost()
    {
        return ("10.0.0.2");
    } // End of the function
    static function setConnectToIpHost(s)
    {
    } // End of the function
    static function getLeaderboardName()
    {
        return ("dummystring");
    } // End of the function
    static function getMapPathFromName(s)
    {
        return ("kalle");
    } // End of the function
    static function getSelectedServerFilterGameMode()
    {
        return ("gamemodeserver");
    } // End of the function
    static function startBrowse()
    {
    } // End of the function
    static function getTeamName(n)
    {
        return ("string");
    } // End of the function
    static function browse(s)
    {
    } // End of the function
    static function setJoinPassword(s)
    {
    } // End of the function
    static function updateFilter()
    {
    } // End of the function
    static function setToggleFilter(n, n2)
    {
    } // End of the function
    static function getToggleFilter(n)
    {
        return (true);
    } // End of the function
    static function getSponsorText()
    {
        return ("sponsortext localized");
    } // End of the function
    static function getSponsorLogoUrl()
    {
        return ("logo pic string");
    } // End of the function
    static function getCurrentMapName()
    {
        return ("zatar_wetlands");
    } // End of the function
    static function getCurrentMapGameMode()
    {
        return ("Conquest");
    } // End of the function
    static function getCurrentMapMaxPlayers()
    {
        return (45);
    } // End of the function
    static function getCurrentMapSize()
    {
        return (16);
    } // End of the function
    static function getHasNewBookmark()
    {
        return (true);
    } // End of the function
    static function setHasNewBookmark(bValue)
    {
    } // End of the function
    static function playNow()
    {
    } // End of the function
    static function isGameSpyAvailable()
    {
        return (true);
    } // End of the function
    static function setCurrentMap(mapIndex)
    {
    } // End of the function
    static function setMapList(maplist)
    {
    } // End of the function
    static function clearMapList()
    {
    } // End of the function
    static function joinServer(address)
    {
    } // End of the function
    static function updateServer(address)
    {
    } // End of the function
    static function createServer(mapName)
    {
    } // End of the function
    static function setCurrentServerId(id)
    {
    } // End of the function
    static function clearServerId()
    {
    } // End of the function
    static function addFavouriteServer(address)
    {
        return (true);
    } // End of the function
    static function removeFavouriteServer(address)
    {
        return (true);
    } // End of the function
    static function isServerOnline(address)
    {
        return (true);
    } // End of the function
    static function getMapName(id)
    {
        return ("songua_stalemate");
    } // End of the function
    static function addMapToMapList(id, gameMode, mapSize)
    {
        return (true);
    } // End of the function
    static function removeMapfromMapList(id)
    {
        return (true);
    } // End of the function
    static function moveMapInList(id, up)
    {
        return (true);
    } // End of the function
    static function setBrowser(sBrowserId)
    {
    } // End of the function
    static function getBrowser()
    {
        return ("internet");
    } // End of the function
    static function setFilter(sFilter)
    {
    } // End of the function
    static function sort(key, ascending, compareMode)
    {
    } // End of the function
    static function downloadDemo(sId)
    {
    } // End of the function
    static function stopDownloadDemo()
    {
    } // End of the function
    static function getDownloadingHostname()
    {
        return ("hostname");
    } // End of the function
    static function getDownloadingUrl()
    {
        return ("url");
    } // End of the function
    static function getDownloadingDate()
    {
        return ("2005-01-02");
    } // End of the function
    static function getDownloadingProgress()
    {
        return (5.000000E-001);
    } // End of the function
    static function deleteDemoBookmark(sId)
    {
    } // End of the function
    static function isDownloadingDemo()
    {
        return (false);
    } // End of the function
    static function getNumDemoBookmarks()
    {
        return (0);
    } // End of the function
    static function getNumServers()
    {
        return (123456);
    } // End of the function
    static function playDemo(sId)
    {
    } // End of the function
    static function deleteDemo(sId)
    {
        return (true);
    } // End of the function
    static function setLeaderboardCategoryId(n)
    {
    } // End of the function
    static function getSelectedLeaderboardCategoryId()
    {
        return ("Scores");
    } // End of the function
    static function getLeaderboardCategoryId()
    {
        return (2);
    } // End of the function
    static function setLeaderboardId(n)
    {
    } // End of the function
    static function getLeaderboardId()
    {
        return (-1);
    } // End of the function
    static function goFirstLeaderboard()
    {
    } // End of the function
    static function goLastLeaderboard()
    {
    } // End of the function
    static function goNextLeaderboard()
    {
    } // End of the function
    static function goPreviousLeaderboard()
    {
    } // End of the function
    static function goLeaderboardPlayer(nId)
    {
    } // End of the function
    static function getLeaderboardDescription()
    {
        return ("Leaderboarddesc");
    } // End of the function
    static function setFilterGameMode(s)
    {
    } // End of the function
    static function getFilterGameMode()
    {
        return ("gpm_cq");
    } // End of the function
    static function getSelectedFilterGameMode()
    {
        return ("Conquest");
    } // End of the function
    static function getMapNameFromId(s)
    {
        return ("Mapname");
    } // End of the function
    static function getMapNameFromIdLocalized(s)
    {
        return ("Mapname localized");
    } // End of the function
    static function getMapDescriptionFromId()
    {
        return ("DEscription");
    } // End of the function
    static function getGameModeFromId()
    {
        return ("Conquest");
    } // End of the function
    static function clearHistory()
    {
    } // End of the function
    static function addHistoryToFavourites(sId)
    {
    } // End of the function
    static function addFavourite(hostname, ip, port)
    {
        return (true);
    } // End of the function
    static function removeFavourite(sId)
    {
    } // End of the function
} // End of Class
