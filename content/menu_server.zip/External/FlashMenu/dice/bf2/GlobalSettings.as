class dice.bf2.GlobalSettings
{
    function GlobalSettings()
    {
    } // End of the function
} // End of Class
