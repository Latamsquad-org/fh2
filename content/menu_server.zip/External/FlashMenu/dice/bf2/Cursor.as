class dice.bf2.Cursor
{
    function Cursor()
    {
    } // End of the function
    static function setCursor(cursorId)
    {
    } // End of the function
    static function getCursor()
    {
        return ("default");
    } // End of the function
    static function enableCursor(enable)
    {
    } // End of the function
} // End of Class
