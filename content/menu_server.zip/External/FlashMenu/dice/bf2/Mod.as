class dice.bf2.Mod
{
    function Mod()
    {
    } // End of the function
    static function getCurrentModName()
    {
        return ("");
    } // End of the function
    static function selectMod(sId)
    {
    } // End of the function
    static function getModLogo()
    {
        return ("mod.png");
    } // End of the function
    static function getModTitle()
    {
        return ("title");
    } // End of the function
    static function getModDesc()
    {
        return ("Description of mod");
    } // End of the function
    static function getModPath()
    {
        return ("mods/bf2");
    } // End of the function
    static function getModUrl()
    {
        return ("http://www.apa.com");
    } // End of the function
    static function getModVersion()
    {
        return ("1.0");
    } // End of the function
    static function getModPathShort()
    {
        return ("bf2");
    } // End of the function
    static function activateMod()
    {
    } // End of the function
    static function browseHomepage()
    {
    } // End of the function
} // End of Class
