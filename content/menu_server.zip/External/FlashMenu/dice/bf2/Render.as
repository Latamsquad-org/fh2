class dice.bf2.Render
{
    function Render()
    {
    } // End of the function
} // End of Class
