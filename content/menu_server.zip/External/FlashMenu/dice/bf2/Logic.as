class dice.bf2.Logic
{
    function Logic()
    {
    } // End of the function
    static function getTeamsConId(n)
    {
        return ("0");
    } // End of the function
    static function setAsync(bo)
    {
    } // End of the function
    static function getAsync()
    {
        return (true);
    } // End of the function
    static function takeMemorySnapshot()
    {
    } // End of the function
    static function dumpMemoryStats()
    {
    } // End of the function
    static function isLoadingDemo()
    {
        return (false);
    } // End of the function
    static function getNumRoundsLeft()
    {
        return (0);
    } // End of the function
    static function cacheCredits()
    {
    } // End of the function
    static function getRandomCreditsTexture()
    {
        return ("image");
    } // End of the function
    static function enableScroller(b)
    {
    } // End of the function
    static function isAbortLoadLevel()
    {
        return (false);
    } // End of the function
    static function isCapsLockPressed()
    {
        return (true);
    } // End of the function
    static function getModVersion()
    {
        return ("version");
    } // End of the function
    static function setDecimals(n, decimals)
    {
        return (n);
    } // End of the function
    static function joinCommandlineServer()
    {
    } // End of the function
    static function startCommandlineServer()
    {
    } // End of the function
    static function isFirstTimeLoading()
    {
        return (false);
    } // End of the function
    static function readyToPlay()
    {
    } // End of the function
    static function getIsLoading()
    {
        return (true);
    } // End of the function
    static function setIsLoading(bLoading)
    {
    } // End of the function
    static function getStorageString(sId, sDefault)
    {
        return ("true");
    } // End of the function
    static function setStorageString(sId, sValue)
    {
    } // End of the function
    static function eraseStorageString(sId)
    {
    } // End of the function
    static function quit()
    {
    } // End of the function
    static function disconnectGame()
    {
    } // End of the function
    static function isGameRunning()
    {
        return (false);
    } // End of the function
    static function active()
    {
        return (false);
    } // End of the function
    static function assert()
    {
    } // End of the function
    static function getCommandline()
    {
        return (0);
    } // End of the function
    static function getActivateReason()
    {
        return (0);
    } // End of the function
    static function setActivateReason(reason)
    {
    } // End of the function
    static function getFrameLabel()
    {
        return ("frameLabel");
    } // End of the function
    static function setFrameLabel(label)
    {
    } // End of the function
    static function getDefaultLevel()
    {
        return ("default");
    } // End of the function
} // End of Class
