class dice.bf2.ServerSettings
{
    function ServerSettings()
    {
    } // End of the function
    static function apply()
    {
    } // End of the function
    static function setFriendlyFire(bool)
    {
    } // End of the function
    static function getFriendlyFire()
    {
        return (true);
    } // End of the function
    static function setSvPunkBuster(bool)
    {
    } // End of the function
    static function getSvPunkBuster()
    {
        return (true);
    } // End of the function
    static function getServerName()
    {
        return ("serverName");
    } // End of the function
    static function setServerName(name)
    {
    } // End of the function
    static function getPassword()
    {
        return ("password");
    } // End of the function
    static function setPassword(pwd)
    {
    } // End of the function
    static function getInternet()
    {
        return (false);
    } // End of the function
    static function setInternet(x)
    {
    } // End of the function
    static function getBandwidthChoke()
    {
        return (0);
    } // End of the function
    static function setBandwidthChoke(x)
    {
    } // End of the function
    static function getMaxPlayers()
    {
        return (32);
    } // End of the function
    static function setMaxPlayers(x)
    {
    } // End of the function
    static function getGameMode()
    {
        return ("gameMode");
    } // End of the function
    static function setGameMode(pwd)
    {
    } // End of the function
    static function getStartDelay()
    {
        return (32);
    } // End of the function
    static function setStartDelay(x)
    {
    } // End of the function
    static function getEndDelay()
    {
        return (32);
    } // End of the function
    static function setEndDelay(x)
    {
    } // End of the function
    static function getSpawnTime()
    {
        return (32);
    } // End of the function
    static function setSpawnTime(x)
    {
    } // End of the function
    static function getManDownTime()
    {
        return (32);
    } // End of the function
    static function setManDownTime(x)
    {
    } // End of the function
    static function getTicketRatio()
    {
        return (32);
    } // End of the function
    static function setTicketRatio(x)
    {
    } // End of the function
    static function getCoopBotRatio()
    {
        return (32);
    } // End of the function
    static function setCoopBotRatio(x)
    {
    } // End of the function
    static function getCoopBotCount()
    {
        return (32);
    } // End of the function
    static function setCoopBotCount(x)
    {
    } // End of the function
    static function getCoopBotDiff()
    {
        return (32);
    } // End of the function
    static function setCoopBotDiff(x)
    {
    } // End of the function
    static function getRoundsPerMap()
    {
        return (32);
    } // End of the function
    static function setRoundsPerMap(x)
    {
    } // End of the function
    static function getTimeLimit()
    {
        return (32);
    } // End of the function
    static function setTimeLimit(x)
    {
    } // End of the function
    static function getScoreLimit()
    {
        return (32);
    } // End of the function
    static function setScoreLimit(x)
    {
    } // End of the function
    static function getSoldierFF()
    {
        return (32);
    } // End of the function
    static function setSoldierFF(x)
    {
    } // End of the function
    static function getVehicleFF()
    {
        return (32);
    } // End of the function
    static function setVehicleFF(x)
    {
    } // End of the function
    static function getSoldierSplashFF()
    {
        return (32);
    } // End of the function
    static function setSoldierSplashFF(x)
    {
    } // End of the function
    static function getVehicleSplashFF()
    {
        return (32);
    } // End of the function
    static function setVehicleSplashFF(x)
    {
    } // End of the function
    static function getPunishTeamKills()
    {
        return (false);
    } // End of the function
    static function setPunishTeamKills(x)
    {
    } // End of the function
    static function getVoteTime()
    {
        return (32);
    } // End of the function
    static function setVoteTime(x)
    {
    } // End of the function
    static function getMinPlayersForVoting()
    {
        return (32);
    } // End of the function
    static function setMinPlayersForVoting(x)
    {
    } // End of the function
    static function getVoipEnabled()
    {
        return (true);
    } // End of the function
    static function setVoipEnabled(x)
    {
    } // End of the function
    static function getVoipQuality()
    {
        return (3);
    } // End of the function
    static function setVoipQuality(x)
    {
    } // End of the function
    static function getVoipServerRemote()
    {
        return (false);
    } // End of the function
    static function setVoipServerRemote(x)
    {
    } // End of the function
    static function getVoipServerRemoteIP()
    {
        return ("127.0.0.1");
    } // End of the function
    static function setVoipServerRemoteIP(pwd)
    {
    } // End of the function
    static function getVoipServerPort()
    {
        return (55124);
    } // End of the function
    static function setVoipServerPort(x)
    {
    } // End of the function
    static function getVoipBFClientPort()
    {
        return (55123);
    } // End of the function
    static function setVoipBFClientPort(x)
    {
    } // End of the function
    static function getGameSpyPort()
    {
        return (32);
    } // End of the function
    static function setGameSpyPort(x)
    {
    } // End of the function
    static function getAllowNATNegotation()
    {
        return (false);
    } // End of the function
    static function setAllowNATNegotation(x)
    {
    } // End of the function
    static function getInterfaceIP()
    {
        return ("127.0.0.1");
    } // End of the function
    static function setInterfaceIP(pwd)
    {
    } // End of the function
    static function getAutoRecord()
    {
        return (false);
    } // End of the function
    static function setAutoRecord(x)
    {
    } // End of the function
    static function getDemoIndexURL()
    {
        return ("127.0.0.1");
    } // End of the function
    static function setDemoIndexURL(pwd)
    {
    } // End of the function
    static function getDemoDownloadURL()
    {
        return ("127.0.0.1");
    } // End of the function
    static function setDemoDownloadURL(pwd)
    {
    } // End of the function
    static function getDemoHook()
    {
        return ("127.0.0.1");
    } // End of the function
    static function setDemoHook(pwd)
    {
    } // End of the function
    static function getAdminScript()
    {
        return ("127.0.0.1");
    } // End of the function
    static function setAdminScript(pwd)
    {
    } // End of the function
    static function getTimeBeforeRestartMap()
    {
        return (32);
    } // End of the function
    static function setTimeBeforeRestartMap(x)
    {
    } // End of the function
    static function getSponsorText()
    {
        return ("127.0.0.1");
    } // End of the function
    static function setSponsorText(pwd)
    {
    } // End of the function
    static function getSponsorLogoURL()
    {
        return ("127.0.0.1");
    } // End of the function
    static function setSponsorLogoURL(pwd)
    {
    } // End of the function
    static function getAutoBalanceTeam()
    {
        return (false);
    } // End of the function
    static function setAutoBalanceTeam(b)
    {
    } // End of the function
    static function getAutoRecordRounds()
    {
        return (5);
    } // End of the function
    static function setAutoRecordRounds(b)
    {
    } // End of the function
    static function getTeamRatio()
    {
        return (1);
    } // End of the function
    static function setTeamRatio(b)
    {
    } // End of the function
    static function getNoVehicles()
    {
        return (false);
    } // End of the function
    static function setNoVehicles(b)
    {
    } // End of the function
} // End of Class
