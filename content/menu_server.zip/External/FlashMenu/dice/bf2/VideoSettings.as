class dice.bf2.VideoSettings
{
    function VideoSettings()
    {
    } // End of the function
    static function getLCDDisplayModes()
    {
        return (true);
    } // End of the function
    static function setLCDDisplayModes(b)
    {
    } // End of the function
    static function needsReboot()
    {
        return (false);
    } // End of the function
    static function isRunningWithUnsupportedDrivers()
    {
        return (false);
    } // End of the function
    static function isOptimzingShaders()
    {
        return (true);
    } // End of the function
    static function detectVideoScheme()
    {
        return (1);
    } // End of the function
    static function setVideoOptionScheme(sId)
    {
    } // End of the function
    static function getVideoOptionScheme()
    {
        return (1);
    } // End of the function
    static function getSelectedVideoOptionScheme()
    {
        return ("optionsscheme");
    } // End of the function
    static function reset()
    {
    } // End of the function
    static function cancel()
    {
    } // End of the function
    static function apply()
    {
        return (true);
    } // End of the function
    static function setTextureFilteringQuality(quality)
    {
    } // End of the function
    static function getSelectedTextureFiltering()
    {
        return ("texturefiltering");
    } // End of the function
    static function setTerrainQuality(quality)
    {
    } // End of the function
    static function getSelectedTerrainQuality()
    {
        return ("terrainquality");
    } // End of the function
    static function setGeometryQuality(quality)
    {
    } // End of the function
    static function getSelectedGeometryQuality()
    {
        return ("geomqual");
    } // End of the function
    static function setLightingQuality(quality)
    {
    } // End of the function
    static function getSelectedLightingQuality()
    {
        return ("lightningquality");
    } // End of the function
    static function setDynamicLightingQuality(quality)
    {
    } // End of the function
    static function getSelectedDynamicLightingQuality()
    {
        return ("dynlightqual");
    } // End of the function
    static function setDynamicShadowsQuality(qual)
    {
    } // End of the function
    static function getSelectedDynamicShadowsQuality()
    {
        return ("dynamicshadowqual");
    } // End of the function
    static function setEffectsQuality(quality)
    {
    } // End of the function
    static function getSelectedEffectsQuality()
    {
        return ("effectsqual");
    } // End of the function
    static function setTextureQuality(quality)
    {
    } // End of the function
    static function getSelectedTexturequality()
    {
        return ("texturequal");
    } // End of the function
    static function getViewDistanceScale()
    {
        return (7.000000E-001);
    } // End of the function
    static function setViewDistanceScale(quality)
    {
    } // End of the function
    static function setResolution(quality)
    {
    } // End of the function
    static function getSelectedResolution()
    {
        return ("800x600");
    } // End of the function
    static function getSelectedAntialias()
    {
        return ("antialiasing");
    } // End of the function
    static function setAntialiasing(quality)
    {
    } // End of the function
    static function setOverallQuality(quality)
    {
    } // End of the function
    static function getSelectedOverallQuality()
    {
        return ("Overallquality");
    } // End of the function
    static function tryToApplySettings()
    {
        return (true);
    } // End of the function
} // End of Class
