class dice.bf2.Sound
{
    function Sound()
    {
    } // End of the function
    static function playSound(s)
    {
        trace ("SOUND: " + s);
    } // End of the function
    static function voipSetTransmitVolume(nValue)
    {
        trace (nValue);
    } // End of the function
    static function voipGetTransmitVolume()
    {
        return (5.000000E-001);
    } // End of the function
    static function voipSetRecieveVolume(nValue)
    {
    } // End of the function
    static function voipGetRecieveVolume()
    {
        return (3.000000E-001);
    } // End of the function
    static function voipInitialize()
    {
        return (true);
    } // End of the function
    static function voipSetThresholdVolume(nValue)
    {
    } // End of the function
    static function voipGetThresholdVolume()
    {
        return (2.000000E-001);
    } // End of the function
    static function voipGetSendingVoiceVolume()
    {
        return (4.000000E-001);
    } // End of the function
    static function voipGetBoost()
    {
        return (true);
    } // End of the function
    static function isVoipBoostEnabled()
    {
        return (true);
    } // End of the function
    static function voipIsBoostEnabled()
    {
        return (true);
    } // End of the function
    static function voipGetEnable()
    {
        return (true);
    } // End of the function
    static function voipSendingVoice()
    {
        return (true);
    } // End of the function
    static function voipStartTest()
    {
    } // End of the function
    static function voipStopTest()
    {
    } // End of the function
    static function voipSetEnable(bValue)
    {
        return (true);
    } // End of the function
} // End of Class
