class dice.bf2.ServerInfo
{
    function ServerInfo()
    {
    } // End of the function
    static function getCommunityLogo()
    {
        return ("fineweather");
    } // End of the function
    static function getServerName()
    {
        return ("Battlefield 2 server (nvidia.dice.se)");
    } // End of the function
    static function getSponsorText()
    {
        return ("sponsorText");
    } // End of the function
    static function getWelcomeMessage()
    {
        return ("Welcomemessage");
    } // End of the function
    static function getSponsorLogo()
    {
        return ("http://www.sponsorLogo.com");
    } // End of the function
    static function getMapName()
    {
        return ("mapName");
    } // End of the function
    static function getMaxPlayers()
    {
        return (32);
    } // End of the function
    static function getGameModeTitle()
    {
        return ("gameModeTitle");
    } // End of the function
    static function getGameModeDescription()
    {
        return ("gameModeDescription");
    } // End of the function
    static function getBackgroundTitle()
    {
        return ("backgroundTitle");
    } // End of the function
    static function getBackgroundDescription()
    {
        return ("backgroundDescription");
    } // End of the function
} // End of Class
