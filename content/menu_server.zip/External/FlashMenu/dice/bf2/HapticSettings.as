class dice.bf2.HapticSettings
{
    function HapticSettings()
    {
    } // End of the function
    static function apply()
    {
    } // End of the function
    static function cancel()
    {
    } // End of the function
    static function reset()
    {
    } // End of the function
    static function getControlBoxLengthSOLDIER_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthSOLDIER_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthSOLDIER_Z()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessSOLDIER_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessSOLDIER_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessSOLDIER_Z()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthLAND_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthLAND_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthLAND_Z()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessLAND_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessLAND_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessLAND_Z()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthAIR_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthAIR_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthAIR_Z()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessAIR_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessAIR_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessAIR_Z()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthHELI_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthHELI_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthHELI_Z()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessHELI_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessHELI_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessHELI_Z()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthSEA_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthSEA_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxLengthSEA_Z()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessSEA_X()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessSEA_Y()
    {
        return (0);
    } // End of the function
    static function getControlBoxStiffnessSEA_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivitySOLDIER_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivitySOLDIER_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivitySOLDIER_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthSOLDIER_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthSOLDIER_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthSOLDIER_Z()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivitySOLDIER_X()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivitySOLDIER_Y()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivitySOLDIER_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLAND_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLAND_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLAND_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthLAND_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthLAND_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthLAND_Z()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivityLAND_X()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivityLAND_Y()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivityLAND_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityAIR_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityAIR_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityAIR_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthAIR_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthAIR_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthAIR_Z()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivityAIR_X()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivityAIR_Y()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivityAIR_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityHELI_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityHELI_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityHELI_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthHELI_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthHELI_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthHELI_Z()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivityHELI_X()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivityHELI_Y()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivityHELI_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivitySEA_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivitySEA_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivitySEA_Z()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthSEA_X()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthSEA_Y()
    {
        return (0);
    } // End of the function
    static function getAimSensitivityLengthSEA_Z()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivitySEA_X()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivitySEA_Y()
    {
        return (0);
    } // End of the function
    static function getTurnSensitivitySEA_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsSOLDIERTransition(s)
    {
        return (0);
    } // End of the function
    static function getPhysicsSOLDIERScale_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsSOLDIERScale_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsSOLDIERScale_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsSOLDIERSmoothTime_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsSOLDIERSmoothTime_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsSOLDIERSmoothTime_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsLANDTransition(s)
    {
        return (0);
    } // End of the function
    static function getPhysicsLANDScale_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsLANDScale_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsLANDScale_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsLANDSmoothTime_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsLANDSmoothTime_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsLANDSmoothTime_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsAIRTransition(s)
    {
        return (0);
    } // End of the function
    static function getPhysicsAIRScale_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsAIRScale_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsAIRScale_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsAIRSmoothTime_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsAIRSmoothTime_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsAIRSmoothTime_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsHELITransition(s)
    {
        return (0);
    } // End of the function
    static function getPhysicsHELIScale_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsHELIScale_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsHELIScale_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsHELISmoothTime_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsHELISmoothTime_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsHELISmoothTime_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsSEATransition(s)
    {
        return (0);
    } // End of the function
    static function getPhysicsSEAScale_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsSEAScale_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsSEAScale_Z()
    {
        return (0);
    } // End of the function
    static function getPhysicsSEASmoothTime_X()
    {
        return (0);
    } // End of the function
    static function getPhysicsSEASmoothTime_Y()
    {
        return (0);
    } // End of the function
    static function getPhysicsSEASmoothTime_Z()
    {
        return (0);
    } // End of the function
    static function getDamageScale()
    {
        return (0);
    } // End of the function
    static function getRecoilPunchScale(s)
    {
        return (0);
    } // End of the function
    static function getRecoilPunchTime(s)
    {
        return (0);
    } // End of the function
    static function getRecoilYawScale(s)
    {
        return (0);
    } // End of the function
    static function getRecoilPitchScale(s)
    {
        return (0);
    } // End of the function
    static function setControlBoxLengthSOLDIER_X(n)
    {
    } // End of the function
    static function setControlBoxLengthSOLDIER_Y(n)
    {
    } // End of the function
    static function setControlBoxLengthSOLDIER_Z(n)
    {
    } // End of the function
    static function setControlBoxStiffnessSOLDIER_X(n)
    {
    } // End of the function
    static function setControlBoxStiffnessSOLDIER_Y(n)
    {
    } // End of the function
    static function setControlBoxStiffnessSOLDIER_Z(n)
    {
    } // End of the function
    static function setControlBoxLengthLAND_X(n)
    {
    } // End of the function
    static function setControlBoxLengthLAND_Y(n)
    {
    } // End of the function
    static function setControlBoxLengthLAND_Z(n)
    {
    } // End of the function
    static function setControlBoxStiffnessLAND_X(n)
    {
    } // End of the function
    static function setControlBoxStiffnessLAND_Y(n)
    {
    } // End of the function
    static function setControlBoxStiffnessLAND_Z(n)
    {
    } // End of the function
    static function setControlBoxLengthAIR_X(n)
    {
    } // End of the function
    static function setControlBoxLengthAIR_Y(n)
    {
    } // End of the function
    static function setControlBoxLengthAIR_Z(n)
    {
    } // End of the function
    static function setControlBoxStiffnessAIR_X(n)
    {
    } // End of the function
    static function setControlBoxStiffnessAIR_Y(n)
    {
    } // End of the function
    static function setControlBoxStiffnessAIR_Z(n)
    {
    } // End of the function
    static function setControlBoxLengthHELI_X(n)
    {
    } // End of the function
    static function setControlBoxLengthHELI_Y(n)
    {
    } // End of the function
    static function setControlBoxLengthHELI_Z(n)
    {
    } // End of the function
    static function setControlBoxStiffnessHELI_X(n)
    {
    } // End of the function
    static function setControlBoxStiffnessHELI_Y(n)
    {
    } // End of the function
    static function setControlBoxStiffnessHELI_Z(n)
    {
    } // End of the function
    static function setControlBoxLengthSEA_X(n)
    {
    } // End of the function
    static function setControlBoxLengthSEA_Y(n)
    {
    } // End of the function
    static function setControlBoxLengthSEA_Z(n)
    {
    } // End of the function
    static function setControlBoxStiffnessSEA_X(n)
    {
    } // End of the function
    static function setControlBoxStiffnessSEA_Y(n)
    {
    } // End of the function
    static function setControlBoxStiffnessSEA_Z(n)
    {
    } // End of the function
    static function setAimSensitivitySOLDIER_X(n)
    {
    } // End of the function
    static function setAimSensitivitySOLDIER_Y(n)
    {
    } // End of the function
    static function setAimSensitivitySOLDIER_Z(n)
    {
    } // End of the function
    static function setAimSensitivityLengthSOLDIER_X(n)
    {
    } // End of the function
    static function setAimSensitivityLengthSOLDIER_Y(n)
    {
    } // End of the function
    static function setAimSensitivityLengthSOLDIER_Z(n)
    {
    } // End of the function
    static function setTurnSensitivitySOLDIER_X(n)
    {
    } // End of the function
    static function setTurnSensitivitySOLDIER_Y(n)
    {
    } // End of the function
    static function setTurnSensitivitySOLDIER_Z(n)
    {
    } // End of the function
    static function setAimSensitivityLAND_X(n)
    {
    } // End of the function
    static function setAimSensitivityLAND_Y(n)
    {
    } // End of the function
    static function setAimSensitivityLAND_Z(n)
    {
    } // End of the function
    static function setAimSensitivityLengthLAND_X(n)
    {
    } // End of the function
    static function setAimSensitivityLengthLAND_Y(n)
    {
    } // End of the function
    static function setAimSensitivityLengthLAND_Z(n)
    {
    } // End of the function
    static function setTurnSensitivityLAND_X(n)
    {
    } // End of the function
    static function setTurnSensitivityLAND_Y(n)
    {
    } // End of the function
    static function setTurnSensitivityLAND_Z(n)
    {
    } // End of the function
    static function setAimSensitivityAIR_X(n)
    {
    } // End of the function
    static function setAimSensitivityAIR_Y(n)
    {
    } // End of the function
    static function setAimSensitivityAIR_Z(n)
    {
    } // End of the function
    static function setAimSensitivityLengthAIR_X(n)
    {
    } // End of the function
    static function setAimSensitivityLengthAIR_Y(n)
    {
    } // End of the function
    static function setAimSensitivityLengthAIR_Z(n)
    {
    } // End of the function
    static function setTurnSensitivityAIR_X(n)
    {
    } // End of the function
    static function setTurnSensitivityAIR_Y(n)
    {
    } // End of the function
    static function setTurnSensitivityAIR_Z(n)
    {
    } // End of the function
    static function setAimSensitivityHELI_X(n)
    {
    } // End of the function
    static function setAimSensitivityHELI_Y(n)
    {
    } // End of the function
    static function setAimSensitivityHELI_Z(n)
    {
    } // End of the function
    static function setAimSensitivityLengthHELI_X(n)
    {
    } // End of the function
    static function setAimSensitivityLengthHELI_Y(n)
    {
    } // End of the function
    static function setAimSensitivityLengthHELI_Z(n)
    {
    } // End of the function
    static function setTurnSensitivityHELI_X(n)
    {
    } // End of the function
    static function setTurnSensitivityHELI_Y(n)
    {
    } // End of the function
    static function setTurnSensitivityHELI_Z(n)
    {
    } // End of the function
    static function setAimSensitivitySEA_X(n)
    {
    } // End of the function
    static function setAimSensitivitySEA_Y(n)
    {
    } // End of the function
    static function setAimSensitivitySEA_Z(n)
    {
    } // End of the function
    static function setAimSensitivityLengthSEA_X(n)
    {
    } // End of the function
    static function setAimSensitivityLengthSEA_Y(n)
    {
    } // End of the function
    static function setAimSensitivityLengthSEA_Z(n)
    {
    } // End of the function
    static function setTurnSensitivitySEA_X(n)
    {
    } // End of the function
    static function setTurnSensitivitySEA_Y(n)
    {
    } // End of the function
    static function setTurnSensitivitySEA_Z(n)
    {
    } // End of the function
    static function setPhysicsSOLDIERTransition(s, n)
    {
        return (0);
    } // End of the function
    static function setPhysicsSOLDIERScale_X(n)
    {
    } // End of the function
    static function setPhysicsSOLDIERScale_Y(n)
    {
    } // End of the function
    static function setPhysicsSOLDIERScale_Z(n)
    {
    } // End of the function
    static function setPhysicsSOLDIERSmoothTime_X(n)
    {
    } // End of the function
    static function setPhysicsSOLDIERSmoothTime_Y(n)
    {
    } // End of the function
    static function setPhysicsSOLDIERSmoothTime_Z(n)
    {
    } // End of the function
    static function setPhysicsLANDTransition(s, n)
    {
        return (0);
    } // End of the function
    static function setPhysicsLANDScale_X(n)
    {
    } // End of the function
    static function setPhysicsLANDScale_Y(n)
    {
    } // End of the function
    static function setPhysicsLANDScale_Z(n)
    {
    } // End of the function
    static function setPhysicsLANDSmoothTime_X(n)
    {
    } // End of the function
    static function setPhysicsLANDSmoothTime_Y(n)
    {
    } // End of the function
    static function setPhysicsLANDSmoothTime_Z(n)
    {
    } // End of the function
    static function setPhysicsAIRTransition(s, n)
    {
        return (0);
    } // End of the function
    static function setPhysicsAIRScale_X(n)
    {
    } // End of the function
    static function setPhysicsAIRScale_Y(n)
    {
    } // End of the function
    static function setPhysicsAIRScale_Z(n)
    {
    } // End of the function
    static function setPhysicsAIRSmoothTime_X(n)
    {
    } // End of the function
    static function setPhysicsAIRSmoothTime_Y(n)
    {
    } // End of the function
    static function setPhysicsAIRSmoothTime_Z(n)
    {
    } // End of the function
    static function setPhysicsHELITransition(s, n)
    {
        return (0);
    } // End of the function
    static function setPhysicsHELIScale_X(n)
    {
    } // End of the function
    static function setPhysicsHELIScale_Y(n)
    {
    } // End of the function
    static function setPhysicsHELIScale_Z(n)
    {
    } // End of the function
    static function setPhysicsHELISmoothTime_X(n)
    {
    } // End of the function
    static function setPhysicsHELISmoothTime_Y(n)
    {
    } // End of the function
    static function setPhysicsHELISmoothTime_Z(n)
    {
    } // End of the function
    static function setPhysicsSEATransition(s, n)
    {
        return (0);
    } // End of the function
    static function setPhysicsSEAScale_X(n)
    {
    } // End of the function
    static function setPhysicsSEAScale_Y(n)
    {
    } // End of the function
    static function setPhysicsSEAScale_Z(n)
    {
    } // End of the function
    static function setPhysicsSEASmoothTime_X(n)
    {
    } // End of the function
    static function setPhysicsSEASmoothTime_Y(n)
    {
    } // End of the function
    static function setPhysicsSEASmoothTime_Z(n)
    {
    } // End of the function
    static function setDamageScale(n)
    {
    } // End of the function
    static function setRecoilPunchScale(n, m)
    {
    } // End of the function
    static function setRecoilPunchTime(n, m)
    {
    } // End of the function
    static function setRecoilYawScale(n, m)
    {
    } // End of the function
    static function setRecoilPitchScale(n, m)
    {
    } // End of the function
    static function setWeaponSelectSOLDIER(n)
    {
    } // End of the function
    static function getWeaponSelectSOLDIER()
    {
        return ("");
    } // End of the function
    static function setWeaponInitialSOLDIER(n)
    {
    } // End of the function
    static function getWeaponInitialSOLDIER(n)
    {
        return ("");
    } // End of the function
    static function setThresholdSelectSOLDIER(n)
    {
        return (0);
    } // End of the function
    static function getThresholdSelectSOLDIER()
    {
        return ("");
    } // End of the function
    static function setThresholdInitialSOLDIER(n)
    {
    } // End of the function
    static function getThresholdInitialSOLDIER()
    {
        return ("");
    } // End of the function
    static function setWeaponSelectLAND(n)
    {
    } // End of the function
    static function getWeaponSelectLAND()
    {
        return ("");
    } // End of the function
    static function setWeaponInitialLAND(n)
    {
    } // End of the function
    static function getWeaponInitialLAND(n)
    {
        return ("");
    } // End of the function
    static function setThresholdSelectLAND(n)
    {
        return (0);
    } // End of the function
    static function getThresholdSelectLAND()
    {
        return ("");
    } // End of the function
    static function setThresholdInitialLAND(n)
    {
    } // End of the function
    static function getThresholdInitialLAND()
    {
        return ("");
    } // End of the function
    static function setWeaponSelectAIR(n)
    {
    } // End of the function
    static function getWeaponSelectAIR()
    {
        return ("");
    } // End of the function
    static function setWeaponInitialAIR(n)
    {
    } // End of the function
    static function getWeaponInitialAIR(n)
    {
        return ("");
    } // End of the function
    static function setThresholdSelectAIR(n)
    {
        return (0);
    } // End of the function
    static function getThresholdSelectAIR()
    {
        return ("");
    } // End of the function
    static function setThresholdInitialAIR(n)
    {
    } // End of the function
    static function getThresholdInitialAIR()
    {
        return ("");
    } // End of the function
    static function setWeaponSelectHELI(n)
    {
    } // End of the function
    static function getWeaponSelectHELI()
    {
        return ("");
    } // End of the function
    static function setWeaponInitialHELI(n)
    {
    } // End of the function
    static function getWeaponInitialHELI(n)
    {
        return ("");
    } // End of the function
    static function setThresholdSelectHELI(n)
    {
        return (0);
    } // End of the function
    static function getThresholdSelectHELI()
    {
        return ("");
    } // End of the function
    static function setThresholdInitialHELI(n)
    {
    } // End of the function
    static function getThresholdInitialHELI()
    {
        return ("");
    } // End of the function
    static function setWeaponSelectSEA(n)
    {
    } // End of the function
    static function getWeaponSelectSEA()
    {
        return ("");
    } // End of the function
    static function setWeaponInitialSEA(n)
    {
    } // End of the function
    static function getWeaponInitialSEA(n)
    {
        return ("");
    } // End of the function
    static function setThresholdSelectSEA(n)
    {
        return (0);
    } // End of the function
    static function getThresholdSelectSEA()
    {
        return ("");
    } // End of the function
    static function setThresholdInitialSEA(n)
    {
    } // End of the function
    static function getThresholdInitialSEA()
    {
        return ("");
    } // End of the function
    static function setHapticSettingsPage(n)
    {
    } // End of the function
    static function getHapticSettingsPage()
    {
        return (0);
    } // End of the function
} // End of Class
