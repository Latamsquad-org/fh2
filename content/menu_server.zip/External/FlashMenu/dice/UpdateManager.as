class dice.UpdateManager
{
    var m_enterCheckMC;
    function UpdateManager(instanceObject, nInterval)
    {
        if (nInterval > 0)
        {
            this.resetInterval(instanceObject, nInterval);
        } // end if
    } // End of the function
    function setEnterCheck(mc)
    {
        trace ("UM: set entercheck: " + mc);
        m_enterCheckEnabled = true;
        m_enterCheckMC = mc;
    } // End of the function
    function getEnterCheck()
    {
        return (m_enterCheckMC);
    } // End of the function
    function clearEnterCheck()
    {
        trace ("UM: clearentercheck");
        m_enterCheckEnabled = false;
    } // End of the function
    function enableEnterCheck()
    {
        m_enterCheckEnabled = true;
    } // End of the function
    function getIndex(obj, func)
    {
        for (var _loc2 = 0; _loc2 < m_updates.length; ++_loc2)
        {
            if (m_updates[_loc2].m_object == obj && m_updates[_loc2].m_function == func)
            {
                return (_loc2);
            } // end if
        } // end of for
        return (-1);
    } // End of the function
    function registerTrigger(obj, func, arg, arg2)
    {
        var _loc2 = new Object();
        _loc2.m_object = obj;
        _loc2.m_function = func;
        _loc2.m_arg = arg;
        if (arg2.length > 0)
        {
            _loc2.m_arg2 = new String(arg2);
        }
        else
        {
            _loc2.m_arg2 = new String("");
        } // end else if
        m_triggers.push(_loc2);
    } // End of the function
    function registerCallback(obj, func, freq)
    {
        if (!freq || freq == 0)
        {
            freq = 1;
        } // end if
        trace ("UM: Register callback for: " + obj + ", function: " + func + " freq: " + freq);
        var _loc4 = this.getIndex(obj, func);
        if (_loc4 < 0)
        {
            var _loc2 = new Object();
            _loc2.m_object = obj;
            _loc2.m_function = func;
            _loc2.m_freq = freq;
            _loc2.m_updateNum = 0;
            _loc2.m_updateCounterStart = m_updateCounter;
            _loc2.m_refCount = 1;
            m_updates.push(_loc2);
        }
        else
        {
            ++m_updates[_loc4].m_refCount;
        } // end else if
    } // End of the function
    function unregisterCallback(obj, func)
    {
        trace ("UM: UN-Register callback for: " + obj + ", function: " + func);
        var _loc2 = this.getIndex(obj, func);
        if (_loc2 >= 0)
        {
            if (!--m_updates[_loc2].m_refCount)
            {
                m_updates.splice(_loc2, 1);
                return (true);
            } // end if
        } // end if
        return (false);
    } // End of the function
    function update()
    {
        var _loc9 = 0;
        while (m_triggers.length)
        {
            var _loc2 = m_triggers[0];
            var _loc8 = new String(_loc2.m_function);
            var _loc5 = _loc8.split(".");
            var _loc7 = _loc5.length;
            var _loc3 = _loc2.m_object;
            if (_loc7 < 2)
            {
                if (_loc2.m_arg2.length > 0)
                {
                    _loc3[_loc2.m_function](_loc2.m_arg, _loc2.m_arg2);
                }
                else
                {
                    _loc3[_loc2.m_function](_loc2.m_arg);
                } // end else if
            }
            else
            {
                for (var _loc4 = 0; _loc4 < _loc7 - 1; ++_loc4)
                {
                    _loc3 = _loc3[_loc5[_loc4]];
                } // end of for
                if (_loc2.m_arg2.length > 0)
                {
                    _loc3[_loc5[_loc4]](_loc2.m_arg, _loc2.m_arg2);
                }
                else
                {
                    _loc3[_loc5[_loc4]](_loc2.m_arg);
                } // end else if
            } // end else if
            m_triggers.shift();
        } // end while
        for (var _loc6 = 0; _loc6 < m_updates.length; ++_loc6)
        {
            _loc2 = m_updates[_loc6];
            if (_loc2.freq == 1 || Math.round((m_updateCounter - _loc2.m_updateCounterStart + 1) / _loc2.m_freq) > _loc2.m_updateNum)
            {
                if (!_loc2.m_object[_loc2.m_function]())
                {
                    if (this.unregisterCallback(_loc2.m_object, _loc2.m_function))
                    {
                        --_loc6;
                    } // end if
                } // end if
                ++_loc2.m_updateNum;
            } // end if
        } // end of for
        if (Key.isDown(13) && m_enterCheckEnabled)
        {
            trace ("UM: Enter pressed!");
            m_enterCheckEnabled = false;
            if (m_enterCheckMC)
            {
                m_enterCheckMC.runEnterFunction();
            } // end if
        } // end if
        ++m_updateCounter;
    } // End of the function
    function clearOwnInterval()
    {
        if (m_intervalId)
        {
            clearInterval(m_intervalId);
            return (true);
        } // end if
        return (false);
    } // End of the function
    function resetInterval(instanceObject, nInterval)
    {
        var _loc2 = false;
        _loc2 = this.clearOwnInterval();
        m_intervalId = setInterval(this, "update", nInterval);
        return (_loc2);
    } // End of the function
    var m_updates = new Array();
    var m_triggers = new Array();
    var m_intervalId = 0;
    var m_updateCounter = 0;
    var m_enterCheckEnabled = false;
} // End of Class
