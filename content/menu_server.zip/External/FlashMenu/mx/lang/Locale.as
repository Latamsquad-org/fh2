class mx.lang.Locale
{
    static var flaName, defaultLang;
    function Locale()
    {
    } // End of the function
    static function setXMLLang(langCode)
    {
        trace ("setXMLLang");
        xmlLang = langCode;
    } // End of the function
    static function setFlaName(name)
    {
        trace ("setFlaName " + name);
        flaName = name;
    } // End of the function
    static function setDefaultLang(langCode)
    {
        trace ("setDefaultLang");
        defaultLang = langCode;
    } // End of the function
    static function addXMLPath(langCode, path)
    {
        trace ("addXMLPath");
        return;
    } // End of the function
    static function checkXMLStatus()
    {
        trace ("checkXMLStatus");
        return (false);
    } // End of the function
    static function addDelayedInstance(instance, stringID)
    {
        if (stringID.length > 0)
        {
            instance.text = dice.bf2.Locale.getString(stringID);
        } // end if
    } // End of the function
    static function checkDelayArray()
    {
        trace ("checkDelayArray");
        for (var _loc1 = 0; _loc1 < mx.lang.Locale.instanceObjects.length; ++_loc1)
        {
            if (mx.lang.Locale.instanceObjects[_loc1] == undefined)
            {
                return (false);
            } // end if
        } // end of for
        return (true);
    } // End of the function
    static function initialize()
    {
        trace ("initialize");
        mx.lang.Locale.start();
    } // End of the function
    static function start()
    {
        trace ("start");
        mx.lang.Locale.assignDelayedInstances();
    } // End of the function
    static function onXMLLoad(success)
    {
        trace ("onXMLLoad");
    } // End of the function
    static function assignDelayedInstances()
    {
        trace ("assignDelayedInstances");
        for (var _loc1 = 0; _loc1 < mx.lang.Locale.instanceObjects.length; ++_loc1)
        {
            if (mx.lang.Locale.instanceObjects[_loc1] != undefined)
            {
                var _loc3 = mx.lang.Locale.instanceObjects[_loc1];
                var _loc2 = mx.lang.Locale.instanceIds[_loc1];
                _loc3.text = dice.bf2.Locale.getString(_loc2);
            } // end if
        } // end of for
    } // End of the function
    static var xmlLang = System.capabilities.language;
    static var instanceObjects = new Array();
    static var instanceIds = new Array();
    static var currentXMLMapIndex = -1;
} // End of Class
